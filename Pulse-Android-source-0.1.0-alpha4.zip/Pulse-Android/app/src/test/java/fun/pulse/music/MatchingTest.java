package fun.pulse.music;

import static org.junit.Assert.*;

import org.junit.Test;

public class MatchingTest {
  Track song(String artist, String title, long duration) {
    Track t = new Track();
    t.artist = artist;
    t.title = title;
    t.duration = duration;
    return t;
  }

  @Test
  public void exactBeatPopularity() {
    Track exact = song("YUNG TRAPPA", "Одна ночь", 150000),
        other = song("Yung Drip", "Другая песня", 140000);
    assertTrue(
        Matching.score("YUNG TRAPPA Одна ночь", exact)
            > Matching.score("YUNG TRAPPA Одна ночь", other));
  }

  @Test
  public void wrongEditNeverMatches() {
    assertFalse(
        Matching.sameRecording(
            song("Artist", "Title", 180000), song("Artist", "Title (slowed)", 181000)));
    assertFalse(
        Matching.sameRecording(
            song("Artist", "Title", 180000), song("Artist", "Title (remix)", 180000)));
  }

  @Test
  public void uploaderCreditCanMatch() {
    assertTrue(
        Matching.sameRecording(
            song("Artist", "Night", 180000),
            song("Uploader", "Artist - Night (official audio)", 182000)));
  }

  @Test
  public void durationMismatchRejects() {
    assertFalse(
        Matching.sameRecording(song("Artist", "Night", 180000), song("Artist", "Night", 30000)));
  }

  @Test
  public void partialArtistCannotImpersonateExact() {
    assertTrue(
        Matching.score("yung trappa", song("YUNG TRAPPA", "Нужна", 200000))
            > Matching.score("yung trappa", song("Yung Q", "Trapaholic", 200000)));
  }
}
