package fun.pulse.music;

import android.app.Dialog;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.*;
import android.widget.*;

/** A themed bottom sheet; blur belongs to the Activity, never to the menu itself. */
final class TrackSheet extends Dialog {
  final MainActivity a;
  final Track track;
  final LinearLayout panel;
  boolean backgroundBlurred;

  TrackSheet(MainActivity activity, Track song) {
    super(activity);
    a = activity;
    track = song;
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    panel = a.column();
    panel.setPadding(a.dp(18), a.dp(12), a.dp(18), a.dp(16));
    GradientDrawable bg =
        new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, new int[] {0xff24242c, 0xff111519});
    bg.setCornerRadius(a.dp(28));
    bg.setStroke(a.dp(1), 0xff49424d);
    panel.setBackground(bg);
    View handle = new View(a);
    GradientDrawable h = new GradientDrawable();
    h.setColor(0xff817887);
    h.setCornerRadius(a.dp(2));
    handle.setBackground(h);
    LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(a.dp(34), a.dp(4));
    hp.gravity = Gravity.CENTER_HORIZONTAL;
    panel.addView(handle, hp);
    a.space(panel, 20);
    LinearLayout header = a.row();
    header.addView(a.art(song, 52), new LinearLayout.LayoutParams(a.dp(52), a.dp(52)));
    LinearLayout names = a.column();
    names.setPadding(a.dp(12), 0, 0, 0);
    TextView title = a.text(song.title, 17, a.TEXT, true);
    title.setMaxLines(2);
    title.setEllipsize(android.text.TextUtils.TruncateAt.END);
    names.addView(title);
    a.space(names, 5);
    TextView artist = a.text(song.artist, 13, a.MUTED, false);
    artist.setMaxLines(1);
    artist.setEllipsize(android.text.TextUtils.TruncateAt.END);
    names.addView(artist);
    header.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
    panel.addView(header);
    a.space(panel, 16);
    String[] labels = {
      a.favorites.stream().anyMatch(t -> t.id.equals(song.id)) ? "Убрать из любимого" : "В любимые",
      "Моя волна по этому треку",
      "Слушать следующим",
      "К исполнителю",
      "Версии трека"
    };
    String[] icons = {"heart", "shuffle", "queue", "profile", "search"};
    for (int i = 0; i < labels.length; i++) {
      final int action = i;
      LinearLayout row = a.row();
      row.setPadding(a.dp(8), a.dp(4), a.dp(8), a.dp(4));
      row.setMinimumHeight(a.dp(54));
      Icons icon = new Icons(a, icons[i]);
      icon.tint(i == 1 ? a.ACCENT : 0xffd6d3dd);
      row.addView(icon, new LinearLayout.LayoutParams(a.dp(40), a.dp(40)));
      TextView label = a.text(labels[i], 15, a.TEXT, i == 1);
      label.setPadding(a.dp(10), 0, 0, 0);
      row.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
      row.setContentDescription(labels[i]);
      a.tap(
          row,
          () -> {
            dismiss();
            a.trackAction(song, action);
          });
      panel.addView(row);
    }
    a.space(panel, 10);
    panel.addView(a.button("Закрыть", this::dismiss));
    ScrollView scroll =
        new ScrollView(a) {
          @Override
          protected void onMeasure(int w, int h) {
            super.onMeasure(
                w,
                MeasureSpec.makeMeasureSpec(
                    (int) (a.getResources().getDisplayMetrics().heightPixels * .82),
                    MeasureSpec.AT_MOST));
          }
        };
    scroll.setFillViewport(false);
    scroll.setVerticalScrollBarEnabled(false);
    scroll.addView(panel);
    FrameLayout host = new FrameLayout(a);
    host.setPadding(a.dp(10), a.dp(10), a.dp(10), a.dp(12) + a.shell.getPaddingBottom());
    host.addView(scroll, new FrameLayout.LayoutParams(-1, -2));
    setContentView(host);
    setOnDismissListener(
        d -> {
          blur(false);
          if (a.trackSheet == this) a.trackSheet = null;
        });
  }

  @Override
  public void show() {
    super.show();
    Window w = getWindow();
    w.setBackgroundDrawableResource(android.R.color.transparent);
    w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
    w.setDimAmount(.42f);
    w.setLayout(-1, -2);
    w.setGravity(Gravity.BOTTOM);
    w.setNavigationBarColor(Color.TRANSPARENT);
    blur(true);
    if (MobileMotion.enabled()) {
      panel.setAlpha(0);
      panel.setTranslationY(a.dp(20));
      panel.animate().alpha(1).translationY(0).setDuration(200).start();
    }
  }

  void blur(boolean enabled) {
    if (Build.VERSION.SDK_INT >= 31) {
      a.root.setRenderEffect(
          enabled ? RenderEffect.createBlurEffect(a.dp(5), a.dp(5), Shader.TileMode.CLAMP) : null);
      backgroundBlurred = enabled;
    }
  }
}
