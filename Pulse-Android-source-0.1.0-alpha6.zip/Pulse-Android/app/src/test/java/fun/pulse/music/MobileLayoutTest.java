package fun.pulse.music;

import static org.junit.Assert.*;

import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;

/** Native Android layout rendering in Robolectric. WebGL and online audio need device QA. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35, qualifiers = "w384dp-h800dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class MobileLayoutTest {
  ActivityController<MainActivity> controller;
  MainActivity a;

  @Before
  public void setup() {
    RuntimeEnvironment.getApplication().getSharedPreferences("pulse-v1", 0).edit().clear().commit();
    // Layout-only tests: the default fake service binder has a null ComponentName.
    // Media transport is covered separately rather than treating this as a device service.
    org.robolectric.Shadows.shadowOf(RuntimeEnvironment.getApplication())
        .declareComponentUnbindable(
            new android.content.ComponentName(
                RuntimeEnvironment.getApplication(), PlaybackService.class));
    controller = Robolectric.buildActivity(MainActivity.class).create();
    a = controller.get();
  }

  @After
  public void stop() {
    controller.destroy();
  }

  @Test
  public void fittedPlayerKeepsAllSixControlsAndActionsVisible() throws Exception {
    org.json.JSONObject p = a.store.register("Listener", "fit@example.invalid", "test-pass-6");
    a.store.activate(p);
    a.store.put("tour:" + p.getString("id"), "true");
    Track t = new Track();
    t.id = "local:fit";
    t.source = "local";
    t.title = "Очень длинное название песни, которое должно занимать не больше двух строк";
    t.artist = "Исполнитель";
    a.current = t;
    int[][] sizes = {{320, 640}, {360, 740}, {384, 800}, {412, 860}, {800, 384}};
    for (int[] size : sizes) {
      RuntimeEnvironment.setQualifiers("w" + size[0] + "dp-h" + size[1] + "dp-mdpi");
      a.nowPlaying();
      render("mobile-alpha6-player-" + size[0], size[0], size[1]);
      assertTrue(a.content.getChildAt(0) instanceof NowPlayingView);
      NowPlayingView player = a.nowView;
      assertNotNull(player);
      assertEquals(6, player.controls.getChildCount());
      assertTrue(
          "details below viewport " + size[0],
          player.details.getBottom() <= player.stage.getHeight());
      assertTrue(
          "controls below details", player.controls.getBottom() <= player.details.getHeight());
      View first = player.controls.getChildAt(0), last = player.controls.getChildAt(5);
      assertEquals(player.controls.getWidth() / 2f, (first.getLeft() + last.getRight()) / 2f, 1);
      assertTrue(player.cover.getWidth() >= 80);
      assertTrue(player.cover.getDrawable() instanceof CoverPlaceholder);
      assertTrue(player.artist.getHeight() >= player.artist.getLayout().getHeight());
      assertEquals("Исполнитель", player.artist.getText().toString());
      assertTrue("artist width=" + player.artist.getWidth(), player.artist.getWidth() > 100);
      assertTrue(
          "artist height=" + player.artist.getHeight() + " text=" + player.artist.getText(),
          player.artist.getHeight() > 12);
      assertTrue(a.nowTime.getHeight() >= a.nowTime.getLayout().getHeight());
      if (size[0] == 384) {
        Bitmap artistImage =
            Bitmap.createBitmap(
                player.artist.getWidth(), player.artist.getHeight(), Bitmap.Config.ARGB_8888);
        player.artist.draw(new Canvas(artistImage));
        int ink = 0;
        for (int y = 0; y < artistImage.getHeight(); y++)
          for (int x = 0; x < artistImage.getWidth(); x++)
            if (Color.alpha(artistImage.getPixel(x, y)) > 20) ink++;
        try (FileOutputStream stream = new FileOutputStream("build/qa/mobile-alpha6-artist.png")) {
          artistImage.compress(Bitmap.CompressFormat.PNG, 100, stream);
        }
        artistImage.recycle();
        assertTrue("Artist must actually draw text: " + ink, ink > 10);
      }
      assertNotNull(findText(player, "Текст песни"));
      assertNotNull(findText(player, "Моя волна"));
      for (int i = 0; i < player.details.getChildCount(); i++) {
        View child = player.details.getChildAt(i);
        if (child.getVisibility() != View.GONE)
          assertTrue(child.getBottom() <= player.details.getHeight());
      }
    }
    RuntimeEnvironment.setQualifiers("w360dp-h740dp-mdpi");
    RuntimeEnvironment.setFontScale(1.5f);
    a.nowPlaying();
    render("mobile-alpha6-player-large-font", 360, 740);
    assertTrue(a.nowView.details.getBottom() <= a.nowView.stage.getHeight());
    RuntimeEnvironment.setFontScale(1);
    a.nowLikeIcon.performClick();
    assertTrue(a.nowLikeIcon.favorite);
    a.nowDislikeIcon.performClick();
    assertTrue(a.nowDislikeIcon.disliked);
    assertFalse(a.nowLikeIcon.favorite);
    assertTrue(a.store.tracks("favorites").isEmpty());
    assertEquals(1, a.store.tracks("dislikes").size());
    org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper())
        .idleFor(java.time.Duration.ofMillis(250));
    render("mobile-alpha6-dislike", 360, 740);
    a.nowLikeIcon.performClick();
    assertFalse(a.nowDislikeIcon.disliked);
    assertTrue(a.store.tracks("dislikes").isEmpty());
  }

  @Test
  public void playlistsAndSilentHeartFitAndPersist() throws Exception {
    org.json.JSONObject profile =
        a.store.register("Listener", "playlist@example.invalid", "test-pass-5");
    a.store.activate(profile);
    a.store.put("tour:" + profile.getString("id"), "true");
    Track t = new Track();
    t.id = "local:qa";
    t.source = "local";
    t.title = "Песня для плейлиста";
    t.artist = "Исполнитель";
    String id = a.playlists.data.create("В дорогу");
    a.playlists.data.add(id, t);
    a.playlists.open(id);
    render("mobile-alpha5-playlist", 384, 800);
    assertEquals("playlist", a.page);
    assertNotNull(findText(a.content, "Переименовать"));
    ListView list = (ListView) a.content.getChildAt(0);
    assertEquals(View.OVER_SCROLL_NEVER, list.getOverScrollMode());
    assertFalse(list.isVerticalScrollBarEnabled());
    assertTrue(list.getClipToPadding());
    a.current = t;
    a.nowPlaying();
    assertNotNull(a.nowLikeIcon);
    assertFalse(a.nowLikeIcon.favorite);
    org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper())
        .idleFor(java.time.Duration.ofMillis(250));
    android.widget.Toast oldToast = org.robolectric.shadows.ShadowToast.getLatestToast();
    a.nowLikeIcon.performClick();
    assertTrue(a.nowLikeIcon.favorite);
    assertEquals(1, a.store.tracks("favorites").size());
    assertSame(oldToast, org.robolectric.shadows.ShadowToast.getLatestToast());
    org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper())
        .idleFor(java.time.Duration.ofMillis(250));
    render("mobile-alpha5-liked", 384, 800);
    a.nowLikeIcon.performClick();
    assertFalse(a.nowLikeIcon.favorite);
    assertTrue(a.store.tracks("favorites").isEmpty());
    a.trackMenu(t);
    assertNotNull(findText(a.trackSheet.panel, "В плейлист"));
    a.trackSheet.dismiss();
    a.playlists.show();
    render("mobile-alpha5-playlists", 384, 800);
  }

  void render(String name, int width, int height) throws Exception {
    a.root.measure(
        View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
        View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
    a.root.layout(0, 0, width, height);
    Bitmap image = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
    a.root.draw(new Canvas(image));
    File dir = new File("build/qa");
    dir.mkdirs();
    try (FileOutputStream out = new FileOutputStream(new File(dir, name + ".png"))) {
      image.compress(Bitmap.CompressFormat.PNG, 100, out);
    }
    image.recycle();
    assertEquals(width, a.root.getMeasuredWidth());
    assertEquals(height, a.root.getMeasuredHeight());
  }

  @Test
  public void smallPhoneHasScrollableAuthAndReadableTitle() throws Exception {
    render("mobile-login-384", 384, 800);
    assertEquals("auth", a.page);
    assertEquals(View.GONE, a.nav.getVisibility());
    assertEquals(View.GONE, a.mini.getVisibility());
    a.auth(true);
    render("mobile-register-320", 320, 640);
    assertTrue(a.content.getChildAt(0) instanceof ScrollView);
    TextView headline = findText(a.content, "Музыка\nначинается с тебя.");
    assertNotNull(headline);
    assertNotNull(headline.getLayout());
    assertTrue(headline.getHeight() >= headline.getLayout().getHeight());
  }

  @Test
  public void homeProfileAndPlayerFitPhone() throws Exception {
    org.json.JSONObject p = a.store.register("Слушатель", "qa@example.invalid", "test-pass-3");
    a.store.activate(p);
    a.store.put("tour:" + p.getString("id"), "true");
    Track t = new Track();
    t.id = "qa";
    t.title = "Твоя любимая песня";
    t.artist = "Исполнитель";
    t.source = "local";
    t.duration = 180000;
    a.homeRows = new ArrayList<>(Arrays.asList(t));
    a.home();
    render("mobile-home-384", 384, 800);
    assertTrue(a.mini.getBottom() <= a.nav.getTop());
    assertTrue(a.nav.getBottom() <= 800);
    a.profile();
    render("mobile-profile-384", 384, 800);
    assertNotNull(findText(a.content, "Выйти из профиля"));
    assertNotNull(findText(a.content, "Подключить Яндекс по коду"));
    assertNotNull(findText(a.content, "Импортировать из Яндекс Музыки"));
    assertNull(findText(a.content, "Таймер сна"));
    assertNull(findText(a.content, "Настроить волну"));
    assertNull(findText(a.content, "Сохранить диагностику звука"));
    assertNotNull(a.miniArt);
    a.current = t;
    a.nowPlaying();
    render("mobile-player-384", 384, 800);
    assertEquals(View.GONE, a.mini.getVisibility());
    assertEquals(View.GONE, a.nav.getVisibility());
    assertNotNull(a.nowSeek);
  }

  @Test
  public void differentPhoneWidthsAndLargeTextRemainUsable() throws Exception {
    org.json.JSONObject p = a.store.register("Слушатель", "sizes@example.invalid", "test-pass-4");
    a.store.activate(p);
    a.store.put("tour:" + p.getString("id"), "true");
    Track t = new Track();
    t.id = "qa";
    t.title = "Название песни";
    t.artist = "Исполнитель";
    a.homeRows = new ArrayList<>(Arrays.asList(t));
    for (int width : new int[] {320, 360, 384, 412, 480, 600}) {
      RuntimeEnvironment.setQualifiers("w" + width + "dp-h800dp-mdpi");
      a.home();
      render("mobile-home-" + width, width, 800);
      assertTrue(a.nav.getBottom() <= 800);
      assertTrue(a.content.getBottom() <= a.mini.getTop());
      for (int i = 0; i < a.nav.getChildCount(); i++) {
        LinearLayout item = (LinearLayout) a.nav.getChildAt(i);
        View glyph = item.getChildAt(0), label = item.getChildAt(1);
        assertEquals(
            (glyph.getLeft() + glyph.getRight()) / 2, (label.getLeft() + label.getRight()) / 2, 1);
      }
    }
    RuntimeEnvironment.setQualifiers("w360dp-h780dp-mdpi");
    RuntimeEnvironment.setFontScale(1.5f);
    a.auth(true);
    render("mobile-register-large-font", 360, 780);
    TextView headline = findText(a.content, "Музыка\nначинается с тебя.");
    assertNotNull(headline);
    assertTrue(headline.getHeight() >= headline.getLayout().getHeight());
    RuntimeEnvironment.setFontScale(1);
  }

  @Test
  public void allBackgroundsIgnoreOldTouchSettingsButKeepAnimation() throws Exception {
    for (String effect : new String[] {"vortex", "chrome", "veil", "silk", "iridescence"}) {
      a.store.put("effect", effect);
      org.json.JSONObject saved =
          new org.json.JSONObject()
              .put("mouseReact", true)
              .put("mouseInteraction", true)
              .put("interactive", true)
              .put("clickRipple", true)
              .put("clickSwirl", true)
              .put("mouseStrength", 9)
              .put("speed", 0.7);
      a.store.put("effect:" + effect, saved.toString());
      org.json.JSONObject config = a.backgroundEditor.config(true);
      org.json.JSONObject props = config.getJSONObject("props");
      assertFalse(config.getBoolean("paused"));
      for (String key :
          new String[] {
            "mouseReact", "mouseInteraction", "interactive", "clickRipple", "clickSwirl"
          }) assertFalse(effect + ":" + key, props.getBoolean(key));
      assertEquals(0, props.getDouble("mouseStrength"), 0);
      assertEquals(0.7, props.getDouble("speed"), 0);
    }
  }

  @Test
  public void walkthroughUsesRealTargetsAndCannotBeSkippedByBack() throws Exception {
    org.json.JSONObject p = a.store.register("Обучение", "tour@example.invalid", "test-pass-3");
    a.store.activate(p);
    Track demo = new Track();
    demo.id = "demo";
    demo.title = "Песня";
    demo.artist = "Артист";
    a.homeRows = new ArrayList<>(Arrays.asList(demo));
    render("mobile-before-tour", 384, 800);
    a.tour(0);
    for (int step = 0; step < CoachMarks.TITLES.length; step++) {
      if (step > 0) a.coach.step(step);
      render("mobile-tour-layout", 384, 800);
      org.robolectric.shadows.ShadowLooper.idleMainLooper();
      a.coach
          .place(); // Layout-only Activity: explicitly execute the post-layout spotlight placement.
      assertFalse(a.coach.revealed);
      android.view.MotionEvent press =
          android.view.MotionEvent.obtain(
              0,
              0,
              android.view.MotionEvent.ACTION_UP,
              a.coach.focus.centerX(),
              a.coach.focus.centerY(),
              0);
      a.coach.onTouchEvent(press);
      press.recycle();
      assertTrue(a.coach.revealed);
      render("mobile-tour-" + step, 384, 800);
      assertNotNull(a.coach.target);
      assertTrue(a.coach.focus.width() > 0);
      a.onBackPressed();
      assertTrue(a.touring);
      assertFalse(a.store.get("tour:" + p.getString("id"), "false").equals("true"));
    }
    a.coach.step(CoachMarks.TITLES.length);
    assertFalse(a.touring);
    assertEquals("true", a.store.get("tour:" + p.getString("id"), "false"));
  }

  @Test
  public void miniArtworkOpensSongAndTabsKeepSelectedState() throws Exception {
    org.json.JSONObject profile = a.store.register("Фото", "art@example.invalid", "test-pass-3");
    a.store.activate(profile);
    a.store.put("tour:" + profile.getString("id"), "true");
    Track song = new Track();
    song.id = "art-test";
    song.title = "Название песни";
    song.artist = "Исполнитель";
    song.cover = "https://example.invalid/art.jpg";
    Bitmap bitmap = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888);
    bitmap.eraseColor(0xff8a738b);
    a.imageCache.put(song.cover, bitmap);
    a.current = song;
    a.homeRows = new ArrayList<>(Arrays.asList(song));
    a.home();
    a.refreshMini();
    assertSame(
        bitmap, ((android.graphics.drawable.BitmapDrawable) a.miniArt.getDrawable()).getBitmap());
    a.mini.performClick();
    assertEquals("now", a.page);
    a.nav.getChildAt(1).performClick();
    assertEquals("search", a.page);
    assertTrue(a.nav.getChildAt(1).isSelected());
    render("mobile-alpha4-search", 384, 800);
    a.trackMenu(song);
    TrackSheet sheet = a.trackSheet;
    assertTrue(sheet.isShowing());
    assertTrue(sheet.backgroundBlurred);
    org.robolectric.shadows.ShadowLooper.idleMainLooper(
        250, java.util.concurrent.TimeUnit.MILLISECONDS);
    View decor = sheet.getWindow().getDecorView();
    decor.measure(
        View.MeasureSpec.makeMeasureSpec(384, View.MeasureSpec.EXACTLY),
        View.MeasureSpec.makeMeasureSpec(800, View.MeasureSpec.AT_MOST));
    decor.layout(0, 0, 384, decor.getMeasuredHeight());
    Bitmap preview = Bitmap.createBitmap(384, decor.getHeight(), Bitmap.Config.ARGB_8888);
    decor.draw(new Canvas(preview));
    try (FileOutputStream out = new FileOutputStream(new File("build/qa/mobile-alpha4-menu.png"))) {
      preview.compress(Bitmap.CompressFormat.PNG, 100, out);
    }
    preview.recycle();
    sheet.dismiss();
    org.robolectric.shadows.ShadowLooper.idleMainLooper();
    assertFalse(sheet.backgroundBlurred);
    assertNull(a.trackSheet);
    WaveHero hero = new WaveHero(a, song, () -> {}, () -> {});
    hero.ready(50);
    assertTrue(hero.transport.isEnabled());
    assertTrue(hero.caption.getText().toString().contains("50"));
    LinearLayout body = a.column();
    body.addView(hero);
    a.surface(a.scroll(body));
    render("mobile-alpha4-wave", 384, 800);
    assertTrue(hero.getHeight() <= a.dp(290));
  }

  @Test
  public void customPhotoCanBeSelectedAndPresetsRestored() throws Exception {
    org.json.JSONObject profile = a.store.register("Фон", "bg@example.invalid", "test-pass-3");
    a.store.activate(profile);
    a.store.put("tour:" + profile.getString("id"), "true");
    Bitmap image = Bitmap.createBitmap(900, 600, Bitmap.Config.ARGB_8888);
    image.eraseColor(0xff617485);
    try (FileOutputStream out = new FileOutputStream(a.customBackground.file())) {
      image.compress(Bitmap.CompressFormat.JPEG, 90, out);
    }
    image.recycle();
    a.store.put("effect", "custom");
    a.applyBackground();
    assertEquals(View.VISIBLE, a.customBackground.getVisibility());
    assertEquals(View.GONE, a.background.getVisibility());
    assertEquals(View.GONE, a.vortex.getVisibility());
    assertNotNull(a.customBackground.getDrawable());
    a.backgroundEditor.show();
    assertNotNull(findText(a.content, "Выбрать свою картинку"));
    a.store.put("effect", "vortex");
    a.applyBackground();
    assertEquals(View.GONE, a.customBackground.getVisibility());
    assertEquals(View.VISIBLE, a.vortex.getVisibility());
    assertEquals("Pulse", a.getApplicationInfo().loadLabel(a.getPackageManager()).toString());
  }

  static TextView findText(View v, String value) {
    if (v instanceof TextView && ((TextView) v).getText().toString().equals(value))
      return (TextView) v;
    if (v instanceof ViewGroup)
      for (int i = 0; i < ((ViewGroup) v).getChildCount(); i++) {
        TextView found = findText(((ViewGroup) v).getChildAt(i), value);
        if (found != null) return found;
      }
    return null;
  }
}
