package fun.pulse.music;

import java.util.*;

final class Feedback {
  static boolean matches(Track a, Track b) {
    return !a.id.isEmpty() && a.id.equals(b.id) || Matching.sameRecording(a, b);
  }

  static boolean disliked(Track track, List<Track> blocked) {
    for (Track t : blocked) if (matches(track, t)) return true;
    return false;
  }

  static void filter(List<Track> rows, List<Track> blocked) {
    rows.removeIf(t -> disliked(t, blocked));
  }
}
