// Pulse Telegram sign-in. No music, passwords, or permanent user database.
import {handleSupport,cleanSupport} from './support.js';
import {avatarBase64} from './brand.js';
const json=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{'content-type':'application/json','cache-control':'no-store','x-content-type-options':'nosniff'}});
const hex=bytes=>Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
const random=()=>hex(crypto.getRandomValues(new Uint8Array(24)));
const hash=async text=>hex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text))));
function equal(a,b){if(typeof a!=='string'||typeof b!=='string'||a.length!==b.length)return false;let n=0;for(let i=0;i<a.length;i++)n|=a.charCodeAt(i)^b.charCodeAt(i);return n===0;}
async function schema(db){
 await db.prepare('CREATE TABLE IF NOT EXISTS challenges(id TEXT PRIMARY KEY, secret TEXT NOT NULL, ip TEXT, created INTEGER, expires INTEGER, user_id TEXT, name TEXT, approved INTEGER DEFAULT 0)').run();
 await db.prepare('CREATE INDEX IF NOT EXISTS challenges_ip ON challenges(ip,created)').run();
}
async function telegram(env,method,body){
 const r=await fetch('https://api.telegram.org/bot'+env.BOT_TOKEN+'/'+method,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
 if(!r.ok)throw new Error('Telegram unavailable');
 const value=await r.json();if(!value.ok)throw new Error('Telegram rejected request');return value.result;
}
export default {
 async scheduled(controller,env){if(env.DB){await env.DB.prepare('DELETE FROM challenges WHERE expires<?').bind(Math.floor(Date.now()/1000)).run();await cleanSupport(env,telegram);}},
 async fetch(request,env){
  const url=new URL(request.url);
  if(request.method==='GET'&&url.pathname==='/health')return json({service:'Pulse sign-in and support',ready:!!(env.DB&&env.BOT_TOKEN&&env.WEBHOOK_SECRET),support_ready:!!env.SUPPORT_OWNER_ID});
  if(request.method==='GET'&&url.pathname==='/avatar.png')return new Response(Uint8Array.from(atob(avatarBase64),c=>c.charCodeAt(0)),{headers:{'content-type':'image/png','cache-control':'public,max-age=86400'}});
  if(request.method==='GET'&&['/','/privacy'].includes(url.pathname)){
   const privacy=url.pathname==='/privacy';
   const content=privacy?'Pulse stores your profile, settings, favourites and listening history on your Windows computer. Local registration does not verify email and never sends your password to this service. Google sign-in requests your basic name, email and account identifier; it is verified directly on your computer. Telegram sign-in temporarily sends your Telegram name and identifier through this Cloudflare service to your computer after your explicit confirmation in the bot. We do not request your phone number, conversations or music history. Telegram login requests expire after 5 minutes and are deleted on successful delivery or during the next cleanup, normally within another 5 minutes. Cloudflare and the identity providers process connection metadata under their own policies. Support drafts are stored for up to one day. When you press Send, your description and selected Telegram attachments are delivered to the developer in Telegram. Ticket metadata and descriptions are retained for up to 30 days to route replies. Unsubmitted drafts are not sent to the developer. No advertising or tracking cookies are used by this service. To remove your local data, delete your Pulse data folder. Contact: ddemonovic65@gmail.com.':'Your music. Your space. Pulse is a Windows music player with a local profile, favourites, personalised waves and custom backgrounds. Access to music depends on the source service. This server handles sign-in and support; it does not serve music or collect your listening history.';
   return new Response('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pulse'+(privacy?' · Privacy':'')+'</title><style>body{margin:0;background:#080d10;color:#eaf2f5;font:17px/1.8 system-ui;display:grid;min-height:100vh;place-items:center}main{max-width:760px;margin:40px;padding:44px;border:1px solid #253238;border-radius:22px;background:#111a1e}small,a{color:#91bcc8}h1{font-size:48px;line-height:1.1;letter-spacing:-2px}p{color:#b4c4cc}</style><main><small>PULSE</small><h1>'+(privacy?'Privacy':'Music starts with you.')+'</h1><p>'+content+'</p><a href="'+(privacy?'/':'/privacy')+'">'+(privacy?'Pulse':'Privacy policy')+'</a></main></html>',{headers:{'content-type':'text/html; charset=utf-8','content-security-policy':"default-src 'none'; style-src 'unsafe-inline'; frame-ancestors 'none'",'x-content-type-options':'nosniff'}});
  }
  if(request.method!=='POST'||!['/challenge','/poll','/telegram','/configure'].includes(url.pathname))return json({error:'not_found'},404);
  if(!env.DB||!env.BOT_TOKEN||!env.WEBHOOK_SECRET)return json({error:'not_ready'},503);
  if(Number(request.headers.get('content-length')||0)>16384)return json({error:'too_large'},413);
  if(!request.headers.get('content-type')?.includes('application/json'))return json({error:'json_required'},415);
  if(url.pathname==='/telegram'&&!equal(request.headers.get('X-Telegram-Bot-Api-Secret-Token'),env.WEBHOOK_SECRET))return json({error:'forbidden'},403);
  if(url.pathname==='/configure'&&!equal(request.headers.get('X-Pulse-Setup'),env.WEBHOOK_SECRET))return json({error:'forbidden'},403);
  let body;try{const text=await request.text();if(text.length>16384)return json({error:'too_large'},413);body=JSON.parse(text);}catch{return json({error:'invalid_json'},400);}
  try{
   const db=env.DB;await schema(db);const now=Math.floor(Date.now()/1000);
   if(url.pathname==='/configure'){
    await telegram(env,'setWebhook',{url:'https://pulse-help.ddemonovic65.workers.dev/telegram',secret_token:env.WEBHOOK_SECRET,allowed_updates:['message','callback_query']});
    if(body.brand){
     await telegram(env,'setMyName',{name:'PulseMusic Help'});
     await telegram(env,'setMyDescription',{description:'Вход и поддержка музыкального плеера Pulse. Подтверждай вход из приложения или выбери /support, чтобы сообщить о проблеме. К обращению можно приложить фото, видео и файлы.'});
     await telegram(env,'setMyShortDescription',{short_description:'PulseMusic Help · вход в Pulse и поддержка. Поможем с музыкой, аккаунтом и оформлением.'});
     await telegram(env,'setMyCommands',{commands:[{command:'support',description:'Написать в поддержку'},{command:'status',description:'Мои обращения'},{command:'help',description:'Как работает бот'},{command:'cancel',description:'Удалить черновик обращения'}]});
     const form=new FormData();form.set('photo',JSON.stringify({type:'static',photo:'attach://avatar'}));form.set('avatar',new Blob([Uint8Array.from(atob(avatarBase64),c=>c.charCodeAt(0))],{type:'image/png'}),'pulse.png');
     const response=await fetch('https://api.telegram.org/bot'+env.BOT_TOKEN+'/setMyProfilePhoto',{method:'POST',body:form});const result=await response.json();if(!response.ok||!result.ok)throw new Error('Avatar setup failed');
    }
    const me=await telegram(env,'getMe');
    return json({ok:true,name:me.first_name,username:me.username,branded:!!body.brand,support_ready:!!env.SUPPORT_OWNER_ID});
   }
   if(url.pathname==='/challenge'){
    await db.prepare('DELETE FROM challenges WHERE expires<?').bind(now).run();
    const ip=await hash(env.WEBHOOK_SECRET+':'+Math.floor(now/86400)+':'+(request.headers.get('CF-Connecting-IP')||'unknown'));
    const rate=await db.prepare('SELECT COUNT(*) AS n FROM challenges WHERE ip=? AND created>?').bind(ip,now-600).first();
    if(rate.n>=10)return json({error:'rate_limit'},429);
    const id=random(),secret=random();
    await db.prepare('INSERT INTO challenges(id,secret,ip,created,expires) VALUES(?,?,?,?,?)').bind(id,await hash(secret),ip,now,now+300).run();
    return json({id,secret,url:'https://t.me/PulseMusicHelpBot?start='+id,expires_in:300});
   }
   if(url.pathname==='/poll'){
    if(!/^[a-f0-9]{48}$/.test(body.id||'')||!/^[a-f0-9]{48}$/.test(body.secret||''))return json({error:'bad_request'},400);
    const digest=await hash(body.secret);
    const row=await db.prepare('SELECT secret,expires,approved FROM challenges WHERE id=?').bind(body.id).first();
    if(!row||row.expires<now||!equal(row.secret,digest))return json({cancelled:true},200);
    if(!row.approved)return json({pending:true});
    // DELETE RETURNING makes profile delivery single use even for simultaneous polling.
    const identity=await db.prepare('DELETE FROM challenges WHERE id=? AND secret=? AND approved=1 AND expires>=? RETURNING user_id,name').bind(body.id,digest,now).first();
    return identity?json({identity:{provider_id:identity.user_id,name:identity.name,email:''}}):json({cancelled:true});
   }
   if(await handleSupport(body,env,telegram))return json({ok:true});
   const msg=body.message,callback=body.callback_query;
   if(msg&&msg.chat?.type==='private'&&!msg.from?.is_bot){
    const match=/^\/start(?:@\w+)?\s+([a-f0-9]{48})$/.exec(msg.text||'');
    if(!match){await telegram(env,'sendMessage',{chat_id:msg.chat.id,text:'Открой Pulse и нажми «Войти через Telegram». Здесь появится запрос подтверждения.'});return json({ok:true});}
    const id=match[1];const row=await db.prepare('SELECT expires,user_id FROM challenges WHERE id=?').bind(id).first();
    if(!row||row.expires<now||(row.user_id&&row.user_id!==String(msg.from.id))){await telegram(env,'sendMessage',{chat_id:msg.chat.id,text:'Этот запрос недоступен. Начни вход заново в Pulse.'});return json({ok:true});}
    const name=[msg.from.first_name,msg.from.last_name].filter(Boolean).join(' ').slice(0,80)||msg.from.username||'Слушатель';
    await db.prepare('UPDATE challenges SET user_id=?,name=? WHERE id=? AND (user_id IS NULL OR user_id=?)').bind(String(msg.from.id),name,id,String(msg.from.id)).run();
    await telegram(env,'sendMessage',{chat_id:msg.chat.id,text:'Вход в Pulse\n\nЗапрос: '+id.slice(0,8).toUpperCase()+'\n\nПодтверждай, только если ты сейчас нажал вход в своём Pulse и код совпадает. Приложение получит твоё имя и ID Telegram. Переписка и номер телефона не передаются.',reply_markup:{inline_keyboard:[[{text:'Войти в Pulse',callback_data:'yes:'+id},{text:'Отмена',callback_data:'no:'+id}]]}});
   }else if(callback&&callback.message?.chat?.type==='private'&&!callback.from?.is_bot){
    const match=/^(yes|no):([a-f0-9]{48})$/.exec(callback.data||'');
    if(match){
     const [_,choice,id]=match;
     let result;
     if(choice==='yes')result=await db.prepare('UPDATE challenges SET approved=1 WHERE id=? AND user_id=? AND expires>=? AND approved=0').bind(id,String(callback.from.id),now).run();
     else result=await db.prepare('DELETE FROM challenges WHERE id=? AND user_id=?').bind(id,String(callback.from.id)).run();
     const changed=result.meta.changes>0;
     await telegram(env,'answerCallbackQuery',{callback_query_id:callback.id,text:changed?(choice==='yes'?'Вход подтверждён. Вернись в Pulse.':'Вход отменён.'):'Запрос уже завершён или истёк.'});
     await telegram(env,'editMessageReplyMarkup',{chat_id:callback.message.chat.id,message_id:callback.message.message_id,reply_markup:{inline_keyboard:[]}});
    }
   }
   return json({ok:true});
  }catch{return json({error:'temporarily_unavailable'},503);}
 }
};
