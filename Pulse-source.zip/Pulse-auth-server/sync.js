// Account-scoped favourite events. Session credentials are issued only after bot approval.
const hex=b=>Array.from(b,x=>x.toString(16).padStart(2,'0')).join('');
const digest=async s=>hex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s))));
const reply=(v,status=200)=>Response.json(v,{status,headers:{'cache-control':'no-store','x-content-type-options':'nosniff'}});
const ready=new WeakSet();
export async function syncSchema(db){
 if(ready.has(db))return;
 await db.prepare('CREATE TABLE IF NOT EXISTS sync_sessions(token TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires INTEGER NOT NULL)').run();
 await db.prepare('CREATE TABLE IF NOT EXISTS favourite_events(revision INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,op TEXT NOT NULL,track_id TEXT NOT NULL,liked INTEGER NOT NULL,track TEXT NOT NULL,UNIQUE(user_id,op))').run();
 await db.prepare('CREATE INDEX IF NOT EXISTS favourite_user_revision ON favourite_events(user_id,revision)').run();
 ready.add(db);
}
export async function issueSession(db,user,now){
 await syncSchema(db);
 const token=hex(crypto.getRandomValues(new Uint8Array(32))),expires=now+90*86400;
 await db.prepare('INSERT INTO sync_sessions(token,user_id,expires) VALUES(?,?,?)').bind(await digest(token),user,expires).run();
 return {token,expires};
}
export function cleanTrack(raw){
 if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('track');
 const source=raw.source||'yandex',id=String(raw.id||'');
 if(!['yandex','soundcloud','audius'].includes(source)||!id||id.length>160||!/^[-\w:]+$/.test(id))throw Error('track');
 if(source==='soundcloud'&&!/^sc:\d+$/.test(id)||source==='audius'&&!/^audius:[\w-]+$/.test(id)||source==='yandex'&&!/^\d+(?::\d+)?$/.test(id))throw Error('id');
 const t={id,source,duration:Math.max(0,Math.min(86400000,Number(raw.duration)||0))};
 for(const k of ['title','artist','artist_id','genre'])t[k]=String(raw[k]||'').slice(0,k==='title'||k==='artist'?500:160);
 for(const k of ['url','artist_url','cover']){
  t[k]='';if(typeof raw[k]!=='string'||raw[k].length>2048)continue;
  try{const u=new URL(raw[k]);if(u.protocol==='https:'&&!u.username&&!u.password&&!u.search&&!u.hash)t[k]=u.href;}catch{}
 }
 // No signed streams, service tokens, local file paths or arbitrary object fields leave the device.
 return t;
}
export async function handleSync(request,env){
 if(request.method!=='POST')return reply({error:'method'},405);
 if(!env.DB)return reply({error:'not_ready'},503);
 const auth=request.headers.get('authorization')||'';
 if(!/^Bearer [a-f0-9]{64}$/.test(auth))return reply({error:'sign_in_required'},401);
 await syncSchema(env.DB);
 const now=Math.floor(Date.now()/1000),session=await env.DB.prepare('SELECT user_id FROM sync_sessions WHERE token=? AND expires>?').bind(await digest(auth.slice(7)),now).first();
 if(!session)return reply({error:'sign_in_required'},401);
 if(Number(request.headers.get('content-length')||0)>1048576)return reply({error:'too_large'},413);
 let body,ops;
 try{
  const text=await request.text();if(text.length>1048576)return reply({error:'too_large'},413);
  body=JSON.parse(text);if(!Array.isArray(body.ops)||body.ops.length>100)throw Error();
  if(!Number.isSafeInteger(body.cursor)||body.cursor<0)throw Error();
  ops=body.ops.map(o=>{if(!/^[a-f0-9-]{36}$/.test(o.op)||typeof o.liked!=='boolean')throw Error();return {...o,track:cleanTrack(o.track)};});
 }catch{return reply({error:'bad_request'},400);}
 // At most 100 bound parameters per statement; stay below the Free invocation query limit.
 const writes=[];
 for(let i=0;i<ops.length;i+=20){
  const part=ops.slice(i,i+20);
  writes.push(env.DB.prepare('INSERT OR IGNORE INTO favourite_events(user_id,op,track_id,liked,track) VALUES '+part.map(()=>'(?,?,?,?,?)').join(',')).bind(...part.flatMap(o=>[session.user_id,o.op,o.track.id,o.liked?1:0,JSON.stringify(o.track)])));
 }
 if(writes.length)await env.DB.batch(writes);
 const result=await env.DB.prepare('SELECT revision,track_id,liked,track FROM favourite_events WHERE user_id=? AND revision>? ORDER BY revision LIMIT 200').bind(session.user_id,body.cursor).all();
 const events=result.results.map(e=>({revision:e.revision,liked:!!e.liked,track:JSON.parse(e.track)}));
 return reply({ack:ops.map(o=>o.op),events,cursor:events.length?events.at(-1).revision:body.cursor,more:events.length===200});
}
