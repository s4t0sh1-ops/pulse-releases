const categories={audio:'Не играет музыка',login:'Вход и аккаунт',search:'Поиск и каталог',import:'Перенос музыки',design:'Интерфейс',background:'Фон и нагрузка',update:'Обновление Pulse',other:'Другой вопрос'};
export const supportPrompts={
 audio:'Какая песня не играет и что происходит после нажатия ▶?\n\nМожно написать так:\nТрек или ссылка: …\nЧто происходит: тишина / вечная загрузка / прерывается\nДругие песни играют: да / нет\n\nЕсли есть ошибка — приложи её скриншот.',
 login:'Каким способом пытаешься войти и на каком шаге остановился?\n\nМожно написать так:\nВход через: Google / Telegram / почту\nНажимаю: …\nВместо входа вижу: …\n\nПриложи скрин ошибки. Пароль и коды подтверждения не присылай.',
 search:'Что ищешь и что Pulse показывает вместо нужного результата?\n\nМожно написать так:\nВ поиске пишу: …\nНужны трек и исполнитель: …\nPulse показывает: ничего / другую песню / другого исполнителя\n\nЕсли есть ссылка на нужную песню — добавь её.',
 import:'Откуда переносишь музыку и на каком шаге возникла проблема?\n\nМожно написать так:\nПереношу из: Яндекса / SoundCloud / файла\nСсылка на публичный профиль или плейлист: …\nПроблема: кнопка не работает / перенеслась только часть / появились дубликаты\n\nТокен аккаунта и закрытые ссылки не присылай.',
 design:'На каком экране текст или кнопки выглядят неправильно?\n\nМожно написать так:\nЭкран: вход / профиль / плеер / другое\nЧто не так: текст обрезан / кнопки налезают / плохо видно\n\nПриложи скриншот всего окна. Если знаешь масштаб Windows, укажи 100%, 125% или 150%.',
 background:'Какой фон выбрал и что с ним не так?\n\nМожно написать так:\nФон: …\nПроблема: чёрный экран / тормозит / настройки не применяются\nКогда начинается: сразу / во время музыки / после изменения настроек\n\nЕсли тормозит, напиши модель компьютера, если знаешь.',
 update:'На каком этапе остановилось обновление?\n\nМожно написать так:\nВерсия Pulse сейчас: … (если знаешь)\nЭтап: проверка / скачивание / установка / запуск\nЧто написано на экране: …\n\nПриложи скрин ошибки. Удалять профиль или переустанавливать Windows не нужно.',
 other:'Расскажи своими словами, что не получается или что хочешь предложить.\n\nЕсли удобно, начни так:\nХочу: …\nСейчас получается: …\n\nМожно добавить фото или видео. Ничего заполнять по форме не обязательно.'
};
export async function supportSchema(db){
 await db.prepare('CREATE TABLE IF NOT EXISTS support_drafts(chat_id TEXT PRIMARY KEY, category TEXT, description TEXT, media TEXT, name TEXT, expires INTEGER)').run();
 await db.prepare('CREATE TABLE IF NOT EXISTS support_tickets(id TEXT PRIMARY KEY, chat_id TEXT, category TEXT, description TEXT, media TEXT, name TEXT, created INTEGER, status TEXT, delivered INTEGER DEFAULT -1)').run();
 await db.prepare('CREATE INDEX IF NOT EXISTS support_user_date ON support_tickets(chat_id,created)').run();
 await db.prepare('CREATE TABLE IF NOT EXISTS support_replies(owner_message INTEGER PRIMARY KEY, ticket TEXT, chat_id TEXT, created INTEGER)').run();
}
function menu(){return {inline_keyboard:[[{text:'Не играет музыка',callback_data:'sup:audio'}],[{text:'Не могу войти',callback_data:'sup:login'},{text:'Не нахожу песню',callback_data:'sup:search'}],[{text:'Перенос музыки',callback_data:'sup:import'},{text:'Текст и кнопки',callback_data:'sup:design'}],[{text:'Фон и нагрузка',callback_data:'sup:background'},{text:'Обновление',callback_data:'sup:update'}],[{text:'Другая проблема / идея',callback_data:'sup:other'}]]};}
function actions(){return {inline_keyboard:[[{text:'Отправить обращение',callback_data:'sup:send'}],[{text:'Отмена',callback_data:'sup:cancel'}]]};}
export async function deliverSupport(env,api,ticket){
 const db=env.DB,owner=String(env.SUPPORT_OWNER_ID||'');if(!owner)throw new Error('Support not configured');
 const media=JSON.parse(ticket.media||'[]');let delivered=ticket.delivered;
 if(delivered<0){
  const msg=await api(env,'sendMessage',{chat_id:owner,text:'PULSEMUSIC · ПОДДЕРЖКА\n#'+ticket.id+' · '+ticket.category+'\nОт: '+ticket.name+'\n\n'+ticket.description+'\n\nОтветь на это сообщение, чтобы написать пользователю.'});
  await db.prepare('INSERT OR REPLACE INTO support_replies(owner_message,ticket,chat_id,created) VALUES(?,?,?,?)').bind(msg.message_id,ticket.id,ticket.chat_id,ticket.created).run();
  delivered=0;await db.prepare('UPDATE support_tickets SET delivered=0 WHERE id=?').bind(ticket.id).run();
 }
 for(let i=delivered;i<media.length;i++){
  const msg=await api(env,'copyMessage',{chat_id:owner,from_chat_id:ticket.chat_id,message_id:media[i]});
  await db.prepare('INSERT OR REPLACE INTO support_replies(owner_message,ticket,chat_id,created) VALUES(?,?,?,?)').bind(msg.message_id,ticket.id,ticket.chat_id,ticket.created).run();
  await db.prepare('UPDATE support_tickets SET delivered=? WHERE id=?').bind(i+1,ticket.id).run();
 }
 await db.prepare("UPDATE support_tickets SET status='sent' WHERE id=?").bind(ticket.id).run();
 await api(env,'sendMessage',{chat_id:ticket.chat_id,text:'Обращение #'+ticket.id+' отправлено. Ответ придёт в этот чат. Статус: /status',reply_markup:{inline_keyboard:[[{text:'Другой вопрос',callback_data:'sup:menu'}]]}});
}
export async function cleanSupport(env,api){
 const db=env.DB;await supportSchema(db);const now=Math.floor(Date.now()/1000);
 await db.prepare('DELETE FROM support_drafts WHERE expires<?').bind(now).run();
 await db.prepare('DELETE FROM support_replies WHERE created<?').bind(now-30*86400).run();
 await db.prepare('DELETE FROM support_tickets WHERE created<?').bind(now-30*86400).run();
 const waiting=await db.prepare("SELECT * FROM support_tickets WHERE status='pending' LIMIT 3").all();
 for(const ticket of waiting.results||[])try{await deliverSupport(env,api,ticket);}catch{}
}
export async function handleSupport(update,env,api){
 const msg=update.message,cb=update.callback_query;const user=msg?.from||cb?.from;
 const chat=msg?.chat||cb?.message?.chat;if(!user||user.is_bot||chat?.type!=='private')return false;
 const text=msg?.text||'',command=text.split(/\s/)[0];const data=cb?.data||'';
 const chatId=String(chat.id),owner=String(env.SUPPORT_OWNER_ID||''),db=env.DB,now=Math.floor(Date.now()/1000);
 if(text.match(/^\/start(?:@\w+)?\s+[a-f0-9]{48}$/)||data.match(/^(yes|no):/))return false;
 await supportSchema(db);
 const send=(text,reply_markup)=>api(env,'sendMessage',{chat_id:chat.id,text,...(reply_markup?{reply_markup}:{})});
 if(chatId===owner&&msg?.reply_to_message){
  const ref=await db.prepare('SELECT ticket,chat_id FROM support_replies WHERE owner_message=?').bind(msg.reply_to_message.message_id).first();
  if(ref){
   await api(env,'copyMessage',{chat_id:ref.chat_id,from_chat_id:chat.id,message_id:msg.message_id});
   await db.prepare("UPDATE support_tickets SET status='answered' WHERE id=?").bind(ref.ticket).run();
   await send('Ответ отправлен по обращению #'+ref.ticket);return true;
  }
 }
 if(command==='/status'){
  const tickets=await db.prepare('SELECT id,category,status FROM support_tickets WHERE chat_id=? ORDER BY created DESC LIMIT 5').bind(chatId).all();
  await send((tickets.results||[]).map(t=>'#'+t.id+' · '+t.category+' · '+({pending:'отправляется',sent:'у разработчика',answered:'есть ответ'}[t.status]||t.status)).join('\n')||'У тебя пока нет обращений.',menu());return true;
 }
 if(command==='/support'||command==='/help'||(command==='/start'&&!/^\/start\s+[a-f0-9]{48}$/.test(text))||data==='sup:menu'){
  await send((env.SUPPORT_ONLY?'PulseMusic Help':'PulseMusic')+'\n\nВыбери тему обращения. После описания можно прикрепить фото, видео или файл. Материалы передадим разработчику только после кнопки «Отправить». '+(env.SUPPORT_ONLY?'':'Для входа открой Pulse и выбери Telegram.'),menu());
  if(cb)await api(env,'answerCallbackQuery',{callback_query_id:cb.id});return true;
 }
 if(command==='/cancel'||data==='sup:cancel'){
  await db.prepare('DELETE FROM support_drafts WHERE chat_id=?').bind(chatId).run();await send('Черновик удалён. Можно начать заново.',menu());
  if(cb)await api(env,'answerCallbackQuery',{callback_query_id:cb.id});return true;
 }
 if(data.startsWith('sup:')&&categories[data.slice(4)]){
  const category=categories[data.slice(4)],name=[user.first_name,user.last_name].filter(Boolean).join(' ').slice(0,100)||'Пользователь';
  await db.prepare('INSERT OR REPLACE INTO support_drafts(chat_id,category,description,media,name,expires) VALUES(?,?,?,?,?,?)').bind(chatId,category,'','[]',name,now+86400).run();
  await api(env,'answerCallbackQuery',{callback_query_id:cb.id});
  await send(category+'\n\n'+supportPrompts[data.slice(4)]+'\n\nНапиши одним сообщением — шаблон только подсказка. Затем можно добавить вложения и нажать «Отправить обращение».',{inline_keyboard:[[{text:'Выбрать другую тему',callback_data:'sup:menu'}],[{text:'Отмена',callback_data:'sup:cancel'}]]});return true;
 }
 const draft=await db.prepare('SELECT * FROM support_drafts WHERE chat_id=? AND expires>=?').bind(chatId,now).first();
 if(data==='sup:send'){
  await api(env,'answerCallbackQuery',{callback_query_id:cb.id});
  if(!draft||draft.description.length<10){await send('Сначала добавь описание проблемы.',menu());return true;}
  const rate=await db.prepare('SELECT COUNT(*) AS n FROM support_tickets WHERE chat_id=? AND created>?').bind(chatId,now-3600).first();
  if(rate.n>=3){await send('Уже отправлено три обращения за час. Дождись ответа или попробуй позже.');return true;}
  // Atomically claim the draft so repeated button taps do not create duplicate tickets.
  const claimed=await db.prepare('DELETE FROM support_drafts WHERE chat_id=? RETURNING *').bind(chatId).first();
  if(!claimed){await send('Этот черновик уже отправлен. /status');return true;}
  const id=crypto.randomUUID().slice(0,8).toUpperCase();
  await db.prepare('INSERT INTO support_tickets(id,chat_id,category,description,media,name,created,status,delivered) VALUES(?,?,?,?,?,?,?,?,?)').bind(id,chatId,claimed.category,claimed.description,claimed.media,claimed.name,now,'pending',-1).run();
  const ticket=await db.prepare('SELECT * FROM support_tickets WHERE id=?').bind(id).first();
  try{await deliverSupport(env,api,ticket);}catch{await send('Обращение #'+id+' принято. Доставим его разработчику, когда соединение восстановится.');}
  return true;
 }
 if(msg&&draft){
  const media=JSON.parse(draft.media||'[]'),attachment=!!(msg.photo||msg.video||msg.document||msg.animation||msg.voice||msg.audio);
  let description=draft.description,addition=(msg.text||msg.caption||'').trim();
  if(addition.startsWith('/')){await send('Для отмены напиши /cancel. Для отправки нажми кнопку ниже.',actions());return true;}
  if(addition){description=(description?description+'\n\n':'')+addition;if(description.length>3500){await send('Описание слишком длинное. Оставь до 3500 символов.');return true;}}
  if(attachment){if(media.length>=10){await send('В одном обращении можно прикрепить до 10 сообщений с материалами.',actions());return true;}media.push(msg.message_id);}
  await db.prepare('UPDATE support_drafts SET description=?,media=?,expires=? WHERE chat_id=?').bind(description,JSON.stringify(media),now+86400,chatId).run();
  if(!description||description.length<10){await send(attachment?'Вложение сохранено. Теперь напиши, что случилось — достаточно одного-двух предложений.':'Коротко опиши, что случилось — достаточно одного-двух предложений.');return true;}
  await send('Готово к отправке · '+draft.category+'\n\n'+(description.length>900?description.slice(0,900)+'…':description)+'\n\nВложений: '+media.length+' / 10\nМожно добавить ещё материалы или отправить обращение.',actions());return true;
 }
 if(msg){await send('Выбери тему, чтобы написать в поддержку.',menu());return true;}
 return false;
}
