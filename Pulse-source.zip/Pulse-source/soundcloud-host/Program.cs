using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
class Host : Form {
 [DllImport("kernel32.dll")] static extern uint SetErrorMode(uint mode);
 protected override bool ShowWithoutActivation {get{return true;}}
 protected override CreateParams CreateParams {get{var p=base.CreateParams;if(parentWindow!=IntPtr.Zero){p.Parent=parentWindow;p.Style=(p.Style&~unchecked((int)0x80000000))|0x40000000;p.ExStyle|=0x08000080;}return p;}}
 [DllImport("user32.dll")] static extern IntPtr SetParent(IntPtr child,IntPtr parent);
 [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr window,out RECT rect);
 [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr window,int index);
 [DllImport("user32.dll")] static extern int SetWindowLong(IntPtr window,int index,int value);
 [DllImport("user32.dll")] static extern bool IsWindow(IntPtr window);
 [StructLayout(LayoutKind.Sequential)] struct RECT {public int left,top,right,bottom;}
 readonly IntPtr parentWindow; readonly string cache; readonly WebView2 browser=new WebView2();
 readonly JavaScriptSerializer serializer=new JavaScriptSerializer(); readonly object outputLock=new object();
 readonly System.Windows.Forms.Timer resizeTimer=new System.Windows.Forms.Timer(); string tag="";
 Host(IntPtr parent,string folder){
  parentWindow=parent;cache=folder;FormBorderStyle=FormBorderStyle.None;ShowInTaskbar=false;StartPosition=FormStartPosition.Manual;BackColor=System.Drawing.Color.FromArgb(21,21,26);
  Controls.Add(browser);browser.Dock=DockStyle.Fill;
  Shown+=async delegate {
   SetParent(Handle,parentWindow);SetWindowLong(Handle,-16,(GetWindowLong(Handle,-16)&~unchecked((int)0x80000000))|0x40000000);resizeTimer.Interval=120;resizeTimer.Tick+=delegate{RECT rect;if(!IsWindow(parentWindow)){Close();return;}if(GetClientRect(parentWindow,out rect))SetBounds(0,0,Math.Max(1,rect.right),Math.Max(1,rect.bottom));};resizeTimer.Start();
   try {
    var options=new CoreWebView2EnvironmentOptions("--autoplay-policy=no-user-gesture-required");
    var environment=await CoreWebView2Environment.CreateAsync(null,cache,options);
    await browser.EnsureCoreWebView2Async(environment);
    browser.CoreWebView2.Settings.AreDefaultContextMenusEnabled=false;
    browser.CoreWebView2.Settings.IsStatusBarEnabled=false;
    browser.CoreWebView2.WebMessageReceived+=delegate(object sender,CoreWebView2WebMessageReceivedEventArgs args){lock(outputLock){Console.WriteLine(args.WebMessageAsJson);Console.Out.Flush();}};
    browser.CoreWebView2.NewWindowRequested+=delegate(object sender,CoreWebView2NewWindowRequestedEventArgs args){args.Handled=true;Uri uri;if(Uri.TryCreate(args.Uri,UriKind.Absolute,out uri)&&uri.Scheme=="https"&&(uri.Host=="soundcloud.com"||uri.Host.EndsWith(".soundcloud.com")))System.Diagnostics.Process.Start(args.Uri);};
    Send(new {host_ready=true});new Thread(ReadCommands){IsBackground=true}.Start();
   }catch{Send(new {host_error=true});Close();}
  };
 }
 void Send(object value){lock(outputLock){Console.WriteLine(serializer.Serialize(value));Console.Out.Flush();}}
 void ReadCommands(){
  try{string line;while((line=Console.ReadLine())!=null){var command=serializer.Deserialize<Dictionary<string,object>>(line);BeginInvoke(new Action(()=>Execute(command)));}}
  catch{}try{BeginInvoke(new Action(Close));}catch{}
 }
 async void Execute(Dictionary<string,object> command){
  try {
   var op=Convert.ToString(command["op"]);
   if(op=="load"){tag=Convert.ToString(command["tag"]);browser.CoreWebView2.NavigateToString(Convert.ToString(command["html"]));}
   if(op=="script")await browser.CoreWebView2.ExecuteScriptAsync(Convert.ToString(command["script"]));
   if(op=="close")Close();
  }catch{Send(new {tag=tag,type="error"});}
 }
 [STAThread] static void Main(string[] args){
  SetErrorMode(0x0001|0x0002|0x8000);
  try {
   Console.SetIn(new StreamReader(Console.OpenStandardInput(),new UTF8Encoding(false)));
   Console.SetOut(new StreamWriter(Console.OpenStandardOutput(),new UTF8Encoding(false)){AutoFlush=true});
   Console.SetError(new StreamWriter(Console.OpenStandardError(),new UTF8Encoding(false)){AutoFlush=true});
   Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
   Application.ThreadException+=delegate{try{Console.WriteLine("{\"host_error\":true}");}catch{}Application.Exit();};
   AppDomain.CurrentDomain.UnhandledException+=delegate{Environment.Exit(1);};
   if(args.Length<2)return;IntPtr parent=new IntPtr(long.Parse(args[0]));Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new Host(parent,args[1]));
  }catch{try{Console.WriteLine("{\"host_error\":true}");}catch{}Environment.ExitCode=1;}
 }
}
