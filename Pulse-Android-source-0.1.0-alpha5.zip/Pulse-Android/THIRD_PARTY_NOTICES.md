# Dependencies and licenses

Original Pulse Android code: MIT, see LICENSE.txt. This does not relicense third-party code.

- AndroidX Media3 1.6.1, AndroidX Core 1.15.0 and their AndroidX dependencies: Apache License 2.0, https://android.googlesource.com/platform/frameworks/support/ .
- Guava (transitive): Apache License 2.0, https://github.com/google/guava .
- Android platform/WebView are supplied by the device. SoundCloud's online Widget API remains SoundCloud's service, https://developers.soundcloud.com/docs/api/html5-widget . No SoundCloud audio recordings are bundled.
- Manrope variable font: SIL Open Font License, included at app/src/main/assets/fonts/OFL.txt.
- React Bits background components: original license preserved at app/src/main/assets/backgrounds/REACT_BITS_LICENSE.txt (MIT + Commons Clause). Components are the same local sources as the desktop distribution.
- React/React DOM 18.3.1: MIT, complete notices preserved beside the bundled background assets.
- Gradle Wrapper 8.11.1 and Android Gradle Plugin: Apache License 2.0, https://github.com/gradle/gradle and https://android.googlesource.com/platform/tools/base/ .
- Test-only dependencies: JUnit, Robolectric, AndroidX Test and org.json retain their respective licenses; they are not included as application features in the APK.

No private Google client configuration, Telegram bot token, Cloudflare deployment credential or release-signing key is included in this project or APK. Native Android key material used for local debug signing is not part of the source archive.
