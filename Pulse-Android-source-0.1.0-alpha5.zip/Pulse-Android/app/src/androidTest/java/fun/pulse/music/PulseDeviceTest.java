package fun.pulse.music;

import static org.junit.Assert.*;

import android.app.Instrumentation;
import android.content.*;
import android.graphics.Bitmap;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.*;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;

/**
 * Device-only integration test. It uses a private test installation and generated audio, never the
 * owner's data.
 */
@RunWith(AndroidJUnit4.class)
public class PulseDeviceTest {
  Instrumentation instrumentation;
  Context context;
  MainActivity activity;

  @Before
  public void setUp() {
    instrumentation = InstrumentationRegistry.getInstrumentation();
    context = instrumentation.getTargetContext();
    context.getSharedPreferences("pulse-v1", 0).edit().clear().commit();
    Intent launch = new Intent(context, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    activity = (MainActivity) instrumentation.startActivitySync(launch);
    instrumentation.waitForIdleSync();
  }

  @After
  public void tearDown() {
    if (activity != null) instrumentation.runOnMainSync(() -> activity.finish());
  }

  void shot(String name) throws Exception {
    instrumentation.waitForIdleSync();
    Thread.sleep(500);
    Bitmap b = instrumentation.getUiAutomation().takeScreenshot();
    assertNotNull(b);
    File folder = new File(context.getExternalFilesDir(null), "qa");
    folder.mkdirs();
    try (FileOutputStream out = new FileOutputStream(new File(folder, name + ".png"))) {
      b.compress(Bitmap.CompressFormat.PNG, 100, out);
    }
    b.recycle();
  }

  List<TextView> texts(View root) {
    List<TextView> out = new ArrayList<>();
    if (root instanceof TextView) out.add((TextView) root);
    if (root instanceof ViewGroup)
      for (int i = 0; i < ((ViewGroup) root).getChildCount(); i++)
        out.addAll(texts(((ViewGroup) root).getChildAt(i)));
    return out;
  }

  @Test
  public void firstLaunchResponsiveAuthAndLogout() throws Exception {
    assertEquals("auth", activity.page);
    assertEquals(View.GONE, activity.nav.getVisibility());
    assertEquals(View.GONE, activity.mini.getVisibility());
    shot("01-login");
    instrumentation.runOnMainSync(() -> activity.auth(true));
    shot("02-register");
    JSONObject p = activity.store.register("Слушатель", "listener@example.invalid", "test-pass-1");
    assertFalse(activity.store.get("profiles", "").contains("test-pass-1"));
    try {
      activity.store.login("listener@example.invalid", "wrong");
      fail("wrong password accepted");
    } catch (Exception expected) {
    }
    activity.store.activate(p);
    activity.store.put("tour:" + p.getString("id"), "true");
    Track t = new Track();
    t.id = "qa";
    t.title = "Название трека";
    t.artist = "Исполнитель";
    t.duration = 180000;
    t.source = "local";
    instrumentation.runOnMainSync(
        () -> {
          activity.homeRows = new ArrayList<>(Arrays.asList(t));
          activity.home();
        });
    shot("03-home");
    instrumentation.runOnMainSync(() -> activity.profile());
    shot("04-profile");
    instrumentation.runOnMainSync(
        () -> {
          for (TextView v : texts(activity.content))
            if (v.getText().toString().equals("Выйти из профиля")) {
              v.performClick();
              break;
            }
        });
    Thread.sleep(400);
    assertFalse(activity.store.loggedIn());
    assertEquals("auth", activity.page);
    JSONObject old = activity.store.login("listener@example.invalid", "test-pass-1");
    assertEquals(p.getString("id"), old.getString("id"));
    activity.store.activate(old);
    instrumentation.runOnMainSync(() -> activity.appearance());
    shot("05-appearance");
    instrumentation.runOnMainSync(
        () -> {
          activity.current = t;
          activity.nowPlaying();
        });
    shot("06-now-playing");
  }

  @Test
  public void nativePlaybackPauseSeekAndSession() throws Exception {
    JSONObject p = activity.store.register("Test", "native@example.invalid", "test-pass-2");
    activity.store.activate(p);
    activity.store.put("tour:" + p.getString("id"), "true");
    File wav = new File(context.getCacheDir(), "pulse-original-test.wav");
    writeWave(wav);
    Track t = new Track();
    t.id = "local:qa";
    t.source = "local";
    t.title = "Pulse QA tone";
    t.artist = "Generated test signal";
    t.url = android.net.Uri.fromFile(wav).toString();
    t.duration = 10000;
    long until = System.currentTimeMillis() + 15000;
    while (activity.player == null && System.currentTimeMillis() < until) Thread.sleep(100);
    assertNotNull(activity.player);
    instrumentation.runOnMainSync(
        () -> {
          activity.play(t, Arrays.asList(t));
          activity.nowPlaying();
        });
    until = System.currentTimeMillis() + 15000;
    while (activity.loading && System.currentTimeMillis() < until) Thread.sleep(100);
    Thread.sleep(1200);
    final long[] position = {0};
    instrumentation.runOnMainSync(
        () -> {
          assertTrue(activity.player.isPlaying());
          position[0] = activity.position();
          activity.toggle();
        });
    assertTrue(position[0] > 0);
    instrumentation.runOnMainSync(
        () -> {
          assertFalse(activity.player.isPlaying());
          activity.seek(4000);
          activity.saveSession();
        });
    assertTrue(activity.store.object("session").optLong("position") >= 3900);
    instrumentation.runOnMainSync(() -> activity.toggle());
    Thread.sleep(300);
    instrumentation.runOnMainSync(() -> assertTrue(activity.player.isPlaying()));
    shot("07-native-playback");
    instrumentation.runOnMainSync(() -> activity.stopAudio());
  }

  static void writeWave(File file) throws Exception {
    int rate = 22050, count = rate * 10;
    ByteBuffer b = ByteBuffer.allocate(44 + count * 2).order(ByteOrder.LITTLE_ENDIAN);
    b.put("RIFF".getBytes("US-ASCII"))
        .putInt(36 + count * 2)
        .put("WAVEfmt ".getBytes("US-ASCII"))
        .putInt(16)
        .putShort((short) 1)
        .putShort((short) 1)
        .putInt(rate)
        .putInt(rate * 2)
        .putShort((short) 2)
        .putShort((short) 16)
        .put("data".getBytes("US-ASCII"))
        .putInt(count * 2);
    for (int i = 0; i < count; i++)
      b.putShort((short) (Math.sin(2 * Math.PI * 440 * i / rate) * 1500));
    try (FileOutputStream out = new FileOutputStream(file)) {
      out.write(b.array());
    }
  }
}
