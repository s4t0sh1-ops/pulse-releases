package fun.pulse.music;

import static org.junit.Assert.*;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;

/** Executes against Android's own ICU Pattern, rather than host JVM regex. */
@RunWith(AndroidJUnit4.class)
public class MatchingDeviceTest {
  @Test
  public void unicodeVersionMatchingWorksOnAndroid() {
    assertTrue(Matching.tags("Ночь (ремикс)").contains("remix"));
    assertTrue(Matching.tags("Track (slowed)").contains("slowed"));
    assertEquals("ночь", Matching.core("Артист Ночь Official Audio", "артист"));
    Track a = new Track(), b = new Track();
    a.artist = b.artist = "CODE80";
    a.title = b.title = "NewL";
    assertTrue(Matching.sameRecording(a, b));
  }
}
