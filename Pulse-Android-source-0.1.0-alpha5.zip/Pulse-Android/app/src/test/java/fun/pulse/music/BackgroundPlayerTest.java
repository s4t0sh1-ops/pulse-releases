package fun.pulse.music;

import static org.junit.Assert.*;

import android.content.Context;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import org.json.JSONObject;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;

/**
 * Framework simulation: transport state, locks and persistence. This is not a real-device streaming
 * test.
 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public class BackgroundPlayerTest {
  HybridPlayer player;

  @Before
  public void setup() {
    Context c = RuntimeEnvironment.getApplication();
    c.getSharedPreferences("pulse-v1", 0).edit().clear().commit();
    player = new HybridPlayer(c, new ExoPlayer.Builder(c).build());
  }

  @After
  public void close() {
    player.release();
  }

  void cloudTrack() {
    Track t = new Track();
    t.id = "sc:test";
    t.title = "Track";
    t.artist = "Artist";
    t.source = "soundcloud";
    t.duration = 180000;
    t.url = "https://soundcloud.com/artist/track";
    player.queue.add(t);
    player.cloud = true;
    player.ready = true;
    player.cloudDuration = 180000;
    player.tag = "test";
    player.initialized = true;
  }

  @Test
  public void readyWithoutSoundTimesOutAndLateEventCannotRestart() throws Exception {
    cloudTrack();
    player.wanted = true;
    assertTrue(player.waitingForAudio());
    player.armStartupTimeout(player.generation, 1000);
    Shadows.shadowOf(android.os.Looper.getMainLooper()).idleFor(java.time.Duration.ofSeconds(2));
    assertNotNull(player.failure);
    assertFalse(player.resolving);
    assertFalse(player.wanted);
    player.event(new JSONObject().put("tag", "test").put("type", "play"));
    assertFalse(player.cloudPlaying);
    assertFalse(player.wake.isHeld());
  }

  @Test
  public void timeoutDoesNotInterruptPausedOrPlayingTrack() throws Exception {
    cloudTrack();
    player.wanted = true;
    player.cloudPlaying = true;
    player.armStartupTimeout(player.generation, 1000);
    Shadows.shadowOf(android.os.Looper.getMainLooper()).idleFor(java.time.Duration.ofSeconds(2));
    assertNull(player.failure);
    player.wanted = false;
    player.cloudPlaying = false;
    assertFalse(player.waitingForAudio());
  }

  @Test
  public void cloudPlaybackUsesMediaSessionWithoutAnActivity() throws Exception {
    cloudTrack();
    assertEquals(Player.STATE_READY, player.getPlaybackState());
    assertFalse(player.isPlaying());
    player.play();
    assertTrue(player.wake.isHeld());
    player.event(new JSONObject().put("tag", "test").put("type", "play"));
    assertTrue(player.isPlaying());
    assertEquals(180000, player.getDuration());
    player.event(
        new JSONObject().put("tag", "test").put("type", "progress").put("position", 42000));
    player.persist();
    assertEquals(42000, player.store.object("session").optLong("position"));
    player.pause();
    assertFalse(player.isPlaying());
    assertFalse(player.wake.isHeld());
  }

  @Test
  public void stoppedCloudCannotRestartFromLateWidgetEvent() throws Exception {
    cloudTrack();
    player.play();
    player.stop();
    assertFalse(player.wake.isHeld());
    assertEquals(0, player.getMediaItemCount());
    player.event(new JSONObject().put("tag", "test").put("type", "play"));
    assertFalse(player.isPlaying());
    assertEquals(-1, player.store.object("session").optInt("index"));
  }

  @Test
  public void cloudResumeDoesNotCompeteWithChromiumAudioFocus() throws Exception {
    android.media.AudioManager audio =
        (android.media.AudioManager)
            RuntimeEnvironment.getApplication().getSystemService(Context.AUDIO_SERVICE);
    org.robolectric.shadows.ShadowAudioManager shadow = Shadows.shadowOf(audio);
    Object initial = shadow.getLastAudioFocusRequest();
    cloudTrack();
    player.play();
    player.event(new JSONObject().put("tag", "test").put("type", "ready").put("duration", 180000));
    player.event(new JSONObject().put("tag", "test").put("type", "play"));
    player.pause();
    player.play();
    assertSame(initial, shadow.getLastAudioFocusRequest());
    assertTrue(player.getPlayWhenReady());
    player.event(new JSONObject().put("tag", "test").put("type", "pause"));
    assertFalse(player.getPlayWhenReady()); // Respect an actual interruption; never force playback.
    assertFalse(player.wake.isHeld());
  }

  @Test
  public void startingAnEmptyServicePreservesPausedSession() throws Exception {
    Track t = new Track();
    t.id = "saved";
    player.store.tracks("queue", java.util.Arrays.asList(t));
    player.store.put("session", new JSONObject().put("index", 0).put("position", 12345).toString());
    player.persist();
    assertEquals(1, player.store.tracks("queue").size());
    assertEquals(12345, player.store.object("session").getLong("position"));
  }
}
