package fun.pulse.music;

import static org.junit.Assert.*;

import android.view.*;
import android.widget.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35, qualifiers = "mdpi")
public class SwipePlayerTest {
  org.robolectric.android.controller.ActivityController<android.app.Activity> activity;
  SwipePlayer view;
  int next, previous, taps;

  @Before
  public void setup() {
    view =
        new SwipePlayer(
            RuntimeEnvironment.getApplication(),
            d -> {
              if (d == 1) next++;
              else previous++;
            });
    FrameLayout host = new FrameLayout(RuntimeEnvironment.getApplication());
    activity = Robolectric.buildActivity(android.app.Activity.class).setup().visible();
    activity.get().setContentView(host);
    host.addView(view, new FrameLayout.LayoutParams(360, 100));
    TextView child = new TextView(RuntimeEnvironment.getApplication());
    child.setText("Song");
    child.setOnClickListener(v -> taps++);
    view.addView(child, new LinearLayout.LayoutParams(-1, -1));
    host.measure(
        View.MeasureSpec.makeMeasureSpec(360, View.MeasureSpec.EXACTLY),
        View.MeasureSpec.makeMeasureSpec(100, View.MeasureSpec.EXACTLY));
    host.layout(0, 0, 360, 100);
  }

  @After
  public void close() {
    activity.pause().stop().destroy();
  }

  void event(int action, float x, float y, long time) {
    MotionEvent e = MotionEvent.obtain(0, time, action, x, y, 0);
    view.dispatchTouchEvent(e);
    e.recycle();
  }

  void gesture(float x, float y) {
    event(0, 180, 40, 0);
    event(2, x, y, 90);
    event(1, x, y, 160);
    Shadows.shadowOf(android.os.Looper.getMainLooper()).idleFor(java.time.Duration.ofMillis(250));
  }

  @Test
  public void deliberateSwipeSwitchesOnceAndCancelsTap() {
    gesture(50, 42);
    assertEquals(1, next);
    assertEquals(0, taps);
    gesture(300, 40);
    assertEquals(1, previous);
    assertEquals(0, taps);
  }

  @Test
  public void tapsAndVerticalMotionNeverChangeTrack() {
    gesture(182, 42);
    assertEquals(1, taps);
    gesture(150, 180);
    assertEquals(0, next + previous);
  }

  @Test
  public void cancelledGestureDoesNotChangeSong() {
    event(0, 180, 40, 0);
    event(2, 50, 40, 90);
    event(3, 50, 40, 160);
    assertEquals(0, next + previous);
  }
}
