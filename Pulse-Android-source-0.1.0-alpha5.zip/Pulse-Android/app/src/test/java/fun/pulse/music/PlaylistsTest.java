package fun.pulse.music;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public class PlaylistsTest {
  Store store;

  @Before
  public void setup() {
    RuntimeEnvironment.getApplication().getSharedPreferences("pulse-v1", 0).edit().clear().commit();
    store = new Store(RuntimeEnvironment.getApplication());
  }

  @Test
  public void playlistSurvivesReopenDeduplicatesAndDoesNotRemoveFavorites() throws Exception {
    Playlists p = new Playlists(store);
    String id = p.create(" На вечер ");
    Track t = new Track();
    t.id = "sc:17";
    t.title = "Песня";
    store.tracks("favorites", java.util.Arrays.asList(t));
    assertTrue(p.add(id, t));
    assertFalse(p.add(id, t));
    t.title = "changed outside playlist";
    p = new Playlists(new Store(RuntimeEnvironment.getApplication()));
    assertEquals("На вечер", p.name(id));
    assertEquals("Песня", p.tracks(id).get(0).title);
    p.rename(id, "Дорога");
    assertEquals("Дорога", new Playlists(store).name(id));
    p.remove(id, t);
    assertTrue(p.tracks(id).isEmpty());
    p.add(id, t);
    p.delete(id);
    assertTrue(p.ids().isEmpty());
    assertEquals(1, store.tracks("favorites").size());
  }

  @Test
  public void emptyNamesNeverCreateLists() throws Exception {
    Playlists p = new Playlists(store);
    try {
      p.create("  ");
      fail();
    } catch (IllegalArgumentException expected) {
    }
    assertTrue(p.ids().isEmpty());
  }
}
