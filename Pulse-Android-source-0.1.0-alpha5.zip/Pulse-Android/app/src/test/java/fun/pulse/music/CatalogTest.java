package fun.pulse.music;

import static org.junit.Assert.*;

import java.util.*;
import org.json.*;
import org.junit.Test;

public class CatalogTest {
  @Test
  public void failedCandidateDoesNotHideWorkingSameRecording() throws Exception {
    Track seed = new Track(), bad = new Track(), remix = new Track(), good = new Track();
    for (Track t : Arrays.asList(seed, bad, remix, good)) {
      t.artist = "CODE80";
      t.title = "NewL";
      t.duration = 180000;
      t.source = "soundcloud";
    }
    seed.id = "yandex:1";
    seed.source = "yandex";
    bad.id = "sc:bad";
    remix.id = "sc:remix";
    remix.title = "NewL remix";
    good.id = "sc:good";
    List<String> tried = new ArrayList<>();
    Catalog catalog =
        new Catalog() {
          @Override
          Track direct(Track t) throws Exception {
            tried.add(t.id);
            if (t.id.equals("sc:good")) return t;
            throw new java.io.IOException("offline");
          }

          @Override
          public Result search(String q, List<Track> local) {
            Result r = new Result();
            r.tracks.addAll(Arrays.asList(bad, remix, good));
            return r;
          }
        };
    assertSame(good, catalog.resolve(seed, Collections.emptyList()));
    assertEquals(Arrays.asList("yandex:1", "sc:bad", "sc:good"), tried);
  }

  JSONObject track(String id, String policy, long duration, long full) throws Exception {
    return new JSONObject()
        .put("id", id)
        .put("title", "Test track")
        .put("streamable", true)
        .put("policy", policy)
        .put("duration", duration)
        .put("full_duration", full)
        .put("permalink_url", "https://soundcloud.com/test/" + id)
        .put("user", new JSONObject().put("username", "Artist"));
  }

  @Test
  public void soundCloudNeverReturnsPaidPreviewAsFull() throws Exception {
    JSONObject tracks =
        new JSONObject()
            .put("a", track("a", "ALLOW", 180000, 180000))
            .put("b", track("b", "SNIP", 30000, 180000))
            .put("c", track("c", "ALLOW", 30000, 180000));
    JSONObject page =
        new JSONObject()
            .put(
                "initialStoreState",
                new JSONObject().put("entities", new JSONObject().put("tracks", tracks)));
    List<Track> result = Catalog.scRows(page, null);
    assertEquals(1, result.size());
    assertEquals("sc:a", result.get(0).id);
    assertEquals(180000, result.get(0).duration);
  }

  @Test
  public void audiusGateIsRespected() throws Exception {
    JSONObject available =
        new JSONObject()
            .put("id", "a")
            .put("is_streamable", true)
            .put("title", "Open")
            .put("duration", 180)
            .put("user", new JSONObject().put("id", "artist").put("name", "Artist"));
    JSONObject gated =
        new JSONObject(available.toString())
            .put("id", "b")
            .put("stream_conditions", new JSONObject().put("purchase", true));
    List<Track> result = Catalog.audiusRows(new JSONArray().put(available).put(gated));
    assertEquals(1, result.size());
    assertEquals("audius:a", result.get(0).id);
  }

  @Test
  public void metadataRoundTripPreservesPlaybackAndArtist() throws Exception {
    Track t = new Track();
    t.id = "sc:1";
    t.title = "Название";
    t.artist = "Исполнитель";
    t.source = "soundcloud";
    t.artistUrl = "https://soundcloud.com/artist";
    t.url = "https://soundcloud.com/artist/song";
    t.duration = 123000;
    Track read = Track.from(new JSONObject(t.json().toString()));
    assertEquals(t.id, read.id);
    assertEquals(t.url, read.url);
    assertEquals(t.artistUrl, read.artistUrl);
    assertEquals(t.duration, read.duration);
  }
}
