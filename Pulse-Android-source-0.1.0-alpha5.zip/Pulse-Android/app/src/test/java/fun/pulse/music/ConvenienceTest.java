package fun.pulse.music;

import static org.junit.Assert.*;

import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public class ConvenienceTest {
  @Test
  public void signedUpdateCannotBeTamperedOrDowngraded() throws Exception {
    String raw =
        new String(
            getClass().getResourceAsStream("/signed-update-fixture.json").readAllBytes(), "UTF-8");
    JSONObject envelope = new JSONObject(raw);
    assertEquals(999, MobileUpdates.verify(envelope, 3).getInt("versionCode"));
    assertNull(MobileUpdates.verify(envelope, 999));
    JSONObject payload =
        new JSONObject(
            new String(
                android.util.Base64.decode(
                    envelope.getString("payload"), android.util.Base64.DEFAULT),
                "UTF-8"));
    payload.put("size", 7000000);
    envelope.put(
        "payload",
        android.util.Base64.encodeToString(
            payload.toString().getBytes("UTF-8"), android.util.Base64.NO_WRAP));
    try {
      MobileUpdates.verify(envelope, 3);
      fail("Tampered manifest accepted");
    } catch (SecurityException expected) {
    }
  }

  Track track(String id, String artist) {
    Track t = new Track();
    t.id = id;
    t.artist = artist;
    return t;
  }

  @Test
  public void recommendationsUseLikesHistoryAndNovelty() {
    Track heard = track("old", "Favorite"),
        fresh = track("new", "Favorite"),
        other = track("other", "Other");
    List<Track> result =
        RecommendationRanker.rank(
            Arrays.asList(other, heard, fresh),
            Arrays.asList(track("fav", "Favorite")),
            Arrays.asList(heard));
    assertEquals("new", result.get(0).id);
    assertEquals(3, result.size());
  }

  @Test
  public void importsAcceptProfileNameAndCanonicalizeLikes() throws Exception {
    assertEquals("https://soundcloud.com/listener/likes", Catalog.likesUrl("@listener"));
    assertEquals(
        "https://soundcloud.com/listener/likes",
        Catalog.likesUrl("https://soundcloud.com/listener?si=abcd"));
    for (String unsafe :
        Arrays.asList(
            "https://attacker.example/a",
            "https://soundcloud.com@attacker.example/a",
            "http://soundcloud.com/a")) {
      try {
        Catalog.likesUrl(unsafe);
        fail("Unsafe profile accepted");
      } catch (java.io.IOException expected) {
      }
    }
  }

  @Test
  public void exactArtistCardComesFirstWithoutDuplicates() {
    Track other = track("x", "Other"),
        exact = track("y", "Target"),
        duplicate = track("z", "Target");
    other.artistId = "1";
    exact.artistId = "2";
    duplicate.artistId = "2";
    List<Track> result = Catalog.artistCards("Target", Arrays.asList(other, exact, duplicate));
    assertEquals("Target", result.get(0).artist);
    assertEquals(2, result.size());
  }

  @Test
  public void updateRejectsForeignUrlAndBadSize() throws Exception {
    JSONObject good =
        new JSONObject()
            .put("version", "0.1.0-alpha4")
            .put("versionCode", 4)
            .put("size", 6000000)
            .put("sha256", String.join("", Collections.nCopies(64, "a")))
            .put(
                "url",
                "https://github.com/s4t0sh1-ops/pulse-releases/releases/download/android-v0.1.0-alpha4/Pulse-Android-0.1.0-alpha4.apk");
    MobileUpdates.validate(good);
    try {
      MobileUpdates.validate(
          new JSONObject(good.toString()).put("url", "https://attacker.example/pulse.apk"));
      fail();
    } catch (SecurityException expected) {
    }
    try {
      MobileUpdates.validate(new JSONObject(good.toString()).put("size", 1024));
      fail();
    } catch (SecurityException expected) {
    }
  }
}
