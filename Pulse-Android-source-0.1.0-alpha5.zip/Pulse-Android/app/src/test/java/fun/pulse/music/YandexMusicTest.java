package fun.pulse.music;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public class YandexMusicTest {
  static class FakeMusic extends YandexMusic {
    final List<Integer> batches = new ArrayList<>();
    boolean available = true;

    FakeMusic() {
      super(RuntimeEnvironment.getApplication());
      session
          .context
          .getSharedPreferences("yandex-session", 0)
          .edit()
          .clear()
          .putString("account", "{\"uid\":\"123\"}")
          .commit();
    }

    @Override
    JSONObject get(String path, Map<String, String> data) throws Exception {
      JSONArray rows = new JSONArray();
      if (path.endsWith("/likes/tracks")) {
        for (int i = 1; i <= 67; i++) rows.put(new JSONObject().put("id", "" + i));
        return new JSONObject()
            .put("result", new JSONObject().put("library", new JSONObject().put("tracks", rows)));
      }
      assertEquals("/tracks", path);
      String[] ids = data.get("track-ids").split(",");
      batches.add(ids.length);
      for (String id : ids)
        rows.put(
            new JSONObject()
                .put("id", id)
                .put("title", "Song " + id)
                .put("available", available)
                .put("durationMs", 180000)
                .put(
                    "artists",
                    new JSONArray().put(new JSONObject().put("name", "Artist").put("id", 7))));
      return new JSONObject().put("result", rows);
    }
  }

  @Test
  public void importsBeyondFiftyWithProgressAndOriginalMetadata() throws Exception {
    FakeMusic m = new FakeMusic();
    List<Integer> progress = new ArrayList<>();
    List<Track> tracks =
        m.likes(
            () -> false,
            (loaded, total) -> {
              assertEquals(67, total);
              progress.add(loaded);
            });
    assertEquals(67, tracks.size());
    assertEquals(Arrays.asList(50, 17), m.batches);
    assertEquals(Arrays.asList(50, 67), progress);
    assertEquals("yandex:67", tracks.get(66).id);
    assertEquals("Artist", tracks.get(0).artist);
    assertEquals(180000, tracks.get(0).duration);
  }

  @Test
  public void cancelledImportDoesNotRequestNextBatch() throws Exception {
    FakeMusic m = new FakeMusic();
    try {
      m.likes(() -> !m.batches.isEmpty(), (loaded, total) -> {});
      fail("Cancellation must stop the import");
    } catch (InterruptedException expected) {
    }
    assertEquals(Arrays.asList(50), m.batches);
  }

  @Test
  public void unavailablePersonalTrackCannotRequestFullStream() throws Exception {
    FakeMusic m = new FakeMusic();
    m.available = false;
    Track t = new Track();
    t.id = "yandex:1";
    try {
      m.stream(t);
      fail("Unavailable track must be rejected");
    } catch (IOException expected) {
      assertTrue(expected.getMessage().contains("недоступна"));
    }
    assertEquals(Arrays.asList(1), m.batches);
  }

  @Test
  public void parsesAndroidCompatibleDownloadXmlAndRejectsForeignHostsAndEntities()
      throws Exception {
    String xml =
        "<download-info><host>audio.example.yandex.net</host><path>/abc/track.mp3</path><ts>1abc</ts><s>salt</s></download-info>";
    String url = YandexMusic.direct(xml);
    assertTrue(
        url.matches("https://audio.example.yandex.net/get-mp3/[a-f0-9]{32}/1abc/abc/track.mp3"));
    for (String unsafe :
        Arrays.asList(
            xml.replace("audio.example.yandex.net", "attacker.example"),
            "<!DOCTYPE a [<!ENTITY x SYSTEM 'file:///etc/passwd'>]>" + xml)) {
      try {
        YandexMusic.direct(unsafe);
        fail("Unsafe XML accepted");
      } catch (IOException expected) {
      }
    }
  }
}
