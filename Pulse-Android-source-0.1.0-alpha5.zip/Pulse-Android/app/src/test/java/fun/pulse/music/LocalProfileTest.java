package fun.pulse.music;

import static org.junit.Assert.*;

import org.json.JSONObject;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public class LocalProfileTest {
  Store store;

  @Before
  public void setup() {
    android.content.Context c = RuntimeEnvironment.getApplication();
    c.getSharedPreferences("pulse-v1", 0).edit().clear().commit();
    store = new Store(c);
  }

  @Test
  public void logoutPreservesPasswordHashAndAllowsReturning() throws Exception {
    JSONObject first = store.register("Первый", "first@example.invalid", "safe-pass-123");
    assertFalse(store.loggedIn());
    store.activate(first);
    assertTrue(store.loggedIn());
    store.logout();
    assertFalse(store.loggedIn());
    assertFalse(store.get("profiles", "").contains("safe-pass-123"));
    try {
      store.login("first@example.invalid", "bad-password");
      fail();
    } catch (Exception expected) {
    }
    JSONObject again = store.login("first@example.invalid", "safe-pass-123");
    assertEquals(first.getString("id"), again.getString("id"));
    assertFalse(store.loggedIn());
    store.activate(again);
    assertTrue(store.loggedIn());
  }

  @Test
  public void anotherProfileNeverInheritsIdentityOrBio() throws Exception {
    JSONObject first = store.register("Первый", "first@example.invalid", "safe-pass-123");
    first.put("bio", "Private bio");
    store.saveProfile(first);
    store.logout();
    JSONObject second = store.register("Другой", "second@example.invalid", "other-pass-123");
    assertNotEquals(first.getString("id"), second.getString("id"));
    assertEquals("", second.optString("bio"));
    try {
      store.register("Duplicate", "first@example.invalid", "pass-123");
      fail();
    } catch (Exception expected) {
    }
  }
}
