package fun.pulse.music;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import androidx.media3.common.*;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.*;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

/**
 * Native playback lives independently of the screen, with Android audio focus and headset controls.
 */
public final class PlaybackService extends MediaSessionService {
  static final SessionCommand PLAY_QUEUE = new SessionCommand("pulse.PLAY_QUEUE", Bundle.EMPTY);
  static final SessionCommand SYNC_QUEUE = new SessionCommand("pulse.SYNC_QUEUE", Bundle.EMPTY);
  private MediaSession session;

  @Override
  @androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
  public void onCreate() {
    super.onCreate();
    ExoPlayer player = new ExoPlayer.Builder(this).build();
    player.setAudioAttributes(
        new AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build(),
        true);
    player.setHandleAudioBecomingNoisy(true);
    player.setWakeMode(C.WAKE_MODE_NETWORK);
    PendingIntent open =
        PendingIntent.getActivity(
            this,
            0,
            new Intent(this, MainActivity.class),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    HybridPlayer hybrid = new HybridPlayer(this, player);
    session =
        new MediaSession.Builder(this, hybrid)
            .setSessionActivity(open)
            .setCallback(
                new MediaSession.Callback() {
                  @Override
                  public MediaSession.ConnectionResult onConnect(
                      MediaSession s, MediaSession.ControllerInfo info) {
                    MediaSession.ConnectionResult base =
                        MediaSession.Callback.super.onConnect(s, info);
                    if (!info.getPackageName().equals(getPackageName())) return base;
                    return new MediaSession.ConnectionResult.AcceptedResultBuilder(s)
                        .setAvailableSessionCommands(
                            base.availableSessionCommands
                                .buildUpon()
                                .add(PLAY_QUEUE)
                                .add(SYNC_QUEUE)
                                .build())
                        .build();
                  }

                  @Override
                  public ListenableFuture<SessionResult> onCustomCommand(
                      MediaSession s,
                      MediaSession.ControllerInfo info,
                      SessionCommand command,
                      Bundle args) {
                    if (!info.getPackageName().equals(getPackageName()))
                      return Futures.immediateFuture(
                          new SessionResult(SessionError.ERROR_PERMISSION_DENIED));
                    try {
                      if (command.customAction.equals(PLAY_QUEUE.customAction))
                        hybrid.loadStoredQueue(
                            args.getInt("index"),
                            args.getLong("position"),
                            args.getBoolean("autoplay", true));
                      else if (command.customAction.equals(SYNC_QUEUE.customAction))
                        hybrid.syncQueue();
                      else
                        return Futures.immediateFuture(
                            new SessionResult(SessionError.ERROR_NOT_SUPPORTED));
                      return Futures.immediateFuture(
                          new SessionResult(SessionResult.RESULT_SUCCESS));
                    } catch (Exception e) {
                      return Futures.immediateFuture(
                          new SessionResult(SessionError.ERROR_BAD_VALUE));
                    }
                  }
                })
            .build();
  }

  @Override
  public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
    return session;
  }

  @Override
  public void onDestroy() {
    if (session != null) {
      session.getPlayer().release();
      session.release();
      session = null;
    }
    super.onDestroy();
  }
}
