package fun.pulse.music;

import android.content.Context;
import android.view.*;
import android.widget.*;
import java.util.function.IntConsumer;

/** Intercepts deliberate horizontal swipes; taps and vertical scrolling pass through. */
final class SwipePlayer extends LinearLayout {
  final IntConsumer change;
  final float threshold;
  float downX, downY;
  boolean swiping;

  SwipePlayer(Context context, IntConsumer change) {
    super(context);
    setOrientation(VERTICAL);
    this.change = change;
    threshold = 48 * getResources().getDisplayMetrics().density;
  }

  @Override
  public boolean onInterceptTouchEvent(MotionEvent e) {
    if (e.getPointerCount() > 1) {
      swiping = false;
      return false;
    }
    if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
      downX = e.getX();
      downY = e.getY();
      swiping = false;
    } else if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
      float dx = e.getX() - downX, dy = e.getY() - downY;
      if (Math.abs(dx) > threshold && Math.abs(dx) > Math.abs(dy) * 1.6f) {
        swiping = true;
        getParent().requestDisallowInterceptTouchEvent(true);
        return true;
      }
    }
    return false;
  }

  @Override
  public boolean onTouchEvent(MotionEvent e) {
    if (!swiping) return super.onTouchEvent(e);
    if (e.getActionMasked() == MotionEvent.ACTION_UP) {
      float dx = e.getX() - downX, dy = e.getY() - downY;
      if (Math.abs(dx) > threshold && Math.abs(dx) > Math.abs(dy) * 1.6f) {
        change.accept(dx < 0 ? 1 : -1);
        MobileMotion.press(this);
      }
      swiping = false;
    } else if (e.getActionMasked() == MotionEvent.ACTION_CANCEL) swiping = false;
    return true;
  }
}
