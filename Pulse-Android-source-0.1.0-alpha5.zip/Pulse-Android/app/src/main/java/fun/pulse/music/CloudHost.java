package fun.pulse.music;

import android.app.Presentation;
import android.content.Context;
import android.graphics.PixelFormat;
import android.hardware.display.*;
import android.media.ImageReader;
import android.os.*;
import android.view.WindowManager;
import android.webkit.WebView;

/**
 * An attached, private rendering surface for the service's WebView. Never mirrors the phone screen.
 */
final class CloudHost implements AutoCloseable {
  final ImageReader reader;
  final VirtualDisplay display;
  final Presentation presentation;
  final WebView web;

  CloudHost(Context context) {
    reader = ImageReader.newInstance(320, 120, PixelFormat.RGBA_8888, 2);
    reader.setOnImageAvailableListener(
        r -> {
          android.media.Image image = r.acquireLatestImage();
          if (image != null) image.close();
        },
        new Handler(Looper.getMainLooper()));
    DisplayManager manager = (DisplayManager) context.getSystemService(Context.DISPLAY_SERVICE);
    VirtualDisplay created =
        manager.createVirtualDisplay(
            "Pulse audio renderer",
            320,
            120,
            160,
            reader.getSurface(),
            DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
                | DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION);
    if (created == null) {
      reader.close();
      throw new IllegalStateException("Private display unavailable");
    }
    display = created;
    Presentation window = new Presentation(context, display.getDisplay());
    try {
      web = new WebView(window.getContext());
      window.setContentView(web);
      window.setCancelable(false);
      window
          .getWindow()
          .addFlags(
              WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                  | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
      window.show();
      presentation = window;
    } catch (RuntimeException e) {
      window.dismiss();
      display.release();
      reader.close();
      throw e;
    }
  }

  @Override
  public void close() {
    web.stopLoading();
    web.destroy();
    presentation.dismiss();
    display.release();
    reader.close();
  }
}
