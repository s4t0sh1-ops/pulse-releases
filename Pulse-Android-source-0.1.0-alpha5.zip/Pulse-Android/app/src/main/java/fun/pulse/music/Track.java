package fun.pulse.music;

import java.util.*;
import org.json.JSONArray;
import org.json.JSONObject;

public final class Track {
  public String id = "",
      title = "",
      artist = "",
      source = "",
      url = "",
      cover = "",
      artistId = "",
      artistUrl = "",
      genre = "";
  public long duration;

  public static Track from(JSONObject j) {
    Track t = new Track();
    t.id = j.optString("id");
    t.title = j.optString("title");
    t.artist = j.optString("artist");
    t.source = j.optString("source");
    t.url = j.optString("url");
    t.cover = j.optString("cover");
    t.artistId = j.optString("artist_id");
    t.artistUrl = j.optString("artist_url");
    t.genre = j.optString("genre");
    t.duration = j.optLong("duration");
    return t;
  }

  public JSONObject json() {
    JSONObject j = new JSONObject();
    try {
      j.put("id", id)
          .put("title", title)
          .put("artist", artist)
          .put("source", source)
          .put("url", url)
          .put("cover", cover)
          .put("artist_id", artistId)
          .put("artist_url", artistUrl)
          .put("genre", genre)
          .put("duration", duration);
    } catch (Exception ignored) {
    }
    return j;
  }

  public static List<Track> list(JSONArray a) {
    List<Track> out = new ArrayList<>();
    if (a != null)
      for (int i = 0; i < a.length(); i++) {
        JSONObject j = a.optJSONObject(i);
        if (j != null) out.add(from(j));
      }
    return out;
  }

  public static JSONArray array(List<Track> tracks) {
    JSONArray a = new JSONArray();
    for (Track t : tracks) a.put(t.json());
    return a;
  }
}
