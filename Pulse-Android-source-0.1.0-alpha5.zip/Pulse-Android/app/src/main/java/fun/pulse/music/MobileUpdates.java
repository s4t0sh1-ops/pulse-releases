package fun.pulse.music;

import android.app.AlertDialog;
import android.content.*;
import android.content.pm.*;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.util.Base64;
import android.widget.*;
import androidx.core.content.FileProvider;
import java.io.*;
import java.net.*;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import org.json.*;

/** Signed Android feed is independent from the Windows update payload. */
final class MobileUpdates {
  static final String FEED =
      "https://github.com/s4t0sh1-ops/pulse-releases/releases/latest/download/pulse-android-update.json";
  static final String PUBLIC_KEY =
      "MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAsY9Yjdw+P95b3OL/Of2uIpDcoGlvFAlh0n18sOmu2+JbzP9j1g5vKvwwzyM5u0lV5vLE8RHItoYT3r0j9kuNc2i4CEQFhTYNqMvIxdFhSGxBUPrYnEHSP0mFx8PsH8qGDZlhneGeUxP2QPDlxZMK94oQEJjfPj/PqyoCrzY1cGnzY6ko4HZnU2O2NNA3foFF1hBhCk10Ilg1QrDeiyyopAwLqh8ZX8pCph+MErrqzqOgjMbCzo21bX5Bu2gTDGRrbHvRtF2UOd0BPi/pDu9Njoi5pWXkhyE4hcQEB8RDq6EU73IU6qhjGqNxPkXxCk3Dvr+uFq2RjMwG5940GjXdsgJgXCme3OGGghVX2huU2qIsB4RLj3wKafLJyMCL6dTS/hf+mwn+WTcC6uIlQVBQZp+xuYf+Se0by6nfNydyMY1OB5W3fXsYwW2LsMcpQ7uxd8Mv1OEW4eSXTWKAO1FulIcP/t36/10LuE4Kl2oL0jX5R+Re6FYrX/M5kf/hOH8hAgMBAAE=";
  final MainActivity a;
  boolean required = false, checking = false, closed = false, busy = false;
  JSONObject release;
  AlertDialog dialog;
  TextView status;
  ProgressBar progress;
  File ready;

  MobileUpdates(MainActivity activity) {
    a = activity;
  }

  void check() {
    if (checking || closed || required) return;
    checking = true;
    a.workers.execute(
        () -> {
          try {
            JSONObject envelope = new JSONObject(Catalog.request(FEED, null));
            JSONObject candidate =
                verify(
                    envelope,
                    a.getPackageManager().getPackageInfo(a.getPackageName(), 0).versionCode);
            if (candidate != null)
              a.ui.post(
                  () -> {
                    if (!closed) {
                      release = candidate;
                      required = true;
                      a.stopAudio();
                      show();
                      download();
                    }
                  });
          } catch (Exception ignored) {
          } // Offline starts are allowed; never lock users on a network error.
          finally {
            checking = false;
          }
        });
  }

  static JSONObject verify(JSONObject envelope, int installed) throws Exception {
    byte[] payload = Base64.decode(envelope.getString("payload"), Base64.DEFAULT);
    if (payload.length > 32768) throw new IOException("Manifest too large");
    java.security.Signature verifier = java.security.Signature.getInstance("SHA256withRSA");
    verifier.initVerify(
        KeyFactory.getInstance("RSA")
            .generatePublic(new X509EncodedKeySpec(Base64.decode(PUBLIC_KEY, Base64.DEFAULT))));
    verifier.update(payload);
    if (!verifier.verify(Base64.decode(envelope.getString("signature"), Base64.DEFAULT)))
      throw new SecurityException("Signature mismatch");
    JSONObject row = new JSONObject(new String(payload, "UTF-8"));
    validate(row);
    return row.getInt("versionCode") > installed ? row : null;
  }

  static void validate(JSONObject row) throws Exception {
    URI uri = new URI(row.getString("url"));
    String version = row.getString("version");
    String expected =
        "/s4t0sh1-ops/pulse-releases/releases/download/android-v"
            + version
            + "/Pulse-Android-"
            + version
            + ".apk";
    if (!version.matches("[0-9]+\\.[0-9]+\\.[0-9]+-alpha[0-9]+")
        || !"https".equals(uri.getScheme())
        || !"github.com".equals(uri.getHost())
        || !expected.equals(uri.getPath())
        || uri.getUserInfo() != null
        || uri.getPort() != -1
        || uri.getQuery() != null
        || uri.getFragment() != null
        || !row.getString("sha256").matches("[a-f0-9]{64}")
        || row.getLong("size") < 1000000
        || row.getLong("size") > 100 * 1024 * 1024
        || row.getInt("versionCode") < 1) throw new SecurityException("Invalid update");
  }

  void show() {
    LinearLayout body = a.column();
    body.setPadding(a.dp(22), a.dp(16), a.dp(22), a.dp(16));
    status =
        a.text(
            "Новая версия Pulse "
                + release.optString("version")
                + ". Загружаем и проверяем обновление…",
            15,
            a.TEXT,
            false);
    body.addView(status);
    a.space(body, 14);
    progress = new ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
    progress.setMax(100);
    body.addView(progress);
    a.space(body, 14);
    body.addView(
        a.button(
            "Продолжить обновление",
            () -> {
              if (ready != null) install();
              else download();
            }));
    body.addView(a.button("Закрыть Pulse", a::finish));
    dialog =
        new AlertDialog.Builder(a)
            .setTitle("Обновление Pulse")
            .setView(body)
            .setCancelable(false)
            .create();
    dialog.setCanceledOnTouchOutside(false);
    dialog.show();
  }

  void download() {
    if (busy || closed) return;
    busy = true;
    a.workers.execute(
        () -> {
          File part = new File(a.getCacheDir(), "updates/pulse.part");
          try {
            part.getParentFile().mkdirs();
            long size = release.getLong("size"), count = 0;
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            HttpURLConnection c =
                (HttpURLConnection) new URL(release.getString("url")).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(20000);
            try {
              if (c.getResponseCode() != 200) throw new IOException("Download unavailable");
              try (InputStream in = c.getInputStream();
                  OutputStream out = new FileOutputStream(part)) {
                byte[] bytes = new byte[65536];
                int n, last = -1;
                while ((n = in.read(bytes)) != -1) {
                  if (closed) throw new InterruptedException();
                  count += n;
                  if (count > size) throw new SecurityException("Size");
                  out.write(bytes, 0, n);
                  digest.update(bytes, 0, n);
                  int value = (int) (count * 100 / size);
                  if (value != last) {
                    last = value;
                    a.ui.post(() -> progress.setProgress(value));
                  }
                }
              }
            } finally {
              c.disconnect();
            }
            StringBuilder hex = new StringBuilder();
            for (byte b : digest.digest())
              hex.append(String.format(java.util.Locale.ROOT, "%02x", b & 255));
            if (count != size || !hex.toString().equals(release.getString("sha256")))
              throw new SecurityException("Checksum");
            File apk = new File(part.getParentFile(), "pulse.apk");
            if (apk.exists() && !apk.delete()) throw new IOException("Replace failed");
            if (!part.renameTo(apk)) throw new IOException("Move failed");
            verifyApk(apk, release.getInt("versionCode"));
            ready = apk;
            a.ui.post(
                () -> {
                  if (!closed) {
                    status.setText(
                        "Обновление проверено. Подтверди установку в системном окне Android.");
                    install();
                  }
                });
          } catch (Exception e) {
            part.delete();
            a.ui.post(
                () -> {
                  if (!closed)
                    status.setText(
                        "Не удалось загрузить или проверить обновление. Проверь сеть и нажми"
                            + " «Продолжить обновление».");
                });
          } finally {
            busy = false;
          }
        });
  }

  @SuppressWarnings("deprecation")
  void verifyApk(File apk, int code) throws Exception {
    PackageManager pm = a.getPackageManager();
    int flag =
        Build.VERSION.SDK_INT >= 28
            ? PackageManager.GET_SIGNING_CERTIFICATES
            : PackageManager.GET_SIGNATURES;
    PackageInfo installed = pm.getPackageInfo(a.getPackageName(), flag),
        candidate = pm.getPackageArchiveInfo(apk.getAbsolutePath(), flag);
    if (candidate == null
        || !a.getPackageName().equals(candidate.packageName)
        || candidate.versionCode != code) throw new SecurityException("Wrong package");
    android.content.pm.Signature[] before =
        Build.VERSION.SDK_INT >= 28
            ? installed.signingInfo.getApkContentsSigners()
            : installed.signatures;
    android.content.pm.Signature[] after =
        Build.VERSION.SDK_INT >= 28
            ? candidate.signingInfo.getApkContentsSigners()
            : candidate.signatures;
    if (before.length != 1 || after.length != 1 || !before[0].equals(after[0]))
      throw new SecurityException("Wrong APK signer");
  }

  void install() {
    if (ready == null || closed) return;
    if (!a.getPackageManager().canRequestPackageInstalls()) {
      status.setText(
          "Разреши установку обновлений для Pulse в открывшихся настройках Android. Вернись и нажми"
              + " «Продолжить обновление».");
      a.startActivity(
          new Intent(
              Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
              Uri.parse("package:" + a.getPackageName())));
      return;
    }
    Uri uri = FileProvider.getUriForFile(a, a.getPackageName() + ".updates", ready);
    a.startActivity(
        new Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
  }

  void close() {
    closed = true;
    if (dialog != null) dialog.dismiss();
  }
}
