package fun.pulse.music;

import android.app.Dialog;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.util.function.Consumer;

final class PlaylistUI {
  final MainActivity a;
  final Playlists data;
  String active = "";

  PlaylistUI(MainActivity a) {
    this.a = a;
    data = new Playlists(a.store);
  }

  void show() {
    a.startPage("playlists");
    active = "";
    LinearLayout body = a.column();
    a.header(body, "Мои плейлисты", a::home);
    body.addView(
        a.button(
            "Создать плейлист",
            () ->
                nameDialog(
                    "Новый плейлист",
                    "",
                    name -> {
                      try {
                        open(data.create(name));
                      } catch (Exception e) {
                        a.toast(e.getMessage());
                      }
                    })));
    a.space(body, 18);
    List<String> ids = data.ids();
    if (ids.isEmpty())
      body.addView(a.text("Создай плейлист и добавляй песни через меню ⋯", 14, a.MUTED, false));
    for (String id : ids) {
      List<Track> rows = data.tracks(id);
      LinearLayout card = a.row();
      card.setPadding(a.dp(12), a.dp(12), a.dp(12), a.dp(12));
      card.setBackground(a.glass(18));
      card.addView(
          a.art(rows.isEmpty() ? null : rows.get(0), 56),
          new LinearLayout.LayoutParams(a.dp(56), a.dp(56)));
      LinearLayout labels = a.column();
      labels.setPadding(a.dp(14), 0, 0, 0);
      labels.addView(a.text(data.name(id), 17, a.TEXT, true));
      labels.addView(a.text(rows.size() + " треков", 12, a.MUTED, false));
      card.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
      a.tap(card, () -> open(id));
      body.addView(card);
      a.space(body, 10);
    }
    a.surface(a.scroll(body));
  }

  void open(String id) {
    if (data.get(id) == null) {
      show();
      return;
    }
    a.startPage("playlist");
    active = id;
    List<Track> rows = data.tracks(id);
    LinearLayout head = a.column();
    head.setPadding(a.dp(16), a.dp(8), a.dp(16), a.dp(16));
    a.header(head, data.name(id), this::show);
    LinearLayout hero = a.row();
    hero.addView(
        a.art(rows.isEmpty() ? null : rows.get(0), 64),
        new LinearLayout.LayoutParams(a.dp(64), a.dp(64)));
    TextView count = a.text("  " + rows.size() + " треков", 14, a.MUTED, false);
    hero.addView(count);
    head.addView(hero);
    a.space(head, 14);
    TextView play =
        a.button(
            "Играть всё",
            () -> {
              if (!rows.isEmpty()) a.play(rows.get(0), rows);
            });
    play.setEnabled(!rows.isEmpty());
    head.addView(play);
    a.space(head, 10);
    LinearLayout actions = a.row();
    actions.addView(
        a.button(
            "Переименовать",
            () ->
                nameDialog(
                    "Название плейлиста",
                    data.name(id),
                    name -> {
                      try {
                        data.rename(id, name);
                        open(id);
                      } catch (Exception e) {
                        a.toast(e.getMessage());
                      }
                    })),
        a.weighted());
    a.addIcon(actions, "close", "Удалить плейлист", () -> confirmDelete(id));
    head.addView(actions);
    if (rows.isEmpty()) {
      a.space(head, 14);
      head.addView(a.text("Найди песню → ⋯ → «В плейлист»", 14, a.MUTED, false));
    }
    a.showList(head, rows);
  }

  Dialog sheet(String title, LinearLayout body) {
    Dialog d = new Dialog(a);
    d.requestWindowFeature(Window.FEATURE_NO_TITLE);
    LinearLayout panel = a.column();
    panel.setPadding(a.dp(20), a.dp(20), a.dp(20), a.dp(20));
    panel.setBackground(a.glass(24));
    panel.addView(a.text(title, 20, a.TEXT, true));
    a.space(panel, 16);
    panel.addView(body);
    ScrollView scroll = a.scroll(panel);
    d.setContentView(scroll);
    d.show();
    Window w = d.getWindow();
    w.setBackgroundDrawableResource(android.R.color.transparent);
    w.setDimAmount(.45f);
    w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
    w.setLayout(-1, -2);
    w.setGravity(Gravity.BOTTOM);
    return d;
  }

  void nameDialog(String title, String value, Consumer<String> accept) {
    LinearLayout body = a.column();
    EditText input = a.input("Название плейлиста", value, android.text.InputType.TYPE_CLASS_TEXT);
    input.setSingleLine(true);
    input.setFilters(
        new android.text.InputFilter[] {new android.text.InputFilter.LengthFilter(80)});
    body.addView(input);
    TextView error = a.text("", 13, a.MUTED, false);
    body.addView(error);
    a.space(body, 12);
    Dialog d = sheet(title, body);
    body.addView(
        a.button(
            "Сохранить",
            () -> {
              try {
                String name = data.validName(input.getText().toString());
                d.dismiss();
                accept.accept(name);
              } catch (IllegalArgumentException e) {
                error.setText(e.getMessage());
              }
            }));
    body.addView(a.button("Отмена", d::dismiss));
  }

  void choose(Track t) {
    LinearLayout body = a.column();
    Dialog d = sheet("В плейлист", body);
    body.addView(
        a.button(
            "Создать новый",
            () -> {
              d.dismiss();
              nameDialog(
                  "Новый плейлист",
                  "",
                  name -> {
                    try {
                      String id = data.create(name);
                      data.add(id, t);
                      a.toast("Добавлено в «" + name + "»");
                    } catch (Exception e) {
                      a.toast(e.getMessage());
                    }
                  });
            }));
    for (String id : data.ids()) {
      a.space(body, 8);
      body.addView(
          a.button(
              data.name(id),
              () -> {
                try {
                  boolean added = data.add(id, t);
                  d.dismiss();
                  a.toast(added ? "Добавлено в плейлист" : "Уже в этом плейлисте");
                } catch (Exception e) {
                  a.toast(e.getMessage());
                }
              }));
    }
    a.space(body, 12);
    body.addView(a.button("Отмена", d::dismiss));
  }

  void remove(Track t) {
    try {
      data.remove(active, t);
      open(active);
    } catch (Exception e) {
      a.toast(e.getMessage());
    }
  }

  void confirmDelete(String id) {
    LinearLayout body = a.column();
    body.addView(
        a.text(
            "Удалить «" + data.name(id) + "»? Песни останутся в источниках и любимом.",
            14,
            a.TEXT,
            false));
    Dialog d = sheet("Удалить плейлист?", body);
    a.space(body, 12);
    body.addView(
        a.button(
            "Удалить",
            () -> {
              data.delete(id);
              d.dismiss();
              show();
            }));
    body.addView(a.button("Отмена", d::dismiss));
  }
}
