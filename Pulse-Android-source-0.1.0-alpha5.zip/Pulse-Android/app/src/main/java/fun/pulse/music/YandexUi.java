package fun.pulse.music;

import android.app.*;
import android.content.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.*;

final class YandexUi {
  final MainActivity a;
  final YandexMusic music;
  final AtomicInteger generation = new AtomicInteger();
  AlertDialog authDialog;

  YandexUi(MainActivity activity) {
    a = activity;
    music = new YandexMusic(a);
  }

  void cancel() {
    generation.incrementAndGet();
    if (authDialog != null) {
      authDialog.dismiss();
      authDialog = null;
    }
  }

  void disconnect() {
    cancel();
    music.session.clear();
    a.stopAudio();
    a.toast("Яндекс отключён");
    a.profile();
  }

  void section(LinearLayout body) {
    a.space(body, 18);
    body.addView(a.text("Яндекс Музыка", 20, a.TEXT, true));
    a.space(body, 10);
    if (music.session.connected()) {
      body.addView(
          a.text(
              "Подключён: "
                  + music
                      .session
                      .account()
                      .optString(
                          "displayName",
                          music.session.account().optString("login", "твой аккаунт")),
              13,
              a.MUTED,
              false));
      a.space(body, 12);
      body.addView(a.button("Импортировать из Яндекс Музыки", this::importLikes));
      a.space(body, 10);
      body.addView(a.button("Отключить Яндекс", this::disconnect));
    } else {
      body.addView(a.button("Подключить Яндекс по коду", this::connect));
      a.space(body, 10);
      body.addView(
          a.button(
              "Импортировать из Яндекс Музыки",
              () -> {
                a.toast("Сначала подключи свой аккаунт по коду");
                connect();
              }));
    }
    a.space(body, 12);
    body.addView(
        a.text(
            "Личный музыкальный аккаунт. Импорт добавляет лайки в любимое Pulse; доступ к полным"
                + " записям определяется твоим аккаунтом и подпиской.",
            12,
            a.MUTED,
            false));
  }

  void connect() {
    cancel();
    int request = generation.incrementAndGet();
    a.toast("Получаем код Яндекса…");
    a.workers.execute(
        () -> {
          try {
            JSONObject challenge = YandexMusic.challenge();
            String code = challenge.getString("user_code"),
                device = challenge.getString("device_code");
            String target =
                challenge.optString(
                    "verification_uri",
                    challenge.optString("verification_url", "https://ya.ru/device"));
            java.net.URI parsed = new java.net.URI(target);
            if (!"https".equals(parsed.getScheme())
                || !Arrays.asList(
                        "ya.ru", "oauth.yandex.ru", "oauth.yandex.com", "passport.yandex.ru")
                    .contains(parsed.getHost())) throw new Exception("Неожиданный адрес входа");
            String url = target;
            a.ui.post(
                () -> {
                  if (request != generation.get()) return;
                  LinearLayout body = a.column();
                  body.setPadding(a.dp(20), a.dp(12), a.dp(20), a.dp(12));
                  body.addView(a.text("Введи код на странице Яндекса", 15, a.TEXT, false));
                  a.space(body, 16);
                  TextView value = a.text(code, 30, a.TEXT, true);
                  value.setTextIsSelectable(true);
                  body.addView(value);
                  a.space(body, 16);
                  body.addView(
                      a.button(
                          "Скопировать код и открыть Яндекс",
                          () -> {
                            ((android.content.ClipboardManager)
                                    a.getSystemService(Context.CLIPBOARD_SERVICE))
                                .setPrimaryClip(ClipData.newPlainText("Код входа Яндекс", code));
                            a.open(url);
                          }));
                  authDialog =
                      new AlertDialog.Builder(a)
                          .setTitle("Подключить Яндекс")
                          .setView(body)
                          .setNegativeButton("Отмена", (d, w) -> cancel())
                          .setOnCancelListener(d -> cancel())
                          .show();
                });
            int interval = Math.max(3, Math.min(30, challenge.optInt("interval", 5)));
            long deadline =
                System.currentTimeMillis()
                    + Math.min(600, challenge.optInt("expires_in", 300)) * 1000L;
            while (request == generation.get() && System.currentTimeMillis() < deadline) {
              Thread.sleep(interval * 1000L);
              if (request != generation.get()) return;
              JSONObject answer = YandexMusic.poll(device);
              if (answer.has("access_token")) {
                String token = answer.getString("access_token");
                JSONObject account = YandexMusic.account(token);
                a.ui.post(
                    () -> {
                      if (request != generation.get() || !a.store.loggedIn()) return;
                      try {
                        music.session.save(token, account);
                        cancel();
                        a.toast("Яндекс Музыка подключена");
                        a.profile();
                      } catch (Exception e) {
                        a.toast("Не удалось безопасно сохранить подключение");
                      }
                    });
                return;
              }
              String error = answer.optString("error");
              if (error.equals("slow_down")) {
                interval = Math.min(30, interval + 5);
                continue;
              }
              if (!error.equals("authorization_pending"))
                throw new Exception(
                    error.equals("access_denied")
                        ? "Вход отменён в Яндексе"
                        : "Код недоступен. Запроси новый код");
            }
            a.ui.post(
                () -> {
                  if (request == generation.get()) {
                    cancel();
                    a.toast("Время кода истекло. Подключи Яндекс заново.");
                  }
                });
          } catch (Exception e) {
            a.ui.post(
                () -> {
                  if (request == generation.get()) {
                    cancel();
                    a.toast(
                        "Яндекс: "
                            + (e.getMessage() == null
                                ? "не удалось подключиться"
                                : e.getMessage()));
                  }
                });
          }
        });
  }

  void importLikes() {
    int request = generation.incrementAndGet();
    TextView status = a.text("Загружаем любимые треки…", 15, a.TEXT, false);
    status.setPadding(a.dp(20), a.dp(16), a.dp(20), a.dp(16));
    AlertDialog dialog =
        new AlertDialog.Builder(a)
            .setTitle("Импорт Яндекс Музыки")
            .setView(status)
            .setNegativeButton("Отмена", (d, w) -> cancel())
            .setOnCancelListener(d -> cancel())
            .create();
    dialog.show();
    a.workers.execute(
        () -> {
          try {
            List<Track> rows =
                music.likes(
                    () -> request != generation.get(),
                    (loaded, total) ->
                        a.ui.post(
                            () -> {
                              if (request == generation.get())
                                status.setText("Получено " + loaded + " из " + total);
                            }));
            a.ui.post(
                () -> {
                  if (request != generation.get() || !a.store.loggedIn()) return;
                  int count = 0;
                  Set<String> seen = new HashSet<>();
                  for (Track t : a.favorites) seen.add(t.id);
                  for (Track t : rows)
                    if (seen.add(t.id)) {
                      a.favorites.add(t);
                      count++;
                    }
                  a.store.tracks("favorites", a.favorites);
                  dialog.dismiss();
                  a.toast("Добавлено любимых треков: " + count);
                  a.showCollection("Любимые треки", a.favorites);
                });
          } catch (Exception e) {
            a.ui.post(
                () -> {
                  if (request == generation.get()) {
                    dialog.dismiss();
                    a.toast("Импорт не завершён. Проверь подключение Яндекса и попробуй снова.");
                  }
                });
          }
        });
  }
}
