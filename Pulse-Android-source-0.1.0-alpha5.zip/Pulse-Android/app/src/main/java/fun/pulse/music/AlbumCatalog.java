package fun.pulse.music;

import java.util.*;
import org.json.*;

final class AlbumCatalog {
  static List<Album> load(Track artist) throws Exception {
    LinkedHashMap<String, Album> all = new LinkedHashMap<>();
    if (artist.source.equals("soundcloud") && !artist.artistUrl.isEmpty()) {
      JSONObject page = Catalog.scPage(artist.artistUrl.replaceAll("/$", "") + "/albums");
      JSONObject entities = page.getJSONObject("initialStoreState").getJSONObject("entities");
      JSONObject playlists = Catalog.records(entities, "playlists");
      for (Iterator<String> keys = playlists.keys(); keys.hasNext(); ) {
        JSONObject row = playlists.getJSONObject(keys.next());
        if (!row.optBoolean("is_album") && !row.optString("playlist_type").equals("album"))
          continue;
        Album a = new Album();
        a.source = "soundcloud";
        a.id = row.optString("id");
        a.title = row.optString("title");
        a.cover = row.optString("artwork_url");
        a.url = row.optString("permalink_url");
        a.year = row.optString("release_year");
        all.put(a.id, a);
      }
    } else if (artist.source.equals("audius")) {
      for (int offset = 0; ; offset += 100) {
        JSONArray rows =
            Catalog.object(
                    "https://api.audius.co/v1/users/"
                        + Catalog.enc(artist.artistId)
                        + "/albums?limit=100&offset="
                        + offset
                        + "&app_name=Pulse")
                .optJSONArray("data");
        int before = all.size();
        for (int i = 0; rows != null && i < rows.length(); i++) {
          JSONObject row = rows.getJSONObject(i);
          Album a = new Album();
          a.source = "audius";
          a.id = row.optString("id");
          a.title = row.optString("playlist_name");
          JSONObject art = row.optJSONObject("artwork");
          if (art != null) a.cover = art.optString("480x480");
          a.year = row.optString("release_date");
          if (a.year.length() > 4) a.year = a.year.substring(0, 4);
          all.put(a.id, a);
        }
        if (rows == null || rows.length() < 100 || all.size() == before) break;
      }
    } else if (artist.source.equals("yandex") && artist.artistId.matches("[0-9]+")) {
      for (int page = 0; ; page++) {
        JSONObject result =
            Catalog.object(
                    "https://api.music.yandex.net/artists/"
                        + artist.artistId
                        + "/direct-albums?page="
                        + page
                        + "&page-size=100&sort-by=year")
                .getJSONObject("result");
        JSONArray rows = result.optJSONArray("albums");
        int before = all.size();
        for (int i = 0; rows != null && i < rows.length(); i++) {
          JSONObject row = rows.getJSONObject(i);
          Album a = new Album();
          a.source = "yandex";
          a.id = row.optString("id");
          a.title = row.optString("title");
          a.year = row.optString("year");
          String cover = row.optString("coverUri");
          if (!cover.isEmpty()) a.cover = "https://" + cover.replace("%%", "400x400");
          all.put(a.id, a);
        }
        JSONObject pager = result.optJSONObject("pager");
        int total = pager == null ? 0 : pager.optInt("total");
        if (rows == null
            || rows.length() < 100
            || all.size() == before
            || (total > 0 && all.size() >= total)) break;
      }
    }
    return new ArrayList<>(all.values());
  }

  static List<Track> tracks(Album a) throws Exception {
    if (a.source.equals("soundcloud")) return Catalog.scRows(Catalog.scPage(a.url), null);
    if (a.source.equals("audius"))
      return Catalog.audiusRows(
          Catalog.object(
                  "https://api.audius.co/v1/playlists/"
                      + Catalog.enc(a.id)
                      + "/tracks?app_name=Pulse")
              .optJSONArray("data"));
    JSONObject result =
        Catalog.object("https://api.music.yandex.net/albums/" + Catalog.enc(a.id) + "/with-tracks")
            .getJSONObject("result");
    JSONArray volumes = result.getJSONArray("volumes");
    List<Track> rows = new ArrayList<>();
    for (int i = 0; i < volumes.length(); i++)
      for (int n = 0; n < volumes.getJSONArray(i).length(); n++)
        rows.add(YandexMusic.row(volumes.getJSONArray(i).getJSONObject(n)));
    return rows;
  }
}
