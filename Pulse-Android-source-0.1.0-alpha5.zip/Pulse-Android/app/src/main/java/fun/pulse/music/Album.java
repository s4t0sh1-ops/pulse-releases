package fun.pulse.music;

final class Album {
  String id = "", title = "", cover = "", year = "", source = "", url = "";
}
