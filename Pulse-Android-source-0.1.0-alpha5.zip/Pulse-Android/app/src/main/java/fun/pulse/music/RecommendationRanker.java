package fun.pulse.music;

import java.util.*;

final class RecommendationRanker {
  static List<Track> rank(List<Track> candidates, List<Track> favorites, List<Track> history) {
    Map<String, Integer> artists = new HashMap<>(), genres = new HashMap<>();
    Set<String> heard = new HashSet<>();
    for (Track t : history) {
      artists.merge(Matching.normalize(t.artist), 1, Integer::sum);
      if (!t.genre.isEmpty()) genres.merge(Matching.normalize(t.genre), 1, Integer::sum);
      heard.add(t.id);
    }
    for (Track t : favorites) {
      artists.merge(Matching.normalize(t.artist), 5, Integer::sum);
      if (!t.genre.isEmpty()) genres.merge(Matching.normalize(t.genre), 4, Integer::sum);
    }
    List<Track> rows = new ArrayList<>(candidates);
    Collections.shuffle(rows);
    rows.sort(
        Comparator.comparingInt(
                (Track t) ->
                    artists.getOrDefault(Matching.normalize(t.artist), 0) * 3
                        + genres.getOrDefault(Matching.normalize(t.genre), 0)
                        - (heard.contains(t.id) ? 7 : 0))
            .reversed());
    return rows;
  }
}
