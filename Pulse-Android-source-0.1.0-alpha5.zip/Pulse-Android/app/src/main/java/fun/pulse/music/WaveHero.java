package fun.pulse.music;

import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;

/** Soft monochrome wave artwork, seed cover and transport in one compact header. */
final class WaveHero extends FrameLayout {
  final MainActivity a;
  final TextView caption;
  final Icons transport;

  WaveHero(MainActivity activity, Track seed, Runnable play, Runnable settings) {
    super(activity);
    a = activity;
    setLayoutParams(
        new LinearLayout.LayoutParams(
            -1, a.dp(250 + 80 * Math.max(0, a.getResources().getConfiguration().fontScale - 1))));
    setMinimumHeight(a.dp(230));
    setClipToOutline(true);
    GradientDrawable bg =
        new GradientDrawable(
            GradientDrawable.Orientation.TL_BR, new int[] {0xdc38303f, 0xd9151c22});
    bg.setCornerRadius(a.dp(26));
    bg.setStroke(a.dp(1), 0x795e5565);
    setBackground(bg);
    addView(new Curves(a), new FrameLayout.LayoutParams(-1, -1));
    LinearLayout body = a.column();
    body.setPadding(a.dp(22), a.dp(22), a.dp(22), a.dp(20));
    TextView over =
        a.text(
            seed == null ? "ТВОЙ МУЗЫКАЛЬНЫЙ ПОТОК" : "ВОЛНА ПО ТВОЕМУ ТРЕКУ", 10, a.MUTED, true);
    over.setLetterSpacing(.12f);
    body.addView(over);
    a.space(body, 16);
    LinearLayout main = a.row();
    main.addView(a.art(seed, 74), new LinearLayout.LayoutParams(a.dp(74), a.dp(74)));
    LinearLayout names = a.column();
    names.setPadding(a.dp(16), 0, 0, 0);
    names.addView(a.text("Моя волна", 29, a.TEXT, true));
    a.space(names, 6);
    TextView title =
        a.text(seed == null ? "Музыка по твоим вкусам" : seed.title, 14, a.TEXT, false);
    title.setMaxLines(2);
    title.setEllipsize(android.text.TextUtils.TruncateAt.END);
    names.addView(title);
    if (seed != null) {
      a.space(names, 5);
      TextView artist = a.text(seed.artist, 12, a.MUTED, false);
      artist.setMaxLines(1);
      names.addView(artist);
    }
    main.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
    body.addView(main);
    a.space(body, 20);
    LinearLayout actions = a.row();
    View button = a.icon("play", "Играть волну", play);
    transport = (Icons) button;
    transport.setEnabled(false);
    button.setBackground(a.buttonBg());
    actions.addView(button, new LinearLayout.LayoutParams(a.dp(52), a.dp(52)));
    caption = a.text("Подбираем следующий трек…", 12, a.MUTED, false);
    caption.setPadding(a.dp(12), 0, a.dp(8), 0);
    actions.addView(caption, new LinearLayout.LayoutParams(0, -2, 1));
    actions.addView(
        a.icon("settings", "Настроить волну", settings),
        new LinearLayout.LayoutParams(a.dp(48), a.dp(48)));
    body.addView(actions);
    addView(body, new FrameLayout.LayoutParams(-1, -2));
  }

  void ready(int count) {
    transport.setEnabled(true);
    caption.setText(count + " треков в потоке");
  }

  void transport(boolean playing) {
    transport.kind(playing ? "pause" : "play");
    transport.setContentDescription(playing ? "Приостановить волну" : "Играть волну");
  }

  static final class Curves extends View {
    final Paint paint = new Paint(3);
    final Path path = new Path();

    Curves(android.content.Context c) {
      super(c);
      setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    @Override
    protected void onDraw(Canvas canvas) {
      float w = getWidth(), h = getHeight();
      paint.setStyle(Paint.Style.STROKE);
      paint.setStrokeWidth(1.5f * getResources().getDisplayMetrics().density);
      for (int n = 0; n < 4; n++) {
        paint.setColor(Color.argb(18 + n * 5, 227, 196, 216));
        path.reset();
        float y = h * (.15f + n * .18f);
        path.moveTo(w * .4f, y);
        path.cubicTo(w * .9f, y - h * .35f, w * 1.2f, y + h * .3f, w * .7f, y + h * .5f);
        canvas.drawPath(path, paint);
      }
    }
  }
}
