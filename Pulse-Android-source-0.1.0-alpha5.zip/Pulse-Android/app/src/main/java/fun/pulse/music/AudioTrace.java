package fun.pulse.music;

import android.content.Context;
import java.io.*;
import java.nio.charset.StandardCharsets;

/** Bounded local state diagnostics: no song titles, user identities, tokens or stream addresses. */
final class AudioTrace {
  static synchronized void record(Context c, String event) {
    try {
      File f = new File(c.getFilesDir(), "audio-diagnostics.txt");
      if (f.length() > 96000) {
        byte[] bytes = java.nio.file.Files.readAllBytes(f.toPath());
        try (FileOutputStream out = new FileOutputStream(f)) {
          out.write(bytes, Math.max(0, bytes.length - 48000), Math.min(48000, bytes.length));
        }
      }
      try (FileOutputStream out = new FileOutputStream(f, true)) {
        out.write(
            (System.currentTimeMillis() + " " + event + "\n").getBytes(StandardCharsets.UTF_8));
      }
    } catch (Exception ignored) {
    }
  }

  static String read(Context c) {
    try {
      return new String(
          java.nio.file.Files.readAllBytes(
              new File(c.getFilesDir(), "audio-diagnostics.txt").toPath()),
          StandardCharsets.UTF_8);
    } catch (Exception e) {
      return "События воспроизведения ещё не записаны.";
    }
  }
}
