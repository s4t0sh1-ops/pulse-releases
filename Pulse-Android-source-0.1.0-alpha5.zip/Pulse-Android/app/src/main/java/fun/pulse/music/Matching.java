package fun.pulse.music;

import java.text.Normalizer;
import java.util.*;

/**
 * Ranking is independent of platform popularity. Explicit edits never silently replace originals.
 */
public final class Matching {
  public static String normalize(String s) {
    return Normalizer.normalize(s.toLowerCase(Locale.ROOT).replace('ё', 'е'), Normalizer.Form.NFKC)
        .replaceAll("[^\\p{L}\\p{N}]+", " ")
        .trim();
  }

  public static Set<String> tags(String title) {
    Set<String> out = new HashSet<>();
    String s = normalize(title);
    String[][] tags = {
      {"remix", "remix|ремикс|rmx"},
      {"slowed", "slowed|slow|замедлен"},
      {"sped", "sped|speed up|ускорен|nightcore"},
      {"live", "live|концерт"},
      {"cover", "cover|кавер"},
      {"instrumental", "instrumental|инструментал"}
    };
    for (String[] tag : tags)
      if (java.util.regex.Pattern.compile(wordPattern(tag[1])).matcher(s).find()) out.add(tag[0]);
    return out;
  }

  public static double text(String query, String value) {
    String q = normalize(query), v = normalize(value);
    if (q.isEmpty() || v.isEmpty()) return 0;
    if (q.equals(v)) return 100;
    if (q.replace(" ", "").equals(v.replace(" ", ""))) return 98;
    Set<String> a = new HashSet<>(Arrays.asList(q.split(" "))),
        b = new HashSet<>(Arrays.asList(v.split(" ")));
    if (b.containsAll(a)) return 86.0 + 10.0 * a.size() / b.size();
    if (q.length() >= 4 && v.contains(q)) return 73;
    int[] prev = new int[v.length() + 1];
    for (int j = 0; j <= v.length(); j++) prev[j] = j;
    for (int i = 1; i <= q.length(); i++) {
      int[] next = new int[v.length() + 1];
      next[0] = i;
      for (int j = 1; j <= v.length(); j++)
        next[j] =
            Math.min(
                Math.min(next[j - 1] + 1, prev[j] + 1),
                prev[j - 1] + (q.charAt(i - 1) == v.charAt(j - 1) ? 0 : 1));
      prev = next;
    }
    double sim = 1.0 - (double) prev[v.length()] / Math.max(q.length(), v.length());
    return q.length() >= 5 && sim >= .76 ? 68 * sim : 0;
  }

  public static double score(String q, Track t) {
    return Math.max(
        Math.max(text(q, t.title), text(q, t.artist)),
        Math.max(.97 * text(q, t.artist + " " + t.title), .97 * text(q, t.title + " " + t.artist)));
  }

  public static boolean sameRecording(Track seed, Track candidate) {
    if (!tags(seed.title).equals(tags(candidate.title))) return false;
    if (seed.duration > 0
        && candidate.duration > 0
        && Math.abs(seed.duration - candidate.duration) > 8000) return false;
    String artist = normalize(seed.artist).split(" feat | ft |,")[0];
    if (artist.isEmpty() || !normalize(candidate.artist + " " + candidate.title).contains(artist))
      return false;
    String a = core(seed.title, artist), b = core(candidate.title, artist);
    return !a.isEmpty() && a.equals(b);
  }

  static String core(String title, String artist) {
    return normalize(
        normalize(title)
            .replace(artist, "")
            .replaceAll(wordPattern("official|audio|video|lyrics|hd|hq"), " "));
  }

  // Android's ICU regex does not accept Java's (?U) flag. Explicit Unicode
  // boundaries behave the same on Android and the desktop JVM used by tests.
  static String wordPattern(String alternatives) {
    return "(?<![\\p{L}\\p{N}_])(?:" + alternatives + ")(?![\\p{L}\\p{N}_])";
  }
}
