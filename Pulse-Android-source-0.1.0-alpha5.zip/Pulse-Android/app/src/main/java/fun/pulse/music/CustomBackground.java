package fun.pulse.music;

import android.graphics.*;
import android.net.Uri;
import android.widget.ImageView;
import java.io.*;
import java.nio.file.*;

final class CustomBackground extends ImageView {
  final MainActivity a;
  long loadedStamp = -1;

  CustomBackground(MainActivity activity) {
    super(activity);
    a = activity;
    setScaleType(ScaleType.CENTER_CROP);
    setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
    setClickable(false);
  }

  File file() {
    return new File(a.getFilesDir(), "custom-background.jpg");
  }

  static Bitmap decode(android.content.ContentResolver resolver, Uri uri) throws Exception {
    if (android.os.Build.VERSION.SDK_INT >= 28) {
      return ImageDecoder.decodeBitmap(
          ImageDecoder.createSource(resolver, uri),
          (decoder, info, source) -> {
            android.util.Size size = info.getSize();
            float scale = Math.min(1f, 2048f / Math.max(size.getWidth(), size.getHeight()));
            decoder.setTargetSize(
                Math.max(1, Math.round(size.getWidth() * scale)),
                Math.max(1, Math.round(size.getHeight() * scale)));
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
          });
    }
    BitmapFactory.Options options = new BitmapFactory.Options();
    options.inJustDecodeBounds = true;
    try (InputStream in = resolver.openInputStream(uri)) {
      BitmapFactory.decodeStream(in, null, options);
    }
    if (options.outWidth <= 0 || options.outHeight <= 0)
      throw new IOException("Неизвестное изображение");
    options.inSampleSize = 1;
    while (Math.max(options.outWidth, options.outHeight) / options.inSampleSize > 2048)
      options.inSampleSize *= 2;
    options.inJustDecodeBounds = false;
    try (InputStream in = resolver.openInputStream(uri)) {
      Bitmap bitmap = BitmapFactory.decodeStream(in, null, options);
      if (bitmap == null) throw new IOException("Не удалось прочитать фото");
      return bitmap;
    }
  }

  void importImage(Uri uri) {
    a.toast("Подготавливаем фон…");
    a.workers.execute(
        () -> {
          try {
            Bitmap bitmap = decode(a.getContentResolver(), uri);
            File temporary = new File(a.getFilesDir(), "custom-background.part");
            try (OutputStream out = new FileOutputStream(temporary)) {
              if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)) throw new IOException();
            }
            Files.move(temporary.toPath(), file().toPath(), StandardCopyOption.REPLACE_EXISTING);
            bitmap.recycle();
            a.ui.post(
                () -> {
                  a.store.put("effect", "custom");
                  loadedStamp = -1;
                  a.applyBackground();
                  a.backgroundEditor.show();
                  a.toast("Твой фон установлен");
                });
          } catch (Exception e) {
            a.ui.post(() -> a.toast("Не удалось открыть фото. Выбери JPG, PNG или WebP."));
          }
        });
  }

  void refresh() {
    if (file().lastModified() != loadedStamp) {
      loadedStamp = file().lastModified();
      setImageBitmap(BitmapFactory.decodeFile(file().getAbsolutePath()));
    }
    setAlpha(Integer.parseInt(a.store.get("intensity", "55")) / 100f);
    invalidate();
  }

  @Override
  protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    float edge = Integer.parseInt(a.store.get("edge", "60")) / 100f;
    Paint p = new Paint();
    p.setShader(
        new RadialGradient(
            getWidth() / 2f,
            getHeight() / 2f,
            Math.max(1, Math.max(getWidth(), getHeight()) * .7f),
            new int[] {Color.TRANSPARENT, Color.argb((int) (180 * edge), 0, 0, 0)},
            new float[] {.3f, 1},
            Shader.TileMode.CLAMP));
    canvas.drawRect(0, 0, getWidth(), getHeight(), p);
  }
}
