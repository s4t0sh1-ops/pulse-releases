package fun.pulse.music;

import android.view.*;
import android.widget.TextView;

final class MobileLayout {
  static View findText(View v, String value) {
    if (v instanceof TextView && ((TextView) v).getText().toString().equals(value)) return v;
    if (v instanceof ViewGroup)
      for (int i = 0; i < ((ViewGroup) v).getChildCount(); i++) {
        View found = findText(((ViewGroup) v).getChildAt(i), value);
        if (found != null) return found;
      }
    return null;
  }
}
