package fun.pulse.music;

import android.graphics.*;
import android.view.*;
import android.widget.*;

/** Mandatory walkthrough over real controls, with an accessible card and a spotlight. */
final class CoachMarks extends FrameLayout {
  final MainActivity a;
  final Paint paint = new Paint(3);
  final RectF focus = new RectF();
  View target;
  int index;
  boolean revealed;
  static final String[] TITLES = {
    "Найди музыку",
    "Сохраняй любимое",
    "Управляй музыкой",
    "Моя волна",
    "Выбери свой фон",
    "Подключи Яндекс",
    "Добавь свои треки",
    "Настрой профиль",
    "Поддержка рядом"
  };
  static final String[] TEXT = {
    "Один поиск по всем доступным источникам. Карточки исполнителей открывают их песни и альбомы.",
    "Открой меню песни и нажми «В любимое». Сохранённые песни будут в этой вкладке.",
    "Здесь пауза и следующий трек. Обложка открывает большой плеер и текст песни. Имя исполнителя"
        + " открывает его каталог.",
    "Эта кнопка запускает поток музыки. Удерживай песню и выбери волну по ней. Три последние основы"
        + " появятся рядом.",
    "В профиле открой «Оформление»: выбери фон, цвет и скорость. Фоны анимируются и не реагируют на"
        + " касания.",
    "Личный аккаунт Яндекса даёт доступ к возможностям твоей подписки. Введи код на странице"
        + " Яндекса, затем импортируй любимые песни.",
    "Здесь выбирают свои аудиофайлы с телефона. Они добавятся в библиотеку Pulse.",
    "Здесь меняются имя и био. Внизу профиля можно выйти и войти в другой аккаунт.",
    "Наушники открывают @PulseMusicHelpBot. Выбери проблему, опиши её и при необходимости приложи"
        + " фото или видео."
  };

  CoachMarks(MainActivity activity) {
    super(activity);
    a = activity;
    setWillNotDraw(false);
    setClickable(true);
    setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
  }

  void close() {
    if (getParent() instanceof android.view.ViewGroup)
      ((android.view.ViewGroup) getParent()).removeView(this);
  }

  void step(int n) {
    close();
    index = n;
    revealed = false;
    if (n >= TITLES.length) {
      a.store.put("tour:" + a.store.object("profile").optString("id"), "true");
      a.touring = false;
      a.coach = null;
      a.home();
      return;
    }
    if (n == 0) {
      a.searchPage();
      target = a.nav.getChildAt(1);
    } else if (n == 1) {
      a.showCollection("Любимые треки", a.favorites);
      target = a.nav.getChildAt(2);
    } else if (n == 2) {
      a.home();
      target = a.mini;
    } else if (n == 3) {
      a.home();
      target = findDescription(a.content, "Играть мою волну");
    } else if (n == 4) {
      a.profile();
      target = MobileLayout.findText(a.content, "Оформление");
    } else if (n == 5) {
      a.profile();
      target =
          MobileLayout.findText(
              a.content,
              a.yandexUi.music.session.connected()
                  ? "Импортировать из Яндекс Музыки"
                  : "Подключить Яндекс по коду");
    } else if (n == 6) {
      a.profile();
      target = MobileLayout.findText(a.content, "Свои треки");
    } else if (n == 7) {
      a.profile();
      target = MobileLayout.findText(a.content, "Сохранить");
    } else {
      a.home();
      target = findDescription(a.shell, "Поддержка");
    }
    removeAllViews();
    a.root.addView(this, new FrameLayout.LayoutParams(-1, -1));
    setAlpha(0);
    animate().alpha(1).setDuration(180).start();
    post(
        () -> {
          if (target != null)
            target.requestRectangleOnScreen(
                new Rect(0, 0, target.getWidth(), target.getHeight()), true);
          post(this::place);
        });
  }

  void place() {
    if (getParent() == null) return;
    removeAllViews();
    Rect r = new Rect();
    if (target != null)
      target.requestRectangleOnScreen(new Rect(0, 0, target.getWidth(), target.getHeight()), true);
    if (target != null && target.getWidth() > 0 && target.getHeight() > 0) {
      r.set(0, 0, target.getWidth(), target.getHeight());
      a.root.offsetDescendantRectToMyCoords(target, r);
      focus.set(r);
      focus.inset(-a.dp(5), -a.dp(5));
    } else focus.set(a.dp(18), a.dp(60), getWidth() - a.dp(18), a.dp(112));
    LinearLayout card = a.column();
    card.setPadding(a.dp(20), a.dp(18), a.dp(20), a.dp(18));
    android.graphics.drawable.GradientDrawable bg =
        new android.graphics.drawable.GradientDrawable();
    bg.setColor(0xff182025);
    bg.setCornerRadius(a.dp(22));
    bg.setStroke(a.dp(1), 0xff647078);
    card.setBackground(bg);
    card.addView(a.text((index + 1) + " / " + TITLES.length, 12, a.MUTED, true));
    a.space(card, 10);
    card.addView(a.text(TITLES[index], 23, a.TEXT, true));
    a.space(card, 12);
    card.addView(
        a.text(
            revealed ? TEXT[index] : "Нажми на обведённую кнопку — покажу, как она работает.",
            15,
            a.TEXT,
            false));
    a.space(card, 18);
    if (revealed)
      card.addView(
          a.button(
              index == TITLES.length - 1 ? "Начать слушать" : "Дальше", () -> step(index + 1)));
    int width = Math.max(a.dp(200), getWidth() - a.dp(32));
    card.measure(
        MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
        MeasureSpec.makeMeasureSpec(getHeight() - a.dp(40), MeasureSpec.AT_MOST));
    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, -2);
    lp.leftMargin = a.dp(16);
    int below = (int) focus.bottom + a.dp(18);
    lp.topMargin =
        below + card.getMeasuredHeight() < getHeight() - a.dp(12)
            ? below
            : Math.max(a.dp(24), (int) focus.top - card.getMeasuredHeight() - a.dp(18));
    if (!revealed) {
      View hit = new View(a);
      hit.setContentDescription(TITLES[index] + ". Показать подсказку");
      hit.setFocusable(true);
      hit.setClickable(true);
      hit.setOnClickListener(v -> reveal());
      FrameLayout.LayoutParams hitParams =
          new FrameLayout.LayoutParams(
              Math.max(1, (int) focus.width()), Math.max(1, (int) focus.height()));
      hitParams.leftMargin = (int) focus.left;
      hitParams.topMargin = (int) focus.top;
      addView(hit, hitParams);
    }
    addView(card, lp);
    card.announceForAccessibility(
        TITLES[index] + ". " + (revealed ? TEXT[index] : "Нажми на обведённую кнопку"));
    invalidate();
  }

  void reveal() {
    revealed = true;
    place();
  }

  @Override
  public boolean onTouchEvent(MotionEvent event) {
    if (event.getAction() == MotionEvent.ACTION_UP && focus.contains(event.getX(), event.getY()))
      reveal();
    return true;
  }

  @Override
  protected void onSizeChanged(int w, int h, int oldw, int oldh) {
    super.onSizeChanged(w, h, oldw, oldh);
    if (w > 0 && h > 0) post(this::place);
  }

  @Override
  protected void onDraw(Canvas c) {
    super.onDraw(c);
    Path shade = new Path();
    shade.addRect(0, 0, getWidth(), getHeight(), Path.Direction.CW);
    shade.addRoundRect(focus, a.dp(16), a.dp(16), Path.Direction.CCW);
    paint.setStyle(Paint.Style.FILL);
    paint.setColor(0xb9000000);
    c.drawPath(shade, paint);
    paint.setStyle(Paint.Style.STROKE);
    paint.setStrokeWidth(a.dp(2));
    paint.setColor(0xffe1cddd);
    c.drawRoundRect(focus, a.dp(16), a.dp(16), paint);
  }

  static View findDescription(View v, String value) {
    if (value.contentEquals(v.getContentDescription() == null ? "" : v.getContentDescription()))
      return v;
    if (v instanceof android.view.ViewGroup)
      for (int i = 0; i < ((android.view.ViewGroup) v).getChildCount(); i++) {
        View found = findDescription(((android.view.ViewGroup) v).getChildAt(i), value);
        if (found != null) return found;
      }
    return null;
  }
}
