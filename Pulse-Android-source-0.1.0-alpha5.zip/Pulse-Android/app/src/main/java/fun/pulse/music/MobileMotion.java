package fun.pulse.music;

import android.animation.ValueAnimator;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.*;

final class MobileMotion {
  static boolean enabled() {
    return ValueAnimator.areAnimatorsEnabled();
  }

  static void press(View view) {
    view.animate().cancel();
    if (!enabled()) return;
    view.setScaleX(.95f);
    view.setScaleY(.95f);
    view.animate()
        .scaleX(1)
        .scaleY(1)
        .setDuration(180)
        .setInterpolator(new DecelerateInterpolator())
        .start();
  }

  static void enter(View view, boolean touring) {
    if (touring || !enabled()) return;
    view.setAlpha(.72f);
    view.setTranslationY(6 * view.getResources().getDisplayMetrics().density);
    view.animate()
        .alpha(1)
        .translationY(0)
        .setDuration(190)
        .setInterpolator(new DecelerateInterpolator())
        .start();
  }

  static void selectNavigation(MainActivity a, String page) {
    if (a.nav == null) return;
    int selected =
        page.equals("home") || page.equals("wave")
            ? 0
            : page.equals("search")
                    || page.equals("artist")
                    || page.equals("album")
                    || page.equals("versions")
                ? 1
                : page.equals("collection") || page.equals("playlists") || page.equals("playlist")
                    ? 2
                    : 3;
    for (int i = 0; i < a.nav.getChildCount(); i++) {
      LinearLayout item = (LinearLayout) a.nav.getChildAt(i);
      boolean active = i == selected;
      item.setSelected(active);
      item.setActivated(active);
      TextView label = (TextView) item.getChildAt(1);
      label.setTextColor(active ? a.TEXT : a.MUTED);
      Icons icon = (Icons) item.getChildAt(0);
      icon.tint(active ? a.ACCENT : 0xffaeb4c0);
      GradientDrawable pill = new GradientDrawable();
      pill.setColor(active ? 0x26d5bbc8 : Color.TRANSPARENT);
      pill.setCornerRadius(a.dp(14));
      icon.setBackground(pill);
      icon.animate().cancel();
      if (active && enabled() && !a.touring) {
        icon.setTranslationY(a.dp(2));
        icon.animate().translationY(0).setDuration(180).start();
      }
    }
  }
}
