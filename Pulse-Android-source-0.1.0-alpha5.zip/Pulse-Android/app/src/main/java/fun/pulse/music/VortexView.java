package fun.pulse.music;

import android.content.Context;
import android.opengl.*;
import android.os.*;
import java.io.*;
import java.nio.*;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** The original desktop Pulse shader, rendered at a bounded resolution on mobile. */
public final class VortexView extends GLSurfaceView implements GLSurfaceView.Renderer {
  private final Handler timer = new Handler(Looper.getMainLooper());
  private volatile boolean moving = true, active = true;
  private volatile float speed = .6f, hue = 0, complexity = 5, intensity = .55f;
  private int program, width = 360, height = 720;
  private float elapsed = 0;
  private long previous = 0;
  private final FloatBuffer quad =
      ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();

  public VortexView(Context context) {
    super(context);
    quad.put(new float[] {-1, -1, 1, -1, -1, 1, 1, 1}).position(0);
    setEGLContextClientVersion(2);
    setPreserveEGLContextOnPause(true);
    setRenderer(this);
    setRenderMode(RENDERMODE_WHEN_DIRTY);
    setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
  }

  public void configure(
      boolean active, boolean moving, float speed, float hue, float complexity, float intensity) {
    this.active = active;
    this.moving = moving;
    this.speed = speed;
    this.hue = hue;
    this.complexity = complexity;
    this.intensity = intensity;
    timer.removeCallbacks(frame);
    if (active) {
      requestRender();
      timer.post(frame);
    }
  }

  private final Runnable frame =
      new Runnable() {
        public void run() {
          if (!active) return;
          requestRender();
          if (moving) timer.postDelayed(this, 42);
        }
      };

  @Override
  protected void onSizeChanged(int w, int h, int oldw, int oldh) {
    super.onSizeChanged(w, h, oldw, oldh);
    if (w > 0 && h > 0) getHolder().setFixedSize(320, Math.max(1, 320 * h / w));
  }

  int shader(int type, String source) {
    int shader = GLES20.glCreateShader(type);
    GLES20.glShaderSource(shader, source);
    GLES20.glCompileShader(shader);
    int[] ok = {0};
    GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, ok, 0);
    if (ok[0] == 0) throw new IllegalStateException(GLES20.glGetShaderInfoLog(shader));
    return shader;
  }

  public void onSurfaceCreated(GL10 gl, EGLConfig config) {
    try (InputStream in = getContext().getAssets().open("vortex.frag")) {
      ByteArrayOutputStream bytes = new ByteArrayOutputStream();
      byte[] b = new byte[4096];
      int n;
      while ((n = in.read(b)) > 0) bytes.write(b, 0, n);
      String fragment = bytes.toString("UTF-8");
      program = GLES20.glCreateProgram();
      GLES20.glAttachShader(
          program,
          shader(
              GLES20.GL_VERTEX_SHADER,
              "attribute vec2 position;void main(){gl_Position=vec4(position,0.,1.);}"));
      GLES20.glAttachShader(program, shader(GLES20.GL_FRAGMENT_SHADER, fragment));
      GLES20.glLinkProgram(program);
    } catch (Exception e) {
      program = 0;
    }
    previous = SystemClock.elapsedRealtime();
  }

  public void onSurfaceChanged(GL10 gl, int w, int h) {
    width = w;
    height = h;
    GLES20.glViewport(0, 0, w, h);
  }

  public void onDrawFrame(GL10 gl) {
    long now = SystemClock.elapsedRealtime();
    if (moving) elapsed += Math.min(.1f, (now - previous) / 1000f) * speed;
    previous = now;
    GLES20.glClearColor(.03f, .033f, .041f, 1);
    GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
    if (program == 0) return;
    GLES20.glUseProgram(program);
    GLES20.glUniform2f(GLES20.glGetUniformLocation(program, "resolution"), width, height);
    GLES20.glUniform2f(GLES20.glGetUniformLocation(program, "mouse"), 0, 0);
    GLES20.glUniform1f(GLES20.glGetUniformLocation(program, "seconds"), elapsed);
    GLES20.glUniform1f(GLES20.glGetUniformLocation(program, "hue"), hue);
    GLES20.glUniform1f(GLES20.glGetUniformLocation(program, "complexity"), complexity);
    GLES20.glUniform1f(GLES20.glGetUniformLocation(program, "extent"), 1);
    GLES20.glUniform1f(GLES20.glGetUniformLocation(program, "intensity"), intensity);
    int loc = GLES20.glGetAttribLocation(program, "position");
    GLES20.glEnableVertexAttribArray(loc);
    GLES20.glVertexAttribPointer(loc, 2, GLES20.GL_FLOAT, false, 0, quad);
    GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
    GLES20.glDisableVertexAttribArray(loc);
  }

  public void shutdown() {
    active = false;
    timer.removeCallbacks(frame);
  }
}
