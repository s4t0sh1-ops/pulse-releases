package fun.pulse.music;

import android.content.Context;
import android.graphics.*;
import android.view.View;

/** Small outline icons, matching Pulse's desktop controls. */
public final class Icons extends View {
  private String kind;
  private final Path path = new Path();
  private final Paint p = new Paint(3);
  private int tint = 0xffe9e5eb;
  boolean favorite;
  private android.animation.ValueAnimator colorMotion;

  public void favorite(boolean value, boolean animate) {
    favorite = value;
    setSelected(value);
    setContentDescription(value ? "Убрать из любимого" : "В любимые");
    int target = value ? 0xffee667b : 0xffe9e5eb;
    if (colorMotion != null) colorMotion.cancel();
    if (!animate || !MobileMotion.enabled()) {
      tint(target);
      return;
    }
    colorMotion = android.animation.ValueAnimator.ofArgb(tint, target);
    colorMotion.setDuration(200);
    colorMotion.addUpdateListener(a -> tint((Integer) a.getAnimatedValue()));
    colorMotion.start();
    MobileMotion.press(this);
  }

  public Icons(Context context, String kind) {
    super(context);
    this.kind = kind;
    setContentDescription(kind);
    setLayerType(View.LAYER_TYPE_SOFTWARE, null);
  }

  public void kind(String value) {
    if (!kind.equals(value)) {
      kind = value;
      invalidate();
    }
  }

  public void tint(int value) {
    tint = value;
    invalidate();
  }

  @Override
  protected void onDraw(Canvas c) {
    super.onDraw(c);
    c.save();
    float scale = Math.min(getWidth(), getHeight()) / 48f;
    c.translate((getWidth() - 24 * scale) / 2, (getHeight() - 24 * scale) / 2);
    c.scale(scale, scale);
    p.setColor(tint);
    p.setStrokeWidth(1.5f);
    p.setStrokeCap(Paint.Cap.ROUND);
    p.setStrokeJoin(Paint.Join.ROUND);
    p.setStyle(Paint.Style.STROKE);
    Path x = path;
    x.reset();
    switch (kind) {
      case "play":
        x.moveTo(7, 3);
        x.lineTo(21, 12);
        x.lineTo(7, 21);
        x.close();
        c.drawPath(x, p);
        break;
      case "pause":
        c.drawLine(8, 4, 8, 20, p);
        c.drawLine(16, 4, 16, 20, p);
        break;
      case "next":
        x.moveTo(5, 4);
        x.lineTo(17, 12);
        x.lineTo(5, 20);
        x.close();
        c.drawPath(x, p);
        c.drawLine(20, 4, 20, 20, p);
        break;
      case "prev":
        x.moveTo(19, 4);
        x.lineTo(7, 12);
        x.lineTo(19, 20);
        x.close();
        c.drawPath(x, p);
        c.drawLine(4, 4, 4, 20, p);
        break;
      case "heart":
        if (favorite) p.setStyle(Paint.Style.FILL);
        x.moveTo(12, 21);
        x.cubicTo(-6, 10, 5, -2, 12, 6);
        x.cubicTo(19, -2, 30, 10, 12, 21);
        c.drawPath(x, p);
        break;
      case "home":
        x.moveTo(3, 11);
        x.lineTo(12, 3);
        x.lineTo(21, 11);
        x.lineTo(20, 21);
        x.lineTo(14, 21);
        x.lineTo(14, 14);
        x.lineTo(10, 14);
        x.lineTo(10, 21);
        x.lineTo(4, 21);
        x.close();
        c.drawPath(x, p);
        break;
      case "search":
        c.drawCircle(10, 10, 7, p);
        c.drawLine(15, 15, 21, 21, p);
        break;
      case "profile":
        c.drawCircle(12, 7, 4, p);
        c.drawArc(4, 14, 20, 28, 180, 180, false, p);
        break;
      case "settings":
        for (int i = 0; i < 3; i++) {
          float a = 5 + i * 7;
          c.drawLine(a, 3, a, 21, p);
          c.drawCircle(a, i == 1 ? 15 : 8, 2, p);
        }
        break;
      case "queue":
        c.drawLine(3, 5, 19, 5, p);
        c.drawLine(3, 10, 15, 10, p);
        c.drawLine(3, 15, 11, 15, p);
        c.drawOval(14, 17, 20, 21, p);
        c.drawLine(20, 19, 20, 10, p);
        c.drawLine(20, 10, 23, 9, p);
        break;
      case "plus":
        c.drawLine(12, 4, 12, 20, p);
        c.drawLine(4, 12, 20, 12, p);
        break;
      case "back":
        c.drawLine(15, 5, 8, 12, p);
        c.drawLine(8, 12, 15, 19, p);
        break;
      case "close":
        c.drawLine(6, 6, 18, 18, p);
        c.drawLine(18, 6, 6, 18, p);
        break;
      case "more":
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 3; i++) c.drawCircle(5 + i * 7, 12, 1.3f, p);
        break;
      case "lyrics":
        c.drawLine(5, 5, 19, 5, p);
        c.drawLine(12, 5, 12, 20, p);
        c.drawLine(9, 20, 15, 20, p);
        break;
      case "shuffle":
        x.moveTo(3, 5);
        x.lineTo(7, 5);
        x.lineTo(17, 19);
        x.lineTo(21, 19);
        c.drawPath(x, p);
        x.reset();
        x.moveTo(3, 19);
        x.lineTo(7, 19);
        x.lineTo(17, 5);
        x.lineTo(21, 5);
        x.lineTo(18, 2);
        x.moveTo(21, 5);
        x.lineTo(18, 8);
        c.drawPath(x, p);
        break;
      case "support":
        c.drawArc(3, 3, 21, 21, 180, 180, false, p);
        c.drawRoundRect(2, 11, 6, 20, 2, 2, p);
        c.drawRoundRect(18, 11, 22, 20, 2, 2, p);
        break;
      default:
        c.drawCircle(12, 12, 8, p);
    }
    c.restore();
  }
}
