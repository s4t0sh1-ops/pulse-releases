
precision highp float;
uniform float intensity;
uniform vec2 resolution;
uniform vec2 mouse;
uniform float seconds;
uniform float hue;
uniform float complexity;
uniform float extent;
mat2 turn(float a){return mat2(cos(a),-sin(a),sin(a),cos(a));}
float field(vec3 p){
    vec3 q=p;
    q.xz=turn(p.y*.38+seconds*.10)*q.xz;
    float scale=2.2+complexity*.18;
    vec3 s=q*scale;
    float fluid=dot(sin(s),cos(s.zxy+vec3(0.,0.,seconds*.12)));
    float sheets=(abs(fluid)-.16)/(scale*2.);
    float envelope=(length(p*vec3(.62,.31,1.10))-.94)*.8;
    return max(sheets,envelope);
}
vec3 normalAt(vec3 p){
    vec2 e=vec2(.002,0.);
    return normalize(vec3(field(p+e.xyy)-field(p-e.xyy),field(p+e.yxy)-field(p-e.yxy),field(p+e.yyx)-field(p-e.yyx)));
}
vec3 palette(float h){return .65+.35*cos(6.28318*(h+vec3(0.,.67,.33)));}
void main(){
    vec2 uv=gl_FragCoord.xy/resolution;
    uv.y=1.-uv.y;
    vec2 p=(uv-vec2(extent*.57,.38))*vec2(resolution.x/resolution.y,1.);
    vec3 ro=vec3(mouse.x*.09,mouse.y*.07,3.3);
    vec3 rd=normalize(vec3(p.x*3.2,-p.y*3.8,-2.65));
    ro.xy+=vec2(.02,-.08);
    float d=0.;float hit=0.;vec3 pos=ro;
    for(int i=0;i<42;i++){
        pos=ro+rd*d;
        float s=field(pos);
        if(s<.003){hit=1.;break;}
        d+=s*.73;
        if(d>6.)break;
    }
    vec3 bg=vec3(.030,.033,.041);
    vec3 color=bg;
    if(hit>.5){
        vec3 n=normalAt(pos);
        vec3 r=reflect(rd,n);
        float bands=pow(max(0.,sin(r.y*2.+r.z*1.5+r.x*2.)),8.);
        float strip=pow(max(0.,1.-abs(r.x*.8+r.y*.3)),12.);
        float light=pow(max(dot(n,normalize(vec3(-.5,1.,1.6))),0.),3.);
        float fres=pow(1.-max(dot(-rd,n),0.),3.);
        vec3 tint=mix(vec3(.96,.77,.76),palette(hue/360.),.48);
        color=vec3(.045,.047,.055)+vec3(.92,.94,.98)*bands*.9+tint*strip*.85;
        color+=light*.19+tint*fres*.30;
        color*=.75+.25*cos(pos.z*7.+pos.x*5.);
    }
    float side=smoothstep(.015,.16,uv.x)*(1.-smoothstep(extent*.78,extent+.04,uv.x));
    float bottom=1.-smoothstep(.61,.91,uv.y);
    float top=smoothstep(0.,.12,uv.y);
    float vignette=side*bottom*top;
    // Keep enough contrast behind titles and controls, with no hard image edges.
    color=mix(bg,color,vignette*.76);
    float grain=fract(sin(dot(gl_FragCoord.xy,vec2(12.9898,78.233)))*43758.5453)-.5;
    color+=grain*.009*vignette;
    gl_FragColor=vec4(mix(bg,color,intensity),1.);
}
