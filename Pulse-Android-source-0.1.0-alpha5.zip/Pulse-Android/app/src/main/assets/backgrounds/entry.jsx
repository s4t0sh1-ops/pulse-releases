import LiquidChrome from './LiquidChrome';
import DarkVeil from './DarkVeil';
import Silk from './Silk';
import Iridescence from './Iridescence';
const effects={chrome:LiquidChrome,veil:DarkVeil,silk:Silk,iridescence:Iridescence};
function App(){
 const [config,setConfig]=React.useState({effect:'silk',props:{},intensity:1,edge:0,blur:0,paused:false});
 window.setBackground=c=>{window.pulseFps=c.fps||30;setConfig(c)};
 const C=effects[config.effect];
 return <><div className="effect" style={{opacity:config.intensity,filter:`blur(${config.blur||0}px)`}}>
 {C&&<C key={config.effect} {...config.props} paused={config.paused} speed={config.paused?0:config.props.speed}/>}</div>
 <div className="edge" style={{opacity:config.edge}}/></>;
}
ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
window.forwardPointer=(x,y,kind='pointermove')=>window.dispatchEvent(new PointerEvent(kind,{clientX:x,clientY:y,pointerType:'mouse',bubbles:true,buttons:kind==='pointerdown'?1:0}));
