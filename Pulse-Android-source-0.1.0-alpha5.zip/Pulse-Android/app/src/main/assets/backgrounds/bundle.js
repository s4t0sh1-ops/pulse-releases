(()=>{var Ie=(o=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(o,{get:(w,h)=>(typeof require<"u"?require:w)[h]}):o)(function(o){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+o+'" is not supported')});var ve=Ie("react");var ct=24e5,Ye=4,qe=1/120,st=`#version 300 es
const vec2 corners[3] = vec2[3](vec2(-1.0, -1.0), vec2(3.0, -1.0), vec2(-1.0, 3.0));
void main() {
  gl_Position = vec4(corners[gl_VertexID], 0.0, 1.0);
}`,ut=`#version 300 es
precision highp float;
uniform sampler2D uState;
uniform vec2 uSize;
uniform vec4 uStroke;
uniform vec2 uImpulse;
out vec4 fragColor;

float segment(vec2 p, vec2 a, vec2 b) {
  vec2 ab = b - a;
  float t = clamp(dot(p - a, ab) / max(dot(ab, ab), 1e-4), 0.0, 1.0);
  return length(p - a - ab * t);
}

void main() {
  vec2 texel = 1.0 / uSize;
  vec2 uv = gl_FragCoord.xy * texel;
  vec2 state = texture(uState, uv).rg;
  vec2 around =
    texture(uState, uv - vec2(texel.x, 0.0)).rg +
    texture(uState, uv + vec2(texel.x, 0.0)).rg +
    texture(uState, uv - vec2(0.0, texel.y)).rg +
    texture(uState, uv + vec2(0.0, texel.y)).rg -
    4.0 * state;
  float next = state.r + (state.r - state.g) * 0.982 + 0.3 * around.r + 0.08 * (around.r - around.g);
  next *= 0.998;
  if (uImpulse.x != 0.0) {
    float d = segment(gl_FragCoord.xy, uStroke.xy, uStroke.zw) / uImpulse.y;
    next += uImpulse.x * exp(-d * d);
  }
  fragColor = vec4(next, state.r, 0.0, 1.0);
}`,lt=`#version 300 es
precision highp float;
uniform sampler2D uState;
uniform vec2 uSize;
out vec4 fragColor;

void main() {
  vec2 texel = 1.0 / uSize;
  vec2 uv = gl_FragCoord.xy * texel;
  float left = texture(uState, uv - vec2(texel.x, 0.0)).r;
  float right = texture(uState, uv + vec2(texel.x, 0.0)).r;
  float down = texture(uState, uv - vec2(0.0, texel.y)).r;
  float up = texture(uState, uv + vec2(0.0, texel.y)).r;
  fragColor = vec4((right - left) * 0.5, (up - down) * 0.5, 0.0, 1.0);
}`,ft=`#version 300 es
precision highp float;
uniform vec2 uResolution;
uniform float uUnit;
uniform float uTime;
uniform float uAmplitude;
uniform vec2 uFrequency;
uniform float uDetail;
uniform float uSharpness;
uniform float uDepth;
uniform float uPresence;
uniform vec3 uTint;
uniform vec2 uShift;
uniform float uRoughness;
uniform float uExposure;
uniform float uLight;
uniform sampler2D uSlope;
uniform vec2 uSlopeSize;
uniform float uRipple;
out vec4 fragColor;

vec2 slopeAt(vec2 uv) {
  vec2 st = uv * uSlopeSize - 0.5;
  vec2 i = floor(st);
  vec2 f = st - i;
  vec2 f2 = f * f;
  vec2 f3 = f2 * f;
  vec2 w0 = (-f3 + 3.0 * f2 - 3.0 * f + 1.0) / 6.0;
  vec2 w1 = (3.0 * f3 - 6.0 * f2 + 4.0) / 6.0;
  vec2 w2 = (-3.0 * f3 + 3.0 * f2 + 3.0 * f + 1.0) / 6.0;
  vec2 w3 = f3 / 6.0;
  vec2 g0 = w0 + w1;
  vec2 g1 = w2 + w3;
  vec2 h0 = (i - 0.5 + w1 / g0) / uSlopeSize;
  vec2 h1 = (i + 1.5 + w3 / g1) / uSlopeSize;
  vec2 a = texture(uSlope, vec2(h0.x, h0.y)).rg;
  vec2 b = texture(uSlope, vec2(h1.x, h0.y)).rg;
  vec2 c = texture(uSlope, vec2(h0.x, h1.y)).rg;
  vec2 d = texture(uSlope, vec2(h1.x, h1.y)).rg;
  return g0.y * (g0.x * a + g1.x * b) + g1.y * (g0.x * c + g1.x * d);
}

float lamp(vec2 p, vec2 center, vec2 size, float soft) {
  vec2 grown = size + soft;
  vec2 q = (p - center) / grown;
  q *= q;
  float d = sqrt(sqrt(dot(q, q)));
  float edge = soft / min(grown.x, grown.y);
  float shape = (1.0 - smoothstep(1.0 - edge, 1.0 + edge, d)) * (1.0 - 0.45 * d * d);
  return shape * size.x * size.y / (grown.x * grown.y);
}

vec3 studio(vec3 r, float blur) {
  vec2 p = r.xy / max(r.z + 1.0, 0.05);
  p += uShift * smoothstep(0.3, 1.0, length(p));
  float radius = length(p);
  float soft = 0.008 + blur;
  vec2 dir = p / max(radius, 1e-3);
  float key = lamp(p, vec2(-0.25, 0.42), vec2(0.3, 0.12), soft);
  float side = lamp(p, vec2(0.48, 0.12), vec2(0.06, 0.3), soft);
  float ground = lamp(p, vec2(-0.1, -0.55), vec2(0.45, 0.06), soft);
  float rise = smoothstep(-1.0, 1.0, dir.y);
  if (uLight > 0.5) {
    float edge = 0.008 + blur * 0.8;
    float lobe = smoothstep(0.15, 0.85, 0.5 + 0.5 * sin(atan(dir.y, dir.x) * 2.0 + 0.9));
    float tone = mix(2.4, 0.95, smoothstep(0.5 - edge, 1.0 + edge, radius));
    tone = mix(tone, 0.02, smoothstep(0.98 - edge, 1.12 + edge, radius));
    tone = mix(tone, mix(0.03, 0.3, lobe) * (0.8 + 0.4 * rise), smoothstep(1.15 - edge, 1.3 + edge, radius));
    float width = 0.035 + edge;
    tone += 2.4 * exp(-pow((radius - 1.4) / width, 2.0)) * min(1.0, 0.06 / width) * (0.6 + 0.4 * rise);
    return vec3(tone) * (1.0 - 0.5 * side) * (1.0 - 0.3 * ground) + 0.8 * key;
  }
  float width = 0.015 + soft * 2.0;
  float rim = exp(-abs(radius - 1.0) / width) * 0.031 / width * (0.8 + smoothstep(-0.5, 0.8, p.y));
  float band = 1.0 - 0.95 * smoothstep(1.04 - soft, 1.12 + soft, radius);
  float wall = smoothstep(1.25, 1.55, radius) * (0.6 + 0.4 * rise);
  float streak = smoothstep(0.2, 0.8, 0.5 + 0.5 * sin(atan(dir.y, dir.x) * 3.0 + 0.6));
  vec3 color = vec3(0.004, 0.004, 0.005) + 0.02 * smoothstep(-0.4, 0.6, p.y);
  color += vec3(1.0, 0.97, 0.94) * key * 4.0 + vec3(0.9, 0.95, 1.0) * side * 3.0 + ground * 1.2;
  color += vec3(1.0, 0.98, 0.95) * rim;
  color *= band;
  return color + vec3(mix(0.45, 1.8, streak)) * wall;
}

vec3 shade(vec2 slope, vec3 v, float blur, vec3 f0) {
  float steep = length(slope);
  slope *= 3.0 * tanh(steep / 3.0) / max(steep, 1e-6);
  vec3 n = normalize(vec3(-slope, 1.0));
  vec3 r = reflect(v, n);
  float facing = clamp(dot(n, -v), 0.0, 1.0);
  return studio(r, blur) * (f0 + (1.0 - f0) * pow(1.0 - facing, 5.0));
}

vec3 aces(vec3 x) {
  return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

void main() {
  vec2 frag = gl_FragCoord.xy;
  vec2 uv = (2.0 * frag - uResolution) / uUnit;
  vec2 p = uv;
  vec2 rowX = vec2(1.0, 0.0);
  vec2 rowY = vec2(0.0, 1.0);
  float amplitude = uAmplitude * uPresence;
  for (float i = 1.0; i < 9.0; i++) {
    if (i > uDetail) break;
    float a = amplitude / i;
    float soften = exp(0.3 - 0.3 * i);
    float argX = i * uFrequency.x * p.y + uTime;
    p.x += a * cos(argX);
    rowX -= a * sin(argX) * i * uFrequency.x * soften * rowY;
    float argY = i * uFrequency.y * p.x + uTime;
    p.y += a * cos(argY);
    rowY -= a * sin(argY) * i * uFrequency.y * soften * rowX;
  }
  float phase = uTime - p.x - p.y;
  vec2 field = -(rowX + rowY);
  float density = max(length(field), 1e-3);
  vec2 across = field / density;
  float k = uSharpness;
  float sn = sin(phase);
  float cs = cos(phase);
  float th = tanh(k * sn);
  float bevel = (1.0 - th * th) / tanh(k);
  float fade = smoothstep(3.0, 9.0, 3.14159 * uUnit / density);
  float weight = uDepth * uPresence * fade;
  vec2 slope = k * cs * bevel * weight * across + slopeAt(frag / uResolution) * uRipple;
  vec2 sweep = -k * bevel * (sn + 2.0 * k * cs * cs * th) * weight * density * 2.0 / uUnit * across;
  vec2 stepX = dFdx(slope);
  vec2 stepY = dFdy(slope);
  vec2 crease = dot(stepX, stepX) > dot(stepY, stepY) ? stepX : stepY;
  if (dot(crease, crease) > dot(sweep, sweep)) sweep = crease;
  float bend = length(sweep);
  float alpha = smoothstep(0.0, 0.1, length(slope));
  vec3 f0 = mix(vec3(1.0), uTint, smoothstep(0.05, 0.6, length(slope))) * 0.92;
  vec3 v = normalize(vec3(uv * 0.08, -1.0));
  float blur = uRoughness * 0.35;
  vec3 light;
  if (bend < 0.01) {
    light = shade(slope, v, blur + bend * 0.5, f0);
  } else {
    light = vec3(0.0);
    for (float t = -0.375; t < 0.4; t += 0.25) {
      light += shade(slope + sweep * t, v, blur + bend * 0.15, f0);
    }
    light *= 0.25;
  }
  vec3 color = pow(aces(light * uExposure), vec3(1.0 / 2.2));
  float grain = fract(52.9829189 * fract(dot(frag, vec2(0.06711056, 0.00583715))));
  color += (grain - 0.5) / 255.0;
  fragColor = vec4(clamp(color, 0.0, 1.0) * alpha, alpha);
}`,ne=(o,w,h)=>Math.min(h,Math.max(w,o)),mt=o=>{if(Array.isArray(o))return[0,1,2].map(v=>ne(Number(o[v])||0,0,1));let w=String(o||"").trim(),h=/^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(w);if(h){let v=h[1].length===3?h[1].replace(/./g,G=>G+G):h[1];return[0,2,4].map(G=>parseInt(v.slice(G,G+2),16)/255)}let m=/^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)/i.exec(w);return m?[m[1],m[2],m[3]].map(v=>ne(parseFloat(v)/255,0,1)):[1,1,1]},We=(o,w,h)=>{let m=o.createShader(w);return m?(o.shaderSource(m,h),o.compileShader(m),o.getShaderParameter(m,o.COMPILE_STATUS)?m:(console.error(o.getShaderInfoLog(m)),o.deleteShader(m),null)):null},Oe=(o,w)=>{let h=We(o,o.VERTEX_SHADER,st),m=We(o,o.FRAGMENT_SHADER,w),v=h&&m?o.createProgram():null;if(!h||!m||!v)return h&&o.deleteShader(h),m&&o.deleteShader(m),null;if(o.attachShader(v,h),o.attachShader(v,m),o.linkProgram(v),o.deleteShader(h),o.deleteShader(m),!o.getProgramParameter(v,o.LINK_STATUS))return console.error(o.getProgramInfoLog(v)),o.deleteProgram(v),null;let G={},oe=o.getProgramParameter(v,o.ACTIVE_UNIFORMS);for(let N=0;N<oe;N++){let z=o.getActiveUniform(v,N);z&&(G[z.name]=o.getUniformLocation(v,z.name))}return{program:v,uniforms:G}},dt=({color:o="#ffffff",speed:w=.2,amplitude:h=.3,frequencyX:m=3,frequencyY:v=3,detail:G=4,thickness:oe=1,depth:N=1,roughness:z=.3,exposure:be=1,interactive:Te=!0,rippleStrength:Re=1,rippleSize:Me=1,tilt:Se=1,intro:Ae=!0,lightMode:Fe=!1,maxDevicePixelRatio:_e=2,className:ge="",style:Pe})=>{let xe=(0,ve.useRef)(null),se=(0,ve.useRef)(null),pe=(0,ve.useRef)(null),[ue,me]=(0,ve.useState)(0),J={tint:mt(o).map(_=>Math.pow(_,2.2)),speed:Math.max(0,w),amplitude:ne(h,0,2),frequency:[Math.max(.1,m),Math.max(.1,v)],detail:ne(Math.round(G),1,8),thickness:ne(oe,.25,4),depth:Math.max(0,N),roughness:ne(z,0,1),exposure:Math.max(0,be),interactive:Te,rippleStrength:Math.max(0,Re),rippleSize:ne(Me,.2,4),tilt:Math.max(0,Se),intro:Ae,light:Fe,maxRatio:ne(_e,.5,3)},V=(0,ve.useRef)(J);return V.current=J,(0,ve.useEffect)(()=>{pe.current?.()}),(0,ve.useEffect)(()=>{let _=xe.current,E=se.current;if(!_||!E)return;let e=E.getContext("webgl2",{alpha:!0,premultipliedAlpha:!0,antialias:!1,depth:!1,stencil:!1,powerPreference:"high-performance"}),r=e?Oe(e,ft):null;if(!e||!r)return;let i=!!e.getExtension("EXT_color_buffer_float"),O=i?Oe(e,ut):null,B=i?Oe(e,lt):null,X=window.matchMedia("(prefers-reduced-motion: reduce)").matches,re=e.createVertexArray(),A={width:1,height:1},b=[],M=null,j=0,Y=1,F={x:0,y:0,inside:!1,ready:!1,nx:0,ny:0},p={yaw:0,pitch:0,vyaw:0,vpitch:0},c=[],R=Math.random()*40,S=V.current.intro&&!X&&ue===0?0:1,n=0,C=0,L=0,$=0,ie=!0,ae=document.visibilityState!=="hidden",Q=!1,q=(f,d)=>{let l=e.createTexture();e.bindTexture(e.TEXTURE_2D,l),e.texImage2D(e.TEXTURE_2D,0,e.RG16F,f,d,0,e.RG,e.HALF_FLOAT,null),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE);let P=e.createFramebuffer();return e.bindFramebuffer(e.FRAMEBUFFER,P),e.framebufferTexture2D(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,l,0),e.clearColor(0,0,0,1),e.clear(e.COLOR_BUFFER_BIT),e.bindFramebuffer(e.FRAMEBUFFER,null),{texture:l,framebuffer:P}},ee=f=>{f&&(e.deleteTexture(f.texture),e.deleteFramebuffer(f.framebuffer))},K=()=>{let f=V.current,d=_.getBoundingClientRect(),l=Math.max(1,d.width),P=Math.max(1,d.height),W=Math.min(window.devicePixelRatio||1,f.maxRatio,Math.sqrt(ct/(l*P))),Z=Math.max(1,Math.round(l*W)),I=Math.max(1,Math.round(P*W));if((E.width!==Z||E.height!==I)&&(E.width=Z,E.height=I),Y=Math.min(Z,I),!i||!O||!B)return;let k=ne(Math.round(l/Ye),16,512),te=ne(Math.round(P/Ye),16,512);k===A.width&&te===A.height&&b.length||(b.forEach(ee),b.length=0,ee(M),Object.assign(A,{width:k,height:te}),b.push(q(k,te),q(k,te)),M=q(k,te))},de=f=>{if(!(!O||!B||!M)){e.useProgram(O.program),e.viewport(0,0,A.width,A.height),e.uniform2f(O.uniforms.uSize,A.width,A.height),e.activeTexture(e.TEXTURE0),e.uniform1i(O.uniforms.uState,0);for(let d=0;d<f;d++){let l=d===0?c.shift():null;l?(e.uniform4f(O.uniforms.uStroke,l.ax,l.ay,l.bx,l.by),e.uniform2f(O.uniforms.uImpulse,l.strength,l.radius)):e.uniform2f(O.uniforms.uImpulse,0,1);let P=b[j],W=b[1-j];e.bindTexture(e.TEXTURE_2D,P.texture),e.bindFramebuffer(e.FRAMEBUFFER,W.framebuffer),e.drawArrays(e.TRIANGLES,0,3),j=1-j}e.useProgram(B.program),e.uniform2f(B.uniforms.uSize,A.width,A.height),e.uniform1i(B.uniforms.uState,0),e.bindTexture(e.TEXTURE_2D,b[j].texture),e.bindFramebuffer(e.FRAMEBUFFER,M.framebuffer),e.drawArrays(e.TRIANGLES,0,3)}},he=f=>{e.bindFramebuffer(e.FRAMEBUFFER,null),e.viewport(0,0,E.width,E.height);let d=r.uniforms;e.useProgram(r.program),e.uniform2f(d.uResolution,E.width,E.height),e.uniform1f(d.uUnit,Y),e.uniform1f(d.uTime,R),e.uniform1f(d.uAmplitude,f.amplitude),e.uniform2f(d.uFrequency,f.frequency[0],f.frequency[1]),e.uniform1f(d.uDepth,f.depth),e.uniform1f(d.uDetail,f.detail),e.uniform1f(d.uSharpness,5/(3*f.thickness)),e.uniform1f(d.uPresence,1-Math.pow(1-S,3)),e.uniform3fv(d.uTint,f.tint),e.uniform2f(d.uShift,p.yaw,p.pitch),e.uniform1f(d.uRoughness,f.roughness),e.uniform1f(d.uExposure,f.exposure),e.uniform1f(d.uLight,f.light?1:0),e.activeTexture(e.TEXTURE0),e.bindTexture(e.TEXTURE_2D,M?M.texture:null),e.uniform1i(d.uSlope,0),e.uniform2f(d.uSlopeSize,A.width,A.height),e.uniform1f(d.uRipple,M?f.rippleStrength*2.2:0),e.drawArrays(e.TRIANGLES,0,3)},le=f=>{if(L=0,Q)return;let d=V.current,l=ne((f-$)/1e3||0,0,.05);$=Math.max($,f),R+=l*d.speed*(X?.25:1),S=Math.min(1,S+l/1.8);let P=d.interactive&&F.inside,W=X?0:d.tilt,Z=(P?F.nx*.35:.22*Math.sin(R*1.3))*W,I=(P?-F.ny*.28:.16*Math.sin(R*.9+1.7))*W,k=36,te=2*Math.sqrt(k)*.95;if(p.vyaw+=((Z-p.yaw)*k-p.vyaw*te)*l,p.vpitch+=((I-p.pitch)*k-p.vpitch*te)*l,p.yaw+=p.vyaw*l,p.pitch+=p.vpitch*l,e.bindVertexArray(re),M){C+=l;let Le=Math.min(4,Math.floor(C/qe));C-=Le*qe,Le>0&&(de(Le),n=Math.max(0,n*Math.pow(.982,Le)))}he(d);let fe=Math.abs(p.vyaw)+Math.abs(p.vpitch)>1e-4||Math.abs(Z-p.yaw)+Math.abs(I-p.pitch)>1e-4;(d.speed>0||S<1||fe||n>.002||c.length>0)&&ie&&ae&&(L=requestAnimationFrame(le))},H=()=>{L||Q||!ie||!ae||($=performance.now(),L=requestAnimationFrame(le))};pe.current=()=>{K(),H()};let ce=(f,d)=>{let l=_.getBoundingClientRect();return{x:(f-l.left)/l.width*A.width,y:(1-(d-l.top)/l.height)*A.height,nx:(f-l.left)/l.width*2-1,ny:(d-l.top)/l.height*2-1,inside:f>=l.left&&f<=l.right&&d>=l.top&&d<=l.bottom}},g=(f,d)=>{!M||!d.interactive||X||(c.push(f),c.length>6&&c.shift(),n=1)},T=f=>{let d=V.current,l=ce(f.clientX,f.clientY);if(F.nx=ne(l.nx,-1,1),F.ny=ne(l.ny,-1,1),F.inside=l.inside,l.inside&&F.ready){let P=Math.hypot(l.x-F.x,l.y-F.y);P>.25&&g({ax:F.x,ay:F.y,bx:l.x,by:l.y,strength:-Math.min(.45,.04+P*.045)*d.rippleSize,radius:4*d.rippleSize},d)}F.x=l.x,F.y=l.y,F.ready=l.inside,H()},t=f=>{let d=V.current,l=ce(f.clientX,f.clientY);l.inside&&(g({ax:l.x,ay:l.y,bx:l.x,by:l.y,strength:-1.6*d.rippleSize,radius:6*d.rippleSize},d),H())},a=()=>{F.inside=!1,F.ready=!1,H()},s=f=>{f.pointerType!=="mouse"&&a()};window.addEventListener("pointermove",T,{passive:!0}),window.addEventListener("pointerdown",t,{passive:!0}),window.addEventListener("pointerup",s,{passive:!0}),window.addEventListener("pointercancel",s,{passive:!0}),document.documentElement.addEventListener("pointerleave",a);let u=f=>{f.preventDefault(),Q=!0,cancelAnimationFrame(L),L=0},x=()=>me(f=>f+1);E.addEventListener("webglcontextlost",u),E.addEventListener("webglcontextrestored",x);let y=new ResizeObserver(()=>{K(),H()});y.observe(_);let U=new IntersectionObserver(f=>{ie=f.some(d=>d.isIntersecting),H()});U.observe(_);let D=()=>{ae=document.visibilityState!=="hidden",H()};return document.addEventListener("visibilitychange",D),K(),H(),()=>{cancelAnimationFrame(L),pe.current=null,y.disconnect(),U.disconnect(),window.removeEventListener("pointermove",T),window.removeEventListener("pointerdown",t),window.removeEventListener("pointerup",s),window.removeEventListener("pointercancel",s),document.documentElement.removeEventListener("pointerleave",a),document.removeEventListener("visibilitychange",D),E.removeEventListener("webglcontextlost",u),E.removeEventListener("webglcontextrestored",x),e.isContextLost()||(b.forEach(ee),ee(M),e.deleteVertexArray(re),e.deleteProgram(r.program),O&&e.deleteProgram(O.program),B&&e.deleteProgram(B.program))}},[ue]),React.createElement("div",{ref:xe,className:`liquid-chrome${ge?` ${ge}`:""}`,style:Pe},React.createElement("canvas",{ref:se,className:"liquid-chrome__canvas","aria-hidden":"true"}))},He=dt;var we=Ie("react");var ht=`#version 300 es
in vec2 aPosition;
void main() {
  gl_Position = vec4(aPosition, 0.0, 1.0);
}`,vt=`#version 300 es
precision highp float;
uniform vec2 uView;
uniform vec2 uScale;
uniform float uZoom;
uniform vec2 uTurn;
uniform float uTime;
uniform float uFlow;
uniform float uWarp;
uniform vec3 uSeed;
uniform vec4 uPointer;
uniform vec2 uDrag;
uniform float uUnfold;
uniform float uDither;
out vec4 outColor;

vec4 sigmoid(vec4 x) {
  return 1.0 / (1.0 + exp(-x));
}

vec4 cppn(vec2 coordinate, vec3 latent) {
  vec4 buf[8];
  buf[6]=vec4(coordinate.x,coordinate.y,latent.x,latent.y);
  buf[7]=vec4(latent.z,sqrt(coordinate.x*coordinate.x+coordinate.y*coordinate.y),0.,0.);
  buf[0]=mat4(vec4(6.5404263,-3.6126034,0.7590882,-1.13613),vec4(2.4582713,3.1660357,1.2219609,0.06276096),vec4(-5.478085,-6.159632,1.8701609,-4.7742867),vec4(6.039214,-5.542865,-0.90925294,3.251348))*buf[6]+mat4(vec4(0.8473259,-5.722911,3.975766,1.6522468),vec4(-0.24321538,0.5839259,-1.7661959,-5.350116),vec4(0.,0.,0.,0.),vec4(0.,0.,0.,0.))*buf[7]+vec4(0.21808943,1.1243913,-1.7969975,5.0294676);
  buf[1]=mat4(vec4(-3.3522482,-6.0612736,0.55641043,-4.4719114),vec4(0.8631464,1.7432913,5.643898,1.6106541),vec4(2.4941394,-3.5012043,1.7184316,6.357333),vec4(3.310376,8.209261,1.1355612,-1.165539))*buf[6]+mat4(vec4(5.24046,-13.034365,0.009859298,15.870829),vec4(2.987511,3.129433,-0.89023495,-1.6822904),vec4(0.,0.,0.,0.),vec4(0.,0.,0.,0.))*buf[7]+vec4(-5.9457836,-6.573602,-0.8812491,1.5436668);
  buf[0]=sigmoid(buf[0]);buf[1]=sigmoid(buf[1]);
  buf[2]=mat4(vec4(-15.219568,8.095543,-2.429353,-1.9381982),vec4(-5.951362,4.3115187,2.6393783,1.274315),vec4(-7.3145227,6.7297835,5.2473326,5.9411426),vec4(5.0796127,8.979051,-1.7278991,-1.158976))*buf[6]+mat4(vec4(-11.967154,-11.608155,6.1486754,11.237008),vec4(2.124141,-6.263192,-1.7050359,-0.7021966),vec4(0.,0.,0.,0.),vec4(0.,0.,0.,0.))*buf[7]+vec4(-4.17164,-3.2281182,-4.576417,-3.6401186);
  buf[3]=mat4(vec4(3.1832156,-13.738922,1.879223,3.233465),vec4(0.64300746,12.768129,1.9141049,0.50990224),vec4(-0.049295485,4.4807224,1.4733979,1.801449),vec4(5.0039253,13.000481,3.3991797,-4.5561905))*buf[6]+mat4(vec4(-0.1285731,7.720628,-3.1425676,4.742367),vec4(0.6393625,3.714393,-0.8108378,-0.39174938),vec4(0.,0.,0.,0.),vec4(0.,0.,0.,0.))*buf[7]+vec4(-1.1811101,-21.621881,0.7851888,1.2329718);
  buf[2]=sigmoid(buf[2]);buf[3]=sigmoid(buf[3]);
  buf[4]=mat4(vec4(5.214916,-7.183024,2.7228765,2.6592617),vec4(-5.601878,-25.3591,4.067988,0.4602802),vec4(-10.57759,24.286327,21.102104,37.546658),vec4(4.3024497,-1.9625226,2.3458803,-1.372816))*buf[0]+mat4(vec4(-17.6526,-10.507558,2.2587414,12.462782),vec4(6.265566,-502.75443,-12.642513,0.9112289),vec4(-10.983244,20.741234,-9.701768,-0.7635988),vec4(5.383626,1.4819539,-4.1911616,-4.8444734))*buf[1]+mat4(vec4(12.785233,-16.345072,-0.39901125,1.7955981),vec4(-30.48365,-1.8345358,1.4542528,-1.1118771),vec4(19.872723,-7.337935,-42.941723,-98.52709),vec4(8.337645,-2.7312303,-2.2927687,-36.142323))*buf[2]+mat4(vec4(-16.298317,3.5471997,-0.44300047,-9.444417),vec4(57.5077,-35.609753,16.163465,-4.1534753),vec4(-0.07470326,-3.8656476,-7.0901804,3.1523974),vec4(-12.559385,-7.077619,1.490437,-0.8211543))*buf[3]+vec4(-7.67914,15.927437,1.3207729,-1.6686112);
  buf[5]=mat4(vec4(-1.4109162,-0.372762,-3.770383,-21.367174),vec4(-6.2103205,-9.35908,0.92529047,8.82561),vec4(11.460242,-22.348068,13.625772,-18.693201),vec4(-0.3429052,-3.9905605,-2.4626114,-0.45033523))*buf[0]+mat4(vec4(7.3481627,-4.3661838,-6.3037653,-3.868115),vec4(1.5462853,6.5488915,1.9701879,-0.58291394),vec4(6.5858274,-2.2180402,3.7127688,-1.3730392),vec4(-5.7973905,10.134961,-2.3395722,-5.965605))*buf[1]+mat4(vec4(-2.5132585,-6.6685553,-1.4029363,-0.16285264),vec4(-0.37908727,0.53738135,4.389061,-1.3024765),vec4(-0.70647055,2.0111287,-5.1659346,-3.728635),vec4(-13.562562,10.487719,-0.9173751,-2.6487076))*buf[2]+mat4(vec4(-8.645013,6.5546675,-6.3944063,-5.5933375),vec4(-0.57783127,-1.077275,36.91025,5.736769),vec4(14.283112,3.7146652,7.1452246,-4.5958776),vec4(2.7192075,3.6021907,-4.366337,-2.3653464))*buf[3]+vec4(-5.9000807,-4.329569,1.2427121,8.59503);
  buf[4]=sigmoid(buf[4]);buf[5]=sigmoid(buf[5]);
  buf[6]=mat4(vec4(-1.61102,0.7970257,1.4675229,0.20917463),vec4(-28.793737,-7.1390953,1.5025433,4.656581),vec4(-10.94861,39.66238,0.74318546,-10.095605),vec4(-0.7229728,-1.5483948,0.7301322,2.1687684))*buf[0]+mat4(vec4(3.2547753,21.489103,-1.0194173,-3.3100595),vec4(-3.7316632,-3.3792162,-7.223193,-0.23685838),vec4(13.1804495,0.7916005,5.338587,5.687114),vec4(-4.167605,-17.798311,-6.815736,-1.6451967))*buf[1]+mat4(vec4(0.604885,-7.800309,-7.213122,-2.741014),vec4(-3.522382,-0.12359311,-0.5258442,0.43852118),vec4(9.6752825,-22.853785,2.062431,0.099892326),vec4(-4.3196306,-17.730087,2.5184598,5.30267))*buf[2]+mat4(vec4(-6.545563,-15.790176,-6.0438633,-5.415399),vec4(-43.591583,28.551912,-16.00161,18.84728),vec4(4.212382,8.394307,3.0958717,8.657522),vec4(-5.0237565,-4.450633,-4.4768,-5.5010443))*buf[3]+mat4(vec4(1.6985557,-67.05806,6.897715,1.9004834),vec4(1.8680354,2.3915145,2.5231109,4.081538),vec4(11.158006,1.7294737,2.0738268,7.386411),vec4(-4.256034,-306.24686,8.258898,-17.132736))*buf[4]+mat4(vec4(1.6889864,-4.5852966,3.8534803,-6.3482175),vec4(1.3543309,-1.2640043,9.932754,2.9079645),vec4(-5.2770967,0.07150358,-0.13962056,3.3269649),vec4(28.34703,-4.918278,6.1044083,4.085355))*buf[5]+vec4(6.6818056,12.522166,-3.7075126,-4.104386);
  buf[7]=mat4(vec4(-8.265602,-4.7027016,5.098234,0.7509808),vec4(8.6507845,-17.15949,16.51939,-8.884479),vec4(-4.036479,-2.3946867,-2.6055532,-1.9866527),vec4(-2.2167742,-1.8135649,-5.9759874,4.8846445))*buf[0]+mat4(vec4(6.7790847,3.5076547,-2.8191125,-2.7028968),vec4(-5.743024,-0.27844876,1.4958696,-5.0517144),vec4(13.122226,15.735168,-2.9397483,-4.101023),vec4(-14.375265,-5.030483,-6.2599335,2.9848232))*buf[1]+mat4(vec4(4.0950394,-0.94011575,-5.674733,4.755022),vec4(4.3809423,4.8310084,1.7425908,-3.437416),vec4(2.117492,0.16342592,-104.56341,16.949184),vec4(-5.22543,-2.994248,3.8350096,-1.9364246))*buf[2]+mat4(vec4(-5.900337,1.7946124,-13.604192,-3.8060522),vec4(6.6583457,31.911177,25.164474,91.81147),vec4(11.840538,4.1503043,-0.7314397,6.768467),vec4(-6.3967767,4.034772,6.1714606,-0.32874924))*buf[3]+mat4(vec4(3.4992442,-196.91893,-8.923708,2.8142626),vec4(3.4806502,-3.1846354,5.1725626,5.1804223),vec4(-2.4009497,15.585794,1.2863957,2.0252278),vec4(-71.25271,-62.441242,-8.138444,0.50670296))*buf[4]+mat4(vec4(-12.291733,-11.176166,-7.3474145,4.390294),vec4(10.805477,5.6337385,-0.9385842,-4.7348723),vec4(-12.869276,-7.039391,5.3029537,7.5436664),vec4(1.4593618,8.91898,3.5101583,5.840625))*buf[5]+vec4(2.2415268,-6.705987,-0.98861027,-2.117676);
  buf[6]=sigmoid(buf[6]);buf[7]=sigmoid(buf[7]);
  buf[0]=mat4(vec4(1.6794263,1.3817469,2.9625452,0.),vec4(-1.8834411,-1.4806935,-3.5924516,0.),vec4(-1.3279216,-1.0918057,-2.3124623,0.),vec4(0.2662234,0.23235129,0.44178495,0.))*buf[0]+mat4(vec4(-0.6299101,-0.5945583,-0.9125601,0.),vec4(0.17828953,0.18300213,0.18182953,0.),vec4(-2.96544,-2.5819945,-4.9001055,0.),vec4(1.4195864,1.1868085,2.5176322,0.))*buf[1]+mat4(vec4(-1.2584374,-1.0552157,-2.1688404,0.),vec4(-0.7200217,-0.52666044,-1.438251,0.),vec4(0.15345335,0.15196142,0.272854,0.),vec4(0.945728,0.8861938,1.2766753,0.))*buf[2]+mat4(vec4(-2.4218085,-1.968602,-4.35166,0.),vec4(-22.683098,-18.0544,-41.954372,0.),vec4(0.63792,0.5470648,1.1078634,0.),vec4(-1.5489894,-1.3075932,-2.6444845,0.))*buf[3]+mat4(vec4(-0.49252132,-0.39877754,-0.91366625,0.),vec4(0.95609266,0.7923952,1.640221,0.),vec4(0.30616966,0.15693925,0.8639857,0.),vec4(1.1825981,0.94504964,2.176963,0.))*buf[4]+mat4(vec4(0.35446745,0.3293795,0.59547555,0.),vec4(-0.58784515,-0.48177817,-1.0614829,0.),vec4(2.5271258,1.9991658,4.6846647,0.),vec4(0.13042648,0.08864098,0.30187556,0.))*buf[5]+mat4(vec4(-1.7718065,-1.4033192,-3.3355875,0.),vec4(3.1664357,2.638297,5.378702,0.),vec4(-3.1724713,-2.6107926,-5.549295,0.),vec4(-2.851368,-2.249092,-5.3013067,0.))*buf[6]+mat4(vec4(1.5203838,1.2212278,2.8404984,0.),vec4(1.5210563,1.2651345,2.683903,0.),vec4(2.9789467,2.4364579,5.2347264,0.),vec4(2.2270417,1.8825914,3.8028636,0.))*buf[7]+vec4(-1.5468478,-3.6171484,0.24762098,0.);
  buf[0]=sigmoid(buf[0]);
  return vec4(buf[0].x,buf[0].y,buf[0].z,1.);
}

float hash(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}

mat2 rotate(float a) {
  float c = cos(a);
  float s = sin(a);
  return mat2(c, s, -s, c);
}

void main() {
  vec2 css = gl_FragCoord.xy * uScale;
  vec2 uv = (css * 2.0 - uView) / uView.y;
  uv.y = -uv.y;
  vec2 anchor = vec2(uView.x / uView.y, -1.0);

  vec2 pointer = vec2(uPointer.x * 2.0 - uView.x, uPointer.y * 2.0 - uView.y) / uView.y;
  vec2 offset = uv - pointer;
  float touch = uPointer.z * exp(-dot(offset, offset) / (uPointer.w * uPointer.w));
  uv = pointer + rotate(touch * 0.6) * offset;
  uv -= uDrag * touch;

  float t = uTime;
  uv = rotate(0.06 * uFlow * sin(t * 0.17)) * uv;
  uv += 0.05 * uFlow * vec2(sin(t * 0.21), cos(t * 0.13));
  uv = anchor + mat2(uTurn.x, uTurn.y, -uTurn.y, uTurn.x) * uv * 2.0 / uZoom;
  uv += uWarp * vec2(sin(uv.y * 6.283 + t * 0.5), cos(uv.x * 6.283 + t * 0.5)) * 0.05;

  vec3 latent = uSeed + 0.1 * uFlow * vec3(sin(0.3 * t), sin(0.69 * t), sin(0.44 * t));
  latent += touch * vec3(0.12, -0.1, 0.16);
  latent.z += uUnfold;

  vec3 veil = cppn(uv, latent).rgb;
  veil += (hash(gl_FragCoord.xy) - 0.5) * uDither;
  outColor = vec4(veil, 1.0);
}`,pt=`#version 300 es
precision highp float;
uniform sampler2D uField;
uniform vec2 uResolution;
uniform vec2 uTexel;
uniform vec3 uColor;
uniform vec3 uInk;
uniform float uGain;
uniform float uSheen;
uniform float uGlow;
uniform float uPresence;
uniform float uGrain;
uniform float uFade;
uniform float uOpacity;
uniform float uTime;
uniform float uLightMode;
uniform vec4 uLight;
out vec4 outColor;

float hash(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}

float smootherstep(float edge, float x) {
  float t = clamp(x / max(edge, 0.0001), 0.0, 1.0);
  return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);
}

float level(vec2 uv, float lod) {
  return textureLod(uField, uv, lod).b;
}

void main() {
  vec2 uv = gl_FragCoord.xy / uResolution;
  float base = clamp(level(uv, 0.0), 0.0, 1.0);
  float glow = 0.0;
  glow += level(uv, 2.0) * 0.4;
  glow += level(uv, 3.0) * 0.3;
  glow += level(uv, 4.0) * 0.2;
  glow += level(uv, 5.0) * 0.1;

  float dx = level(uv + vec2(uTexel.x, 0.0), 0.0) - level(uv - vec2(uTexel.x, 0.0), 0.0);
  float dy = level(uv + vec2(0.0, uTexel.y), 0.0) - level(uv - vec2(0.0, uTexel.y), 0.0);
  vec2 slope = vec2(dx / (2.0 * uTexel.x) * (uResolution.y / uResolution.x), dy / (2.0 * uTexel.y));
  vec3 normal = normalize(vec3(-slope * 0.12, 1.0));
  vec2 pixel = gl_FragCoord.xy / uResolution.y;
  vec3 toLight = normalize(vec3(uLight.xy - pixel, 0.7));
  vec3 halfway = normalize(toLight + vec3(0.0, 0.0, 1.0));
  float facing = max(dot(normal, halfway), 0.0);
  float sheen = pow(facing, 40.0) * smoothstep(0.08, 0.7, base);
  float near = uLight.z * exp(-dot(uLight.xy - pixel, uLight.xy - pixel) / 0.2);

  float energy = pow(base, 2.2) * uGain * (1.0 + near * 0.4);
  energy += pow(glow, 2.2) * uGlow * uGain;
  energy *= uPresence;
  vec3 light = uColor * energy;
  light += uColor * energy * energy * 0.35;
  vec3 gleam = mix(uColor * 2.0, vec3(1.0), 0.55);
  light += gleam * sheen * uSheen * (0.8 + near * 0.4) * uPresence;

  float edge = uFade * 0.5;
  float mask = smootherstep(edge, uv.x) * smootherstep(edge, 1.0 - uv.x) * smootherstep(edge, uv.y) * smootherstep(edge, 1.0 - uv.y);
  mask *= uOpacity;
  float grain = (hash(gl_FragCoord.xy + fract(uTime * 7.31) * 113.0) - 0.5) * uGrain;
  float dither = (hash(gl_FragCoord.yx + 31.7) - 0.5) / 255.0;

  float peak = max(light.r, max(light.g, light.b));
  if (uLightMode > 0.5) {
    float cover = 1.0 - exp(-peak * 1.6);
    vec3 ink = mix(uInk, uInk * 0.82, smoothstep(0.5, 1.0, cover));
    ink = mix(ink, vec3(1.0), clamp(sheen * uSheen * 1.5, 0.0, 1.0) * 0.8);
    float alpha = clamp(cover * 0.85 * (1.0 + grain) + dither, 0.0, 1.0) * mask;
    outColor = vec4(ink * alpha, alpha);
  } else {
    vec3 color = 1.0 - exp(-light);
    color = pow(color, vec3(1.0 / 2.2));
    color = clamp(color + grain * peak + dither, 0.0, 1.0) * mask;
    outColor = vec4(color, max(color.r, max(color.g, color.b)));
  }
}`,gt=1.8,$e=9e5,Xe=(o,w,h)=>Math.min(h,Math.max(w,o)),xt=o=>{let w=Number(o)||0;if(!w)return[0,0,0];let h=m=>{let v=Math.sin(w*12.9898+m*78.233)*43758.5453;return v-Math.floor(v)-.5};return[h(1),h(2),h(3)]},Ke=(o,w,h)=>{let m=o.createShader(w);return m?(o.shaderSource(m,h),o.compileShader(m),o.getShaderParameter(m,o.COMPILE_STATUS)?m:(o.deleteShader(m),null)):null},Ze=(o,w)=>{let h=Ke(o,o.VERTEX_SHADER,ht),m=Ke(o,o.FRAGMENT_SHADER,w),v=o.createProgram();if(!h||!m||!v)return null;if(o.attachShader(v,h),o.attachShader(v,m),o.bindAttribLocation(v,0,"aPosition"),o.linkProgram(v),o.deleteShader(h),o.deleteShader(m),!o.getProgramParameter(v,o.LINK_STATUS))return o.deleteProgram(v),null;let G={},oe=o.getProgramParameter(v,o.ACTIVE_UNIFORMS);for(let N=0;N<oe;N++){let z=o.getActiveUniform(v,N);z&&(G[z.name]=o.getUniformLocation(v,z.name))}return{program:v,uniforms:G}},wt=({color:o="#6b12ff",speed:w=.5,scale:h=1,rotation:m=0,flow:v=1,warp:G=0,variation:oe=0,brightness:N=1,sheen:z=0,glow:be=.4,grain:Te=.03,quality:Re=.5,mouseInteraction:Me=!0,mouseStrength:Se=1,intro:Ae=!0,fade:Fe=0,opacity:_e=1,lightMode:ge=!1,paused:Pe=!1,dpr:xe,className:se="",...pe})=>{let ue=(0,we.useRef)(null),me=(0,we.useRef)(null),J=(0,we.useRef)(null),V={color:String(o),speed:w,scale:Math.max(.1,h),rotation:m,flow:Math.max(0,v),warp:Math.max(0,G),variation:oe,brightness:Math.max(0,N),sheen:Math.max(0,z),glow:Math.max(0,be),grain:Math.max(0,Te),quality:Xe(Re,.25,1),mouseInteraction:Me,mouseStrength:Math.max(0,Se),intro:Ae,fade:Xe(Fe,0,1),opacity:Xe(_e,0,1),lightMode:ge,paused:Pe,dpr:xe},_=(0,we.useRef)(V);return _.current=V,(0,we.useEffect)(()=>{let E=ue.current,e=me.current,r=e?.getContext("webgl2",{alpha:!0,premultipliedAlpha:!0,antialias:!1,depth:!1,stencil:!1,powerPreference:"high-performance"});if(!E||!e||!r)return;let i=!!r.getExtension("EXT_color_buffer_float"),O=Ze(r,vt),B=Ze(r,pt);if(!O||!B)return;let X=r.createBuffer(),re=r.createVertexArray();r.bindVertexArray(re),r.bindBuffer(r.ARRAY_BUFFER,X),r.bufferData(r.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),r.STATIC_DRAW),r.enableVertexAttribArray(0),r.vertexAttribPointer(0,2,r.FLOAT,!1,0,0);let A=r.createTexture(),b=r.createFramebuffer(),M={width:0,height:0},j=(g,T)=>{if(M.width===g&&M.height===T)return;M.width=g,M.height=T,r.bindTexture(r.TEXTURE_2D,A);let t=Math.floor(Math.log2(Math.max(g,T)))+1;r.texStorage2D(r.TEXTURE_2D,t,i?r.RGBA16F:r.RGBA8,g,T),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MIN_FILTER,r.LINEAR_MIPMAP_LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MAG_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE),r.bindFramebuffer(r.FRAMEBUFFER,b),r.framebufferTexture2D(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,A,0)},Y=document.createElement("canvas").getContext("2d",{willReadFrequently:!0}),F=window.matchMedia?.("(prefers-reduced-motion: reduce)").matches??!1,p=new Map,c=g=>{if(p.has(g))return p.get(g);let T=[1,1,1];if(Y){Y.clearRect(0,0,1,1),Y.fillStyle="#ffffff",Y.fillStyle=g,Y.fillRect(0,0,1,1);let[t,a,s]=Y.getImageData(0,0,1,1).data;T=[t,a,s].map(u=>Math.pow(u/255,2.2))}return p.set(g,T),T},R={width:1,height:1,fieldWidth:1,fieldHeight:1},S={x:0,y:0,inside:!1},n={clock:0,intro:_.current.intro&&!F?0:1,touch:0,x:0,y:0,vx:0,vy:0,dragX:0,dragY:0,lightX:.5,lightY:.15},C=0,L=0,$=!0,ie=()=>{let g=_.current,T=n.intro*n.intro*n.intro*(n.intro*(n.intro*6-15)+10);r.bindVertexArray(re),j(R.fieldWidth,R.fieldHeight);let t=O.uniforms;r.bindFramebuffer(r.FRAMEBUFFER,b),r.viewport(0,0,M.width,M.height),r.useProgram(O.program);let a=g.rotation*Math.PI/180,[s,u,x]=xt(g.variation);r.uniform2f(t.uView,R.width,R.height),r.uniform2f(t.uScale,R.width/M.width,R.height/M.height),r.uniform1f(t.uZoom,g.scale),r.uniform2f(t.uTurn,Math.cos(a),Math.sin(a)),r.uniform1f(t.uTime,n.clock),r.uniform1f(t.uFlow,g.flow),r.uniform1f(t.uWarp,g.warp),r.uniform3f(t.uSeed,.3948333106474662+s,.36+u,.14+x),r.uniform4f(t.uPointer,n.x,n.y,n.touch*g.mouseStrength*.9,.42),r.uniform2f(t.uDrag,n.dragX*2/R.height,n.dragY*2/R.height),r.uniform1f(t.uUnfold,(1-T)*.45),r.uniform1f(t.uDither,i?0:1/255),r.drawArrays(r.TRIANGLES,0,3),r.bindTexture(r.TEXTURE_2D,A),r.generateMipmap(r.TEXTURE_2D);let y=B.uniforms,U=c(g.color),D=.2126*U[0]+.7152*U[1]+.0722*U[2],f=Math.min(1,.2/Math.max(D,.001)),d=U.map(l=>Math.pow(Math.min(1,l*f),1/2.2));r.bindFramebuffer(r.FRAMEBUFFER,null),r.viewport(0,0,e.width,e.height),r.useProgram(B.program),r.uniform2f(y.uResolution,e.width,e.height),r.uniform2f(y.uTexel,1/M.width,1/M.height),r.uniform3fv(y.uColor,U),r.uniform3fv(y.uInk,d),r.uniform1f(y.uGain,1.15*g.brightness),r.uniform1f(y.uSheen,.5*g.sheen),r.uniform1f(y.uGlow,g.glow),r.uniform1f(y.uPresence,T),r.uniform1f(y.uGrain,g.grain),r.uniform1f(y.uFade,g.fade),r.uniform1f(y.uOpacity,g.opacity),r.uniform1f(y.uTime,n.clock%1e3),r.uniform1f(y.uLightMode,g.lightMode?1:0),r.uniform4f(y.uLight,n.lightX*R.width/R.height,1-n.lightY,n.touch*g.mouseStrength,0),r.activeTexture(r.TEXTURE0),r.bindTexture(r.TEXTURE_2D,A),r.uniform1i(y.uField,0),r.drawArrays(r.TRIANGLES,0,3)},ae=g=>{if(C=0,!$||document.hidden)return;let T=_.current,t=L?Math.min(.05,(g-L)/1e3):1/60;L=g;let a=!T.paused&&!F;a&&(n.clock+=t*T.speed),!T.intro||F?n.intro=1:n.intro<1&&(n.intro=Math.min(1,n.intro+t/gt));let s=T.mouseInteraction&&S.inside&&!F;s&&n.touch<.01&&(n.x=S.x,n.y=S.y);let u=1-Math.exp(-t*9),x=n.x,y=n.y;n.x+=(S.x-n.x)*u,n.y+=(S.y-n.y)*u;let U=(n.x-x)/Math.max(t,.001),D=(n.y-y)/Math.max(t,.001),f=1-Math.exp(-t*5);n.dragX+=(Xe(U*.12,-120,120)-n.dragX)*f,n.dragY+=(Xe(-D*.12,-120,120)-n.dragY)*f,n.touch+=((s?1:0)-n.touch)*(1-Math.exp(-t*(s?3:1.6)));let d=s?S.x/R.width:.5,l=s?S.y/R.height:.15,P=1-Math.exp(-t*4);n.lightX+=(d-n.lightX)*P,n.lightY+=(l-n.lightY)*P,ie();let W=n.intro<1||Math.abs((s?1:0)-n.touch)>.002||Math.abs(n.dragX)+Math.abs(n.dragY)>.05||Math.abs(S.x-n.x)+Math.abs(S.y-n.y)>.3||Math.abs(d-n.lightX)+Math.abs(l-n.lightY)>5e-4;a||W?C=requestAnimationFrame(ae):L=0},Q=()=>{!C&&$&&!document.hidden&&(C=requestAnimationFrame(ae))},q=()=>{let g=_.current,T=Math.max(1,E.clientWidth),t=Math.max(1,E.clientHeight),a=Math.min(g.dpr||window.devicePixelRatio||1,2);R.width=T,R.height=t,e.width=Math.max(1,Math.round(T*a)),e.height=Math.max(1,Math.round(t*a));let s=g.quality;T*t*s*s>$e&&(s=Math.sqrt($e/(T*t))),R.fieldWidth=Math.max(1,Math.round(T*s)),R.fieldHeight=Math.max(1,Math.round(t*s)),C||ie(),Q()},ee=g=>{let T=E.getBoundingClientRect();S.x=g.clientX-T.left,S.y=g.clientY-T.top,S.inside=S.x>=0&&S.y>=0&&S.x<=T.width&&S.y<=T.height,Q()},K=()=>{S.inside=!1,Q()},de=()=>{L=0,Q()},he=new ResizeObserver(q);he.observe(E);let le=new IntersectionObserver(g=>{$=g.some(T=>T.isIntersecting),$&&(L=0,Q())});le.observe(E),window.addEventListener("pointermove",ee,{passive:!0}),document.documentElement.addEventListener("pointerleave",K),document.addEventListener("visibilitychange",de),q();let H=_.current.quality,ce=_.current.dpr;return J.current=()=>{let g=_.current;if(g.quality!==H||g.dpr!==ce){H=g.quality,ce=g.dpr,q();return}C||ie(),Q()},()=>{cancelAnimationFrame(C),J.current=null,he.disconnect(),le.disconnect(),window.removeEventListener("pointermove",ee),document.documentElement.removeEventListener("pointerleave",K),document.removeEventListener("visibilitychange",de),r.deleteTexture(A),r.deleteFramebuffer(b),r.deleteProgram(O.program),r.deleteProgram(B.program),r.deleteBuffer(X),r.deleteVertexArray(re),r.getExtension("WEBGL_lose_context")?.loseContext()}},[]),(0,we.useEffect)(()=>{J.current?.()}),React.createElement("div",{ref:ue,className:`dark-veil-container${se?` ${se}`:""}`,...pe},React.createElement("canvas",{ref:me,className:"dark-veil-canvas","aria-hidden":"true"}))},je=wt;var Ee=Ie("react");var Et=`#version 300 es
in vec2 aPosition;
void main() {
  gl_Position = vec4(aPosition, 0.0, 1.0);
}`,ot=`
uniform vec2 uView;
uniform float uScale;
uniform float uRotation;
uniform float uTime;
uniform float uWave;
uniform float uRipple;
uniform float uFold;
uniform vec2 uShift;
uniform vec4 uPointer;
uniform vec2 uDrag;
uniform vec4 uWaves[4];

const float e = 2.71828182845904523536;

float noise(vec2 texCoord) {
  float G = e;
  vec2 r = (G * sin(G * texCoord));
  return fract(r.x * r.y * (1.0 + texCoord.x));
}

vec2 rotateUvs(vec2 uv, float angle) {
  float c = cos(angle);
  float s = sin(angle);
  mat2 rot = mat2(c, -s, s, c);
  return rot * uv;
}

vec2 bend(vec2 uv) {
  vec2 aspect = vec2(uView.x / uView.y, 1.0);
  vec2 offset = (uv - uPointer.xy) * aspect;
  float touch = uPointer.z * exp(-dot(offset, offset) / (uPointer.w * uPointer.w));
  uv -= uDrag * touch;
  for (int i = 0; i < 4; i++) {
    vec4 wave = uWaves[i];
    if (wave.w <= 0.0) continue;
    vec2 q = (uv - wave.xy) * aspect;
    float dist = length(q);
    float front = dist - wave.z;
    float ring = exp(-front * front * 60.0) * wave.w;
    uv += q / max(dist, 0.0001) / aspect * ring * 0.034 * sin(front * 34.0);
  }
  return uv;
}

float silk(vec2 vUv) {
  vec2 uv = rotateUvs(vUv * uScale, uRotation);
  vec2 tex = uv * uScale + uShift;
  float tOffset = uTime;
  tex.y += 0.03 * uWave * sin(8.0 * tex.x - tOffset);
  return 0.6 + 0.4 * uFold * sin(5.0 * (tex.x + tex.y + cos(3.0 * tex.x + 5.0 * tex.y) + 0.02 * tOffset) + uRipple * sin(20.0 * (tex.x + tex.y - 0.1 * tOffset)));
}
`,yt=`#version 300 es
precision highp float;
${ot}
out vec4 outColor;

void main() {
  vec2 vUv = gl_FragCoord.xy / uView;
  float pattern = silk(bend(vUv));
  float n = clamp((pattern - 0.2) / 0.8, 0.0, 1.0);
  outColor = vec4(pow(n, 6.0), 0.0, 0.0, 1.0);
}`,bt=`#version 300 es
precision highp float;
${ot}
uniform sampler2D uBloom;
uniform vec3 uColor;
uniform vec3 uSheenColor;
uniform float uNoiseIntensity;
uniform float uDepth;
uniform float uSheen;
uniform float uGlow;
uniform float uLightMode;
uniform vec3 uLight;
uniform vec2 uStep;
uniform float uPresence;
uniform float uFade;
out vec4 outColor;

float smootherstep01(float t) {
  t = clamp(t, 0.0, 1.0);
  return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);
}

vec3 softClip(vec3 c) {
  vec3 over = max(c - 0.75, 0.0);
  return min(c, 0.75) + 0.25 * (1.0 - exp(-over * 4.0));
}

void main() {
  vec2 vUv = gl_FragCoord.xy / uView;
  vec2 coord = bend(vUv);
  float pattern = silk(coord);
  float rnd = noise(gl_FragCoord.xy);
  float n = clamp((pattern - 0.2) / 0.8, 0.0, 1.0);

  float gx = silk(coord + vec2(uStep.x, 0.0)) - pattern;
  float gy = silk(coord + vec2(0.0, uStep.y)) - pattern;
  vec3 normal = normalize(vec3(-gx * 26.0, -gy * 26.0, 1.0));
  vec3 toLight = normalize(vec3(uLight.xy, 0.85));
  float relief = 1.0 + (dot(normal, toLight) - toLight.z) * 1.8 * uDepth;
  vec3 halfway = normalize(toLight + vec3(0.0, 0.0, 1.0));
  float gloss = pow(max(dot(normal, halfway), 0.0), 48.0) * smoothstep(0.25, 0.85, n);
  float crest = pow(n, 5.0);
  float shine = (gloss * 0.85 + crest * 0.4) * uSheen * (1.0 + uLight.z * 0.6);

  float bloom = 0.0;
  if (uGlow > 0.0) {
    bloom += textureLod(uBloom, vUv, 1.0).r * 0.35;
    bloom += textureLod(uBloom, vUv, 2.0).r * 0.3;
    bloom += textureLod(uBloom, vUv, 3.0).r * 0.2;
    bloom += textureLod(uBloom, vUv, 4.0).r * 0.15;
  }

  vec3 result;
  if (uLightMode > 0.5) {
    float fold = smoothstep(0.28, 0.9, pattern);
    float specular = smoothstep(0.72, 0.98, pattern);
    vec3 shadowColor = uColor * (0.72 - 0.12 * uDepth);
    vec3 bodyColor = min(uColor * 1.18, vec3(1.0));
    vec3 lightBase = mix(shadowColor, bodyColor, fold) * mix(1.0, relief, 0.6);
    lightBase = mix(lightBase, vec3(1.0), clamp(specular * 0.92 + shine * 0.22 + bloom * uGlow * 0.2, 0.0, 1.0));
    float fineNoise = noise(gl_FragCoord.xy * 0.63 + vec2(17.0, 41.0));
    float grainSignal = (rnd + fineNoise - 1.0);
    float grainStrength = clamp(uNoiseIntensity * 0.038, 0.0, 0.16);
    result = clamp(lightBase + grainSignal * grainStrength, 0.0, 1.0);
  } else {
    float grain = rnd / 15.0 * uNoiseIntensity;
    float floorValue = mix(0.2, 0.03, uDepth);
    float curve = uDepth > 0.0 ? pow(n, 1.0 + 1.4 * uDepth) : n;
    float shade = uDepth > 0.0 ? floorValue + (1.0 - floorValue) * curve : pattern;
    vec3 tone = mix(uColor, pow(uColor, vec3(1.45)), (1.0 - n) * uDepth);
    vec3 lit = tone * shade * relief - vec3(grain);
    vec3 tint = mix(uColor, uSheenColor, 0.8);
    vec3 extra = tint * (shine + bloom * uGlow * 0.55);
    float blend = clamp((uSheen + uGlow) * 4.0, 0.0, 1.0);
    result = mix(clamp(lit, 0.0, 1.0), clamp(softClip(lit + extra), 0.0, 1.0), blend);
  }

  float edge = uFade * 0.5;
  float mask = 1.0;
  if (edge > 0.0) {
    mask = smootherstep01(vUv.x / edge) * smootherstep01((1.0 - vUv.x) / edge);
    mask *= smootherstep01(vUv.y / edge) * smootherstep01((1.0 - vUv.y) / edge);
  }
  float alpha = uPresence * mask;
  outColor = vec4(result * alpha, alpha);
}`,Tt=2.2,Rt=1.6,Qe=1.6,De=[-.55,.7],Je=Math.hypot(De[0],De[1]),ke=(o,w,h)=>Math.min(h,Math.max(w,o)),Mt=o=>o*o*o*(o*(o*6-15)+10),St=o=>{let w=Number(o)||0;if(!w)return[0,0];let h=m=>{let v=Math.sin(w*12.9898+m*78.233)*43758.5453;return v-Math.floor(v)-.5};return[h(1)*6,h(2)*6]},et=(o,w,h)=>{let m=o.createShader(w);return m?(o.shaderSource(m,h),o.compileShader(m),o.getShaderParameter(m,o.COMPILE_STATUS)?m:(o.deleteShader(m),null)):null},tt=(o,w)=>{let h=et(o,o.VERTEX_SHADER,Et),m=et(o,o.FRAGMENT_SHADER,w),v=o.createProgram();if(!h||!m||!v)return null;if(o.attachShader(v,h),o.attachShader(v,m),o.bindAttribLocation(v,0,"aPosition"),o.linkProgram(v),o.deleteShader(h),o.deleteShader(m),!o.getProgramParameter(v,o.LINK_STATUS))return o.deleteProgram(v),null;let G={},oe=o.getProgramParameter(v,o.ACTIVE_UNIFORMS);for(let N=0;N<oe;N++){let z=o.getActiveUniform(v,N);z&&(G[z.name.replace(/\[0\]$/,"")]=o.getUniformLocation(v,z.name))}return{program:v,uniforms:G}},At=({speed:o=5,scale:w=1,color:h="#7B7481",sheenColor:m="#ffffff",noiseIntensity:v=1.5,rotation:G=0,sheen:oe=.5,depth:N=.5,glow:z=.3,ripple:be=1,wave:Te=1,variation:Re=0,mouseInteraction:Me=!0,interactionStrength:Se=1,clickRipple:Ae=!0,intro:Fe=!0,fade:_e=0,lightMode:ge=!1,paused:Pe=!1,dpr:xe,className:se="",style:pe})=>{let ue=(0,Ee.useRef)(null),me=(0,Ee.useRef)(null),J=(0,Ee.useRef)(null),V=(0,Ee.useRef)(null);return V.current={speed:o,scale:w,color:String(h),sheenColor:String(m),noiseIntensity:Math.max(0,v),rotation:G,sheen:Math.max(0,oe),depth:ke(N,0,1),glow:Math.max(0,z),ripple:Math.max(0,be),wave:Math.max(0,Te),variation:Re,mouseInteraction:Me,interactionStrength:Math.max(0,Se),clickRipple:Ae,intro:Fe,fade:ke(_e,0,1),lightMode:ge,paused:Pe,dpr:xe},(0,Ee.useEffect)(()=>{let _=ue.current,E=me.current,e=E?.getContext("webgl2",{alpha:!0,premultipliedAlpha:!0,antialias:!1,depth:!1,stencil:!1,powerPreference:"high-performance"});if(!_||!E||!e)return;let r=tt(e,yt),i=tt(e,bt);if(!r||!i)return;let O=e.createBuffer(),B=e.createVertexArray();e.bindVertexArray(B),e.bindBuffer(e.ARRAY_BUFFER,O),e.bufferData(e.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),e.STATIC_DRAW),e.enableVertexAttribArray(0),e.vertexAttribPointer(0,2,e.FLOAT,!1,0,0);let X=e.createTexture(),re=e.createFramebuffer(),A={width:0,height:0},b=(t,a)=>{A.width===t&&A.height===a||(A.width=t,A.height=a,e.bindTexture(e.TEXTURE_2D,X),e.texImage2D(e.TEXTURE_2D,0,e.RGBA8,t,a,0,e.RGBA,e.UNSIGNED_BYTE,null),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR_MIPMAP_LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE),e.bindFramebuffer(e.FRAMEBUFFER,re),e.framebufferTexture2D(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,X,0))},M=document.createElement("canvas").getContext("2d",{willReadFrequently:!0}),j=new Map,Y=t=>{if(j.has(t))return j.get(t);let a=[1,1,1];if(M){M.clearRect(0,0,1,1),M.fillStyle="#ffffff",M.fillStyle=t,M.fillRect(0,0,1,1);let[s,u,x]=M.getImageData(0,0,1,1).data;a=[s/255,u/255,x/255]}return j.set(t,a),a},F=window.matchMedia?.("(prefers-reduced-motion: reduce)").matches??!1,p={width:1,height:1,ratio:1},c={x:0,y:0,inside:!1},R=[],S=new Float32Array(16),n={flow:0,intro:V.current.intro&&!F?0:1,touch:0,x:0,y:0,dragX:0,dragY:0,lightX:De[0],lightY:De[1]},C=0,L=0,$=!0,ie=(t,a,s,u,x)=>{let[y,U]=St(u.variation);e.uniform2f(t.uView,a,s),e.uniform1f(t.uScale,u.scale),e.uniform1f(t.uRotation,u.rotation),e.uniform1f(t.uTime,n.flow-Rt*(1-x)),e.uniform1f(t.uWave,u.wave),e.uniform1f(t.uRipple,u.ripple),e.uniform1f(t.uFold,.25+.75*x),e.uniform2f(t.uShift,y,U),e.uniform4f(t.uPointer,n.x/p.width,1-n.y/p.height,n.touch*u.interactionStrength,.32),e.uniform2f(t.uDrag,n.dragX,n.dragY),e.uniform4fv(t.uWaves,S)},ae=()=>{let t=V.current,a=Mt(n.intro),s=1-Math.pow(1-n.intro,3);e.bindVertexArray(B),S.fill(0),R.slice(-4).forEach((x,y)=>{S.set([x.x,x.y,x.age*.6,Math.exp(-x.age/(Qe*.45))],y*4)}),t.glow>0&&(b(Math.max(1,Math.round(E.width/4)),Math.max(1,Math.round(E.height/4))),e.bindFramebuffer(e.FRAMEBUFFER,re),e.viewport(0,0,A.width,A.height),e.useProgram(r.program),ie(r.uniforms,A.width,A.height,t,a),e.drawArrays(e.TRIANGLES,0,3),e.bindTexture(e.TEXTURE_2D,X),e.generateMipmap(e.TEXTURE_2D));let u=i.uniforms;e.bindFramebuffer(e.FRAMEBUFFER,null),e.viewport(0,0,E.width,E.height),e.useProgram(i.program),ie(u,E.width,E.height,t,a),e.uniform3fv(u.uColor,Y(t.color)),e.uniform3fv(u.uSheenColor,Y(t.sheenColor)),e.uniform1f(u.uNoiseIntensity,t.noiseIntensity),e.uniform1f(u.uDepth,t.depth),e.uniform1f(u.uSheen,t.sheen),e.uniform1f(u.uGlow,t.glow),e.uniform1f(u.uLightMode,t.lightMode?1:0),e.uniform3f(u.uLight,n.lightX,n.lightY,n.touch*t.interactionStrength),e.uniform2f(u.uStep,p.ratio/E.width,p.ratio/E.height),e.uniform1f(u.uPresence,s),e.uniform1f(u.uFade,t.fade),e.activeTexture(e.TEXTURE0),e.bindTexture(e.TEXTURE_2D,X),e.uniform1i(u.uBloom,0),e.drawArrays(e.TRIANGLES,0,3)},Q=t=>{if(C=0,!$||document.hidden)return;let a=V.current,s=L?Math.min(.05,(t-L)/1e3):1/60;L=t;let u=!a.paused&&!F&&a.speed!==0;u&&(n.flow+=s*.1*a.speed),!a.intro||F?n.intro=1:n.intro<1&&(n.intro=Math.min(1,n.intro+s/Tt));let x=a.mouseInteraction&&c.inside&&!F;x&&n.touch<.01&&(n.x=c.x,n.y=c.y);let y=1-Math.exp(-s*10),U=n.x,D=n.y;n.x+=(c.x-n.x)*y,n.y+=(c.y-n.y)*y;let f=(n.x-U)/Math.max(s,.001)/p.height,d=(n.y-D)/Math.max(s,.001)/p.height,l=1-Math.exp(-s*4);n.dragX+=(ke(f*.03,-.06,.06)-n.dragX)*l,n.dragY+=(ke(-d*.03,-.06,.06)-n.dragY)*l,n.touch+=((x?1:0)-n.touch)*(1-Math.exp(-s*(x?3.5:1.4)));let P=De[0],W=De[1];if(x){let k=(c.x/p.width-.5)*(p.width/p.height),te=.5-c.y/p.height,fe=Math.hypot(k,te);fe>.04?(P=k/fe*Je,W=te/fe*Je):(P=n.lightX,W=n.lightY)}let Z=1-Math.exp(-s*3);n.lightX+=(P-n.lightX)*Z,n.lightY+=(W-n.lightY)*Z;for(let k=R.length-1;k>=0;k--)R[k].age+=s,R[k].age>Qe*2.5&&R.splice(k,1);ae();let I=n.intro<1||R.length>0||Math.abs((x?1:0)-n.touch)>.002||Math.abs(n.dragX)+Math.abs(n.dragY)>2e-4||Math.abs(c.x-n.x)+Math.abs(c.y-n.y)>.3||Math.abs(P-n.lightX)+Math.abs(W-n.lightY)>.001;u||I?C=requestAnimationFrame(Q):L=0},q=()=>{!C&&$&&!document.hidden&&(C=requestAnimationFrame(Q))},ee=()=>{let t=V.current,a=Math.max(1,_.clientWidth),s=Math.max(1,_.clientHeight),u=Math.min(t.dpr||window.devicePixelRatio||1,2);p.width=a,p.height=s,p.ratio=u,E.width=Math.max(1,Math.round(a*u)),E.height=Math.max(1,Math.round(s*u)),C||ae(),q()},K=t=>{let a=_.getBoundingClientRect(),s=t.clientX-a.left,u=t.clientY-a.top;return{x:s,y:u,inside:s>=0&&u>=0&&s<=a.width&&u<=a.height}},de=t=>{let a=K(t);c.x=a.x,c.y=a.y,c.inside=a.inside,q()},he=t=>{if(!V.current.clickRipple||F)return;let s=K(t);s.inside&&(R.push({x:s.x/p.width,y:1-s.y/p.height,age:0}),R.length>4&&R.shift(),q())},le=()=>{c.inside=!1,q()},H=()=>{L=0,q()},ce=new ResizeObserver(ee);ce.observe(_);let g=new IntersectionObserver(t=>{$=t.some(a=>a.isIntersecting),$&&(L=0,q())});g.observe(_),window.addEventListener("pointermove",de,{passive:!0}),window.addEventListener("pointerdown",he,{passive:!0}),document.documentElement.addEventListener("pointerleave",le),document.addEventListener("visibilitychange",H),ee();let T=V.current.dpr;return J.current=()=>{let t=V.current;if(t.dpr!==T){T=t.dpr,ee();return}C||ae(),q()},()=>{cancelAnimationFrame(C),J.current=null,ce.disconnect(),g.disconnect(),window.removeEventListener("pointermove",de),window.removeEventListener("pointerdown",he),document.documentElement.removeEventListener("pointerleave",le),document.removeEventListener("visibilitychange",H),e.deleteTexture(X),e.deleteFramebuffer(re),e.deleteProgram(r.program),e.deleteProgram(i.program),e.deleteBuffer(O),e.deleteVertexArray(B),e.getExtension("WEBGL_lose_context")?.loseContext()}},[]),(0,Ee.useEffect)(()=>{J.current?.()}),React.createElement("div",{ref:ue,className:`silk-container${se?` ${se}`:""}`,style:pe},React.createElement("canvas",{ref:me,className:"silk-canvas","aria-hidden":"true"}))},rt=At;var ye=Ie("react");var Ft=`#version 300 es
in vec2 aPosition;
out vec2 vUv;
void main() {
  vUv = aPosition * 0.5 + 0.5;
  gl_Position = vec4(aPosition, 0.0, 1.0);
}`,_t=`#version 300 es
precision highp float;
uniform vec2 uResolution;
uniform float uTime;
uniform vec3 uColor;
uniform vec2 uMouse;
uniform float uAmplitude;
uniform float uScale;
uniform float uRotation;
uniform int uDetail;
uniform float uWarp;
uniform float uHue;
uniform float uSaturation;
uniform float uBrightness;
uniform float uContrast;
uniform float uGrain;
uniform float uSeed;
uniform float uFade;
uniform float uOpacity;
uniform sampler2D uField;
uniform float uStir;
uniform vec3 uPointer;
uniform float uSheen;
uniform vec4 uSwirls[6];
in vec2 vUv;
out vec4 outColor;

vec3 hueRotate(vec3 c, float angle) {
  const vec3 k = vec3(0.57735027);
  float ca = cos(angle);
  return c * ca + cross(k, c) * sin(angle) + k * dot(k, c) * (1.0 - ca);
}

float smootherstep(float edge, float x) {
  float t = clamp(x / edge, 0.0, 1.0);
  return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);
}

float hash(vec2 p) {
  p = fract(p * vec2(443.897, 441.423));
  p += dot(p, p.yx + 19.19);
  return fract((p.x + p.y) * p.x);
}

void main() {
  float mr = min(uResolution.x, uResolution.y);
  vec2 aspect = uResolution / mr;
  vec2 st = vUv - texture(uField, vUv).rg * uStir;

  for (int k = 0; k < 6; k++) {
    vec4 swirl = uSwirls[k];
    if (swirl.w == 0.0) continue;
    vec2 delta = (st - swirl.xy) * aspect;
    float angle = swirl.w * exp(-dot(delta, delta) / (swirl.z * swirl.z));
    float ca = cos(angle);
    float sa = sin(angle);
    st = swirl.xy + vec2(ca * delta.x - sa * delta.y, sa * delta.x + ca * delta.y) / aspect;
  }

  vec2 uv = (st * 2.0 - 1.0) * aspect;
  float c = cos(uRotation);
  float s = sin(uRotation);
  uv = mat2(c, -s, s, c) * uv / uScale;
  uv += (uMouse - vec2(0.5)) * uAmplitude;

  float d = -uTime * 0.5;
  float a = 0.0;
  for (int i = 0; i < 24; i++) {
    if (i >= uDetail) break;
    float fi = float(i);
    a += cos(fi - d - a * uv.x * uWarp);
    d += sin(uv.y * fi + a);
  }
  d += uTime * 0.5;
  vec3 col = vec3(cos(uv * vec2(d, a)) * 0.6 + 0.4, cos(a + d) * 0.5 + 0.5);
  col = cos(col * cos(vec3(d, a, 2.5)) * 0.5 + 0.5) * uColor;

  vec2 toPointer = (vUv - uPointer.xy) * aspect;
  col += col * uPointer.z * uSheen * 0.8 * exp(-dot(toPointer, toPointer) / 0.09);

  col = hueRotate(col, uHue);
  float luma = dot(col, vec3(0.2126, 0.7152, 0.0722));
  col = mix(vec3(luma), col, uSaturation);
  col = (col - 0.5) * uContrast + 0.5;
  col *= uBrightness;
  col += (hash(gl_FragCoord.xy + uSeed) - 0.5) * uGrain * 0.12;
  col = clamp(col, 0.0, 1.0);

  float alpha = uOpacity;
  if (uFade > 0.0) {
    vec2 px = vUv * uResolution;
    float edge = uFade * mr * 0.5;
    alpha *= smootherstep(edge, px.x) * smootherstep(edge, uResolution.x - px.x);
    alpha *= smootherstep(edge, px.y) * smootherstep(edge, uResolution.y - px.y);
  }
  outColor = vec4(col * alpha, alpha);
}`,Pt=48,nt=6,Be=3.2,Ue=(o,w,h)=>Math.min(h,Math.max(w,o)),it=(o,w,h)=>{let m=o.createShader(w);return m?(o.shaderSource(m,h),o.compileShader(m),o.getShaderParameter(m,o.COMPILE_STATUS)?m:(o.deleteShader(m),null)):null},Lt=({color:o=[1,1,1],speed:w=1,amplitude:h=.1,mouseReact:m=!0,scale:v=1,detail:G=8,rotation:oe=0,warp:N=1,hueShift:z=0,saturation:be=1,brightness:Te=1.5,contrast:Re=1,stir:Me=.5,sheen:Se=.3,clickSwirl:Ae=!0,grain:Fe=0,fade:_e=0,opacity:ge=1,resolution:Pe=1,paused:xe=!1,className:se="",style:pe})=>{let ue=(0,ye.useRef)(null),me=(0,ye.useRef)(null),J=(0,ye.useRef)(null),_={colorKey:Array.isArray(o)?o.join(","):String(o),color:o,speed:w,amplitude:h,mouseReact:m,scale:Math.max(.05,v),detail:Ue(Math.round(G),1,24),rotation:oe,warp:N,hueShift:z,saturation:Math.max(0,be),brightness:Math.max(0,Te),contrast:Math.max(0,Re),stir:Math.max(0,Me),sheen:Math.max(0,Se),clickSwirl:Ae,grain:Ue(Fe,0,1),fade:Ue(_e,0,1),opacity:Ue(ge,0,1),resolution:Ue(Pe,.1,2),paused:xe},E=(0,ye.useRef)(_);return E.current=_,(0,ye.useEffect)(()=>{let e=ue.current,r=me.current,i=r?.getContext("webgl2",{alpha:!0,premultipliedAlpha:!0,antialias:!1});if(!e||!r||!i)return;let O=it(i,i.VERTEX_SHADER,Ft),B=it(i,i.FRAGMENT_SHADER,_t),X=i.createProgram();if(!O||!B||!X||(i.attachShader(X,O),i.attachShader(X,B),i.linkProgram(X),!i.getProgramParameter(X,i.LINK_STATUS)))return;i.useProgram(X);let re=i.createBuffer();i.bindBuffer(i.ARRAY_BUFFER,re),i.bufferData(i.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),i.STATIC_DRAW);let A=i.getAttribLocation(X,"aPosition");i.enableVertexAttribArray(A),i.vertexAttribPointer(A,2,i.FLOAT,!1,0,0);let b={};for(let t of["uResolution","uTime","uColor","uMouse","uAmplitude","uScale","uRotation","uDetail","uWarp","uHue","uSaturation","uBrightness","uContrast","uGrain","uSeed","uFade","uOpacity","uField","uStir","uPointer","uSheen","uSwirls"])b[t]=i.getUniformLocation(X,t);let M=i.createTexture();i.activeTexture(i.TEXTURE0),i.bindTexture(i.TEXTURE_2D,M),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MIN_FILTER,i.LINEAR),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MAG_FILTER,i.LINEAR),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE),i.uniform1i(b.uField,0);let j=document.createElement("canvas");j.width=1,j.height=1;let Y=j.getContext("2d",{willReadFrequently:!0}),F=window.matchMedia?.("(prefers-reduced-motion: reduce)").matches??!1,p={x:.5,y:.5,px:0,py:0,inside:!1,tracked:!1},c={width:1,height:1,phase:0,mouse:[.5,.5],presence:0,color:[1,1,1],colorKey:"",cols:0,rows:0,field:new Float32Array(0),scratch:new Float32Array(0),fieldActive:!1,swirls:[],seed:0},R=new Float32Array(nt*4),S=0,n=0,C=!0,L=!0,$=t=>{if(t.colorKey===c.colorKey)return;if(c.colorKey=t.colorKey,Array.isArray(t.color)){c.color=[0,1,2].map(x=>Ue(Number(t.color[x]??1),0,1));return}if(!Y)return;Y.clearRect(0,0,1,1),Y.fillStyle="#ffffff",Y.fillStyle=String(t.color),Y.fillRect(0,0,1,1);let[a,s,u]=Y.getImageData(0,0,1,1).data;c.color=[a/255,s/255,u/255]},ie=()=>{let t=Pt,a=Ue(Math.round(t*c.height/c.width),6,96);t===c.cols&&a===c.rows||(c.cols=t,c.rows=a,c.field=new Float32Array(t*a*2),c.scratch=new Float32Array(t*a*2),i.activeTexture(i.TEXTURE0),i.bindTexture(i.TEXTURE_2D,M),i.texImage2D(i.TEXTURE_2D,0,i.RG16F,t,a,0,i.RG,i.FLOAT,c.field))},ae=(t,a,s,u)=>{let{cols:x,rows:y,field:U}=c,D=.22,f=c.width/c.height,d=Math.max(0,Math.floor((t-D/f)*x)),l=Math.min(x-1,Math.ceil((t+D/f)*x)),P=Math.max(0,Math.floor((a-D)*y)),W=Math.min(y-1,Math.ceil((a+D)*y));for(let Z=P;Z<=W;Z++)for(let I=d;I<=l;I++){let k=((I+.5)/x-t)*f,te=(Z+.5)/y-a,fe=1-(k*k+te*te)/(D*D);if(fe<=0)continue;let Ce=(Z*x+I)*2,Le=U[Ce]+s*fe*fe*3.2,Ne=U[Ce+1]+u*fe*fe*3.2,Ge=Math.hypot(Le,Ne),ze=.4,Ve=Ge>0?ze*Math.tanh(Ge/ze)/Ge:0;U[Ce]=Le*Ve,U[Ce+1]=Ne*Ve}c.fieldActive=!0},Q=t=>{let{cols:a,rows:s,field:u,scratch:x}=c,y=Math.exp(-t*1.4),U=0;for(let D=0;D<s;D++)for(let f=0;f<a;f++){let d=(D*a+f)*2,l=(D*a+Math.max(0,f-1))*2,P=(D*a+Math.min(a-1,f+1))*2,W=(Math.max(0,D-1)*a+f)*2,Z=(Math.min(s-1,D+1)*a+f)*2;for(let I=0;I<2;I++){let k=(u[d+I]*12+u[l+I]+u[P+I]+u[W+I]+u[Z+I])/16;x[d+I]=k*y,U=Math.max(U,Math.abs(x[d+I]))}}u.set(x),U<4e-4&&(u.fill(0),c.fieldActive=!1)},q=()=>{let t=E.current;$(t),ie(),i.viewport(0,0,r.width,r.height),i.activeTexture(i.TEXTURE0),i.bindTexture(i.TEXTURE_2D,M),i.texSubImage2D(i.TEXTURE_2D,0,0,0,c.cols,c.rows,i.RG,i.FLOAT,c.field),R.fill(0),c.swirls.forEach((a,s)=>{let u=.21*(1+.4*a.age),x=Math.exp(-a.age*1.35)-Math.exp(-a.age*10),y=Math.min(1,(Be-a.age)/.8);R.set([a.x,a.y,u,3*x*y*(.21/u)**2],s*4)}),i.uniform2f(b.uResolution,c.width,c.height),i.uniform1f(b.uTime,c.phase),i.uniform3f(b.uColor,c.color[0],c.color[1],c.color[2]),i.uniform2f(b.uMouse,c.mouse[0],c.mouse[1]),i.uniform1f(b.uAmplitude,t.amplitude),i.uniform1f(b.uScale,t.scale),i.uniform1f(b.uRotation,t.rotation*Math.PI/180),i.uniform1i(b.uDetail,t.detail),i.uniform1f(b.uWarp,t.warp),i.uniform1f(b.uHue,t.hueShift*Math.PI/180),i.uniform1f(b.uSaturation,t.saturation),i.uniform1f(b.uBrightness,t.brightness),i.uniform1f(b.uContrast,t.contrast),i.uniform1f(b.uGrain,t.grain),i.uniform1f(b.uSeed,c.seed),i.uniform1f(b.uFade,t.fade),i.uniform1f(b.uOpacity,t.opacity),i.uniform1f(b.uStir,t.mouseReact?t.stir:0),i.uniform3f(b.uPointer,p.x,p.y,t.mouseReact?c.presence:0),i.uniform1f(b.uSheen,t.sheen),i.uniform4fv(b.uSwirls,R),i.clearColor(0,0,0,0),i.clear(i.COLOR_BUFFER_BIT),i.drawArrays(i.TRIANGLES,0,3)},ee=t=>{if(S=0,!L||!C)return;let a=E.current,s=n?Math.min(.05,(t-n)/1e3):1/60;n=t;let u=!a.paused&&!F;u&&(c.phase+=s*a.speed);let x=a.mouseReact&&p.tracked?[p.x,p.y]:[.5,.5],y=1-Math.exp(-s*5);c.mouse[0]+=(x[0]-c.mouse[0])*y,c.mouse[1]+=(x[1]-c.mouse[1])*y,c.presence+=((p.inside?1:0)-c.presence)*(1-Math.exp(-s*4)),c.fieldActive&&Q(s),c.swirls=c.swirls.filter(D=>(D.age+=s)<Be),a.grain>0&&u&&(c.seed=Math.floor(t/42)%997),q();let U=Math.abs(x[0]-c.mouse[0])>5e-4||Math.abs(x[1]-c.mouse[1])>5e-4||Math.abs((p.inside?1:0)-c.presence)>.002;u||U||c.fieldActive||c.swirls.length?S=requestAnimationFrame(ee):n=0},K=()=>{S||!L||!C||(S=requestAnimationFrame(ee))},de=t=>{let a=e.getBoundingClientRect();return{x:(t.clientX-a.left)/Math.max(1,a.width),y:1-(t.clientY-a.top)/Math.max(1,a.height)}},he=t=>{let a=E.current,{x:s,y:u}=de(t),x=s>=0&&s<=1&&u>=0&&u<=1;x&&a.mouseReact&&!F&&p.inside&&a.stir>0&&ae(s,u,s-p.x,u-p.y),p.x=s,p.y=u,p.inside=x,x&&(p.tracked=!0),K()},le=()=>{p.inside=!1,K()},H=t=>{if(!E.current.clickSwirl||F)return;let{x:s,y:u}=de(t);if(!(s<0||s>1||u<0||u>1)){if(c.swirls.length>=nt){if(c.swirls[0].age<Be-.4)return;c.swirls.shift()}c.swirls.push({x:s,y:u,age:0}),K()}},ce=()=>{let t=E.current,a=Math.min(window.devicePixelRatio||1,2)*t.resolution;c.width=Math.max(1,e.clientWidth),c.height=Math.max(1,e.clientHeight),r.width=Math.max(1,Math.round(c.width*a)),r.height=Math.max(1,Math.round(c.height*a)),q(),K()};J.current=()=>{let t=Math.min(window.devicePixelRatio||1,2)*E.current.resolution;r.width!==Math.max(1,Math.round(c.width*t))?ce():S||q(),K()};let g=new ResizeObserver(ce);g.observe(e);let T=new IntersectionObserver(t=>{C=t.some(a=>a.isIntersecting),C&&(n=0,K())});return T.observe(e),window.addEventListener("pointermove",he,{passive:!0}),window.addEventListener("pointerdown",H,{passive:!0}),document.documentElement.addEventListener("pointerleave",le),ce(),()=>{L=!1,cancelAnimationFrame(S),J.current=null,g.disconnect(),T.disconnect(),window.removeEventListener("pointermove",he),window.removeEventListener("pointerdown",H),document.documentElement.removeEventListener("pointerleave",le),i.deleteTexture(M),i.deleteBuffer(re),i.deleteProgram(X),i.deleteShader(O),i.deleteShader(B)}},[]),(0,ye.useEffect)(()=>{J.current?.()}),React.createElement("div",{ref:ue,className:`iridescence-container${se?` ${se}`:""}`,style:pe},React.createElement("canvas",{ref:me,className:"iridescence-canvas","aria-hidden":"true"}))},at=Lt;var Ut={chrome:He,veil:je,silk:rt,iridescence:at};function Dt(){let[o,w]=React.useState({effect:"silk",props:{},intensity:1,edge:0,blur:0,paused:!1});window.setBackground=m=>{window.pulseFps=m.fps||30,w(m)};let h=Ut[o.effect];return React.createElement(React.Fragment,null,React.createElement("div",{className:"effect",style:{opacity:o.intensity,filter:`blur(${o.blur||0}px)`}},h&&React.createElement(h,{key:o.effect,...o.props,paused:o.paused,speed:o.paused?0:o.props.speed})),React.createElement("div",{className:"edge",style:{opacity:o.edge}}))}ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(Dt,null));window.forwardPointer=(o,w,h="pointermove")=>window.dispatchEvent(new PointerEvent(h,{clientX:o,clientY:w,pointerType:"mouse",bubbles:!0,buttons:h==="pointerdown"?1:0}));})();
