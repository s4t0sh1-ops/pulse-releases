package fun.pulse.music;

import android.content.*;
import android.media.AudioManager;
import android.os.*;
import android.webkit.*;
import androidx.core.content.ContextCompat;
import androidx.media3.common.*;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import com.google.common.util.concurrent.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

/** Both transports belong to the foreground media service, never to an Activity. */
@UnstableApi
final class HybridPlayer extends ForwardingSimpleBasePlayer {
  final Context context;
  final ExoPlayer nativePlayer;
  final Store store;
  final Catalog catalog;
  final Handler main = new Handler(Looper.getMainLooper());
  final ExecutorService network = Executors.newFixedThreadPool(2);
  Future<?> resolver;
  final PowerManager.WakeLock wake;
  WebView web;
  CloudHost cloudHost;
  List<Track> queue = new ArrayList<>();
  int index = 0, generation = 0;
  boolean resolving = false,
      cloud = false,
      wanted = false,
      ready = false,
      cloudPlaying = false,
      released = false,
      initialized = false;
  long cloudPosition = 0, cloudDuration = 0, lastSave = 0, lastWake = 0;
  String tag = "";
  PlaybackException failure;
  float volume = 1;
  final Player.Commands commands =
      new Player.Commands.Builder()
          .addAll(
              Player.COMMAND_PLAY_PAUSE,
              Player.COMMAND_PREPARE,
              Player.COMMAND_STOP,
              Player.COMMAND_SEEK_IN_CURRENT_MEDIA_ITEM,
              Player.COMMAND_SEEK_TO_DEFAULT_POSITION,
              Player.COMMAND_SEEK_TO_MEDIA_ITEM,
              Player.COMMAND_SEEK_TO_NEXT,
              Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM,
              Player.COMMAND_SEEK_TO_PREVIOUS,
              Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM,
              Player.COMMAND_GET_CURRENT_MEDIA_ITEM,
              Player.COMMAND_GET_TIMELINE,
              Player.COMMAND_GET_METADATA,
              Player.COMMAND_GET_AUDIO_ATTRIBUTES,
              Player.COMMAND_GET_VOLUME,
              Player.COMMAND_SET_VOLUME,
              Player.COMMAND_SET_REPEAT_MODE,
              Player.COMMAND_SET_SHUFFLE_MODE,
              Player.COMMAND_RELEASE)
          .build();
  final BroadcastReceiver noisy =
      new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
          if (cloud && wanted) pause();
        }
      };

  HybridPlayer(Context context, ExoPlayer player) {
    super(player);
    this.context = context;
    nativePlayer = player;
    store = new Store(context);
    catalog = new Catalog(context);
    // Chromium owns SoundCloud's audio focus. A second focus request here pauses our own WebView.
    PowerManager power = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
    wake = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Pulse:SoundCloudPlayback");
    wake.setReferenceCounted(false);
    ContextCompat.registerReceiver(
        context,
        noisy,
        new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
        ContextCompat.RECEIVER_NOT_EXPORTED);
    player.addListener(
        new Player.Listener() {
          @Override
          public void onPlayWhenReadyChanged(boolean play, int reason) {
            AudioTrace.record(context, "native play=" + play + " reason=" + reason);
          }

          @Override
          public void onPlayerError(PlaybackException e) {
            AudioTrace.record(context, "native error=" + e.errorCode);
          }

          @Override
          public void onPlaybackStateChanged(int state) {
            AudioTrace.record(context, "native state=" + state);
            if (!cloud && !resolving && state == Player.STATE_ENDED)
              main.post(() -> advanceQueue());
          }
        });
    main.post(pulse);
  }

  void loadStoredQueue(int selected, long position, boolean autoplay) throws Exception {
    List<Track> rows = store.tracks("queue");
    if (rows.isEmpty() || selected < 0 || selected >= rows.size())
      throw new IllegalArgumentException("Пустая очередь");
    initialized = true;
    queue = rows;
    load(selected, position, autoplay);
  }

  void syncQueue() {
    String id = queue.isEmpty() ? "" : queue.get(index).id;
    List<Track> rows = store.tracks("queue");
    for (int i = 0; i < rows.size(); i++)
      if (rows.get(i).id.equals(id)) {
        queue = rows;
        index = i;
        invalidateState();
        return;
      }
  }

  void load(int selected, long position, boolean autoplay) {
    int request = ++generation;
    if (resolver != null) resolver.cancel(true);
    nativePlayer.pause();
    nativePlayer.clearMediaItems();
    js("pause", 0);
    releaseCloudFocus();
    index = selected;
    cloud = false;
    wanted = autoplay;
    cloudPlaying = false;
    ready = false;
    resolving = true;
    failure = null;
    cloudPosition = position;
    cloudDuration = queue.get(index).duration;
    invalidateState();
    persist();
    Track song = queue.get(index);
    resolver =
        network.submit(
            () -> {
              try {
                Track playable = catalog.resolve(song, store.tracks("library"));
                main.post(
                    () -> {
                      if (released || request != generation) return;
                      resolving = false;
                      if (playable.source.equals("soundcloud")) {
                        cloud = true;
                        openCloud(playable, position);
                      } else {
                        cloud = false;
                        nativePlayer.setMediaItem(item(song, playable.url));
                        nativePlayer.prepare();
                        if (position > 0) nativePlayer.seekTo(position);
                        nativePlayer.setPlayWhenReady(wanted);
                      }
                      List<Track> history = store.tracks("history");
                      history.removeIf(t -> t.id.equals(song.id));
                      history.add(0, song);
                      store.tracks("history", history.subList(0, Math.min(100, history.size())));
                      invalidateState();
                    });
              } catch (Exception e) {
                main.post(
                    () -> {
                      if (request == generation) fail(e.getMessage());
                    });
              }
            });
    main.postDelayed(
        () -> {
          if (request == generation && !released && (resolving || cloud && !ready)) {
            fail("Источник не ответил. Выбери другую версию записи.");
          }
        },
        30000);
  }

  MediaItem item(Track t, String uri) {
    return new MediaItem.Builder()
        .setMediaId(t.id)
        .setUri(uri.isEmpty() ? "https://pulse.invalid/metadata" : uri)
        .setMediaMetadata(
            new MediaMetadata.Builder()
                .setTitle(t.title)
                .setArtist(t.artist)
                .setArtworkUri(
                    t.cover.startsWith("https://") ? android.net.Uri.parse(t.cover) : null)
                .build())
        .build();
  }

  @Override
  protected State getState() {
    State.Builder b =
        cloud || resolving || failure != null ? new State.Builder() : super.getState().buildUpon();
    List<MediaItemData> playlist = new ArrayList<>();
    for (int i = 0; i < queue.size(); i++) {
      Track t = queue.get(i);
      long duration = i == index && cloud ? cloudDuration : t.duration;
      playlist.add(
          new MediaItemData.Builder(t.id + ":" + i)
              .setMediaItem(item(t, t.url))
              .setIsSeekable(true)
              .setDurationUs(duration > 0 ? duration * 1000 : C.TIME_UNSET)
              .build());
    }
    b.setAvailableCommands(commands)
        .setPlaylist(playlist)
        .setCurrentMediaItemIndex(queue.isEmpty() ? C.INDEX_UNSET : index);
    if (queue.isEmpty())
      return b.setPlaybackState(Player.STATE_IDLE)
          .setIsLoading(false)
          .setPlayWhenReady(false, Player.PLAY_WHEN_READY_CHANGE_REASON_USER_REQUEST)
          .build();
    if (cloud || resolving || failure != null) {
      int state =
          failure != null
              ? Player.STATE_IDLE
              : resolving || !ready || wanted && !cloudPlaying
                  ? Player.STATE_BUFFERING
                  : Player.STATE_READY;
      b.setPlaybackState(state)
          .setIsLoading(state == Player.STATE_BUFFERING)
          .setPlayWhenReady(wanted, Player.PLAY_WHEN_READY_CHANGE_REASON_USER_REQUEST)
          .setPlayerError(failure)
          .setContentPositionMs(cloudPosition)
          .setContentBufferedPositionMs(PositionSupplier.getConstant(cloudPosition))
          .setTotalBufferedDurationMs(PositionSupplier.ZERO)
          .setAudioAttributes(
              new AudioAttributes.Builder()
                  .setUsage(C.USAGE_MEDIA)
                  .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                  .build())
          .setVolume(volume);
    }
    return b.build();
  }

  void advanceQueue() {
    if (queue.isEmpty() || released) return;
    int target = index + 1;
    if (target >= queue.size()) {
      if (store.get("repeat", "false").equals("true")) target = 0;
      else {
        wanted = false;
        cloudPlaying = false;
        releaseCloudFocus();
        invalidateState();
        persist();
        return;
      }
    }
    load(target, 0, true);
  }

  void fail(String message) {
    AudioTrace.record(context, "source failure cloud=" + cloud);
    generation++;
    resolving = false;
    wanted = false;
    cloudPlaying = false;
    js("pause", 0);
    nativePlayer.pause();
    releaseCloudFocus();
    failure =
        new PlaybackException(
            message == null ? "Запись недоступна" : message,
            null,
            PlaybackException.ERROR_CODE_IO_UNSPECIFIED);
    invalidateState();
    persist();
  }

  @Override
  protected ListenableFuture<?> handleSetPlayWhenReady(boolean play) {
    wanted = play;
    if (failure != null && play && !queue.isEmpty()) {
      load(index, cloudPosition, true);
      return Futures.immediateVoidFuture();
    }
    AudioTrace.record(context, "command play=" + play + " cloud=" + cloud);
    if (cloud) {
      if (play) {
        holdWake();
        js("play", 0);
      } else {
        js("pause", 0);
        cloudPlaying = false;
        releaseCloudFocus();
      }
    } else if (!resolving) nativePlayer.setPlayWhenReady(play);
    invalidateState();
    persist();
    return Futures.immediateVoidFuture();
  }

  @Override
  protected ListenableFuture<?> handlePrepare() {
    if (!cloud && !resolving) nativePlayer.prepare();
    return Futures.immediateVoidFuture();
  }

  @Override
  protected ListenableFuture<?> handleSeek(int selected, long pos, int command) {
    int target = selected == C.INDEX_UNSET ? index : selected;
    if (command == Player.COMMAND_SEEK_TO_NEXT || command == Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM)
      target = Math.min(queue.size() - 1, index + 1);
    if (command == Player.COMMAND_SEEK_TO_PREVIOUS
        || command == Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM) target = Math.max(0, index - 1);
    pos = pos == C.TIME_UNSET ? 0 : Math.max(0, pos);
    if (target != index && !queue.isEmpty()) load(target, pos, wanted);
    else if (cloud) {
      cloudPosition = pos;
      js("seek", pos);
      invalidateState();
    } else if (!resolving) nativePlayer.seekTo(pos);
    persist();
    return Futures.immediateVoidFuture();
  }

  @Override
  protected ListenableFuture<?> handleStop() {
    initialized = true;
    generation++;
    wanted = false;
    resolving = false;
    cloudPlaying = false;
    js("pause", 0);
    nativePlayer.stop();
    releaseCloudFocus();
    queue.clear();
    cloud = false;
    failure = null;
    invalidateState();
    persist();
    return Futures.immediateVoidFuture();
  }

  @Override
  protected ListenableFuture<?> handleRelease() {
    released = true;
    generation++;
    main.removeCallbacksAndMessages(null);
    network.shutdownNow();
    js("pause", 0);
    if (web != null) {
      if (cloudHost != null) {
        cloudHost.close();
        cloudHost = null;
      } else web.destroy();
      web = null;
    }
    releaseCloudFocus();
    context.unregisterReceiver(noisy);
    nativePlayer.release();
    return Futures.immediateVoidFuture();
  }

  @Override
  protected ListenableFuture<?> handleSetVolume(float value) {
    volume = value;
    if (cloud) js("volume", value * 100);
    else nativePlayer.setVolume(value);
    invalidateState();
    return Futures.immediateVoidFuture();
  }

  boolean ensureWeb() {
    if (web != null) return true;
    try {
      cloudHost = new CloudHost(context);
      web = cloudHost.web;
    } catch (RuntimeException e) {
      AudioTrace.record(context, "cloud host failed " + e.getClass().getSimpleName());
      fail("Не удалось запустить системный плеер SoundCloud");
      return false;
    }
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setMediaPlaybackRequiresUserGesture(false);
    web.getSettings().setAllowFileAccess(false);
    web.getSettings().setAllowContentAccess(false);
    web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
    web.setWebViewClient(
        new WebViewClient() {
          @Override
          public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            return req.isForMainFrame();
          }

          @Override
          public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail detail) {
            web = null;
            if (cloudHost != null) {
              cloudHost.close();
              cloudHost = null;
            } else v.destroy();
            fail("Плеер SoundCloud завершился. Нажми играть, чтобы повторить.");
            return true;
          }
        });
    web.setWebChromeClient(
        new WebChromeClient() {
          @Override
          public boolean onConsoleMessage(ConsoleMessage m) {
            if (m.message().startsWith("PULSE_SC:"))
              try {
                JSONObject e = new JSONObject(m.message().substring(9));
                main.post(() -> event(e));
                return true;
              } catch (Exception ignored) {
              }
            return false;
          }
        });
    return true;
  }

  void openCloud(Track playable, long position) {
    if (!ensureWeb()) return;
    tag = UUID.randomUUID().toString();
    cloudPosition = position;
    cloudDuration = playable.duration;
    ready = false;
    cloudPlaying = false;
    String widget =
        "https://w.soundcloud.com/player/?url="
            + Catalog.enc(playable.url)
            + "&auto_play=false&visual=false";
    String html =
        "<!doctype html><meta name='viewport' content='width=device-width'><iframe id='s'"
            + " allow='autoplay; encrypted-media' src='"
            + widget
            + "'></iframe><script"
            + " src='https://w.soundcloud.com/player/api.js'></script><script>const tag="
            + JSONObject.quote(tag)
            + ";let w=SC.Widget(document.getElementById('s')),ready=false,pos="
            + position
            + ";function"
            + " report(type,data={}){console.log('PULSE_SC:'+JSON.stringify({tag,type,...data}))}function"
            + " command(c,v){if(c==='seek')pos=v;if(!ready)return;if(c==='play')w.play();if(c==='pause')w.pause();if(c==='seek')w.seekTo(v);if(c==='volume')w.setVolume(v)}w.bind(SC.Widget.Events.READY,()=>{ready=true;w.getDuration(duration=>{report('ready',{duration});if(pos)w.seekTo(pos)})});w.bind(SC.Widget.Events.PLAY,()=>report('play'));w.bind(SC.Widget.Events.PAUSE,()=>report('pause'));w.bind(SC.Widget.Events.PLAY_PROGRESS,e=>report('progress',{position:e.currentPosition}));w.bind(SC.Widget.Events.FINISH,()=>report('finish'));w.bind(SC.Widget.Events.ERROR,()=>report('error'));</script>";
    web.loadDataWithBaseURL("https://pulse-player.local/", html, "text/html", "UTF-8", null);
    if (wanted) holdWake();
    invalidateState();
  }

  void event(JSONObject e) {
    if (released || !cloud || !tag.equals(e.optString("tag"))) return;
    if (!e.optString("type").equals("progress"))
      AudioTrace.record(
          context,
          "cloud event=" + e.optString("type") + " wanted=" + wanted + " pos=" + cloudPosition);
    switch (e.optString("type")) {
      case "ready":
        ready = true;
        cloudDuration = e.optLong("duration");
        js("volume", volume * 100);
        if (wanted) {
          holdWake();
          js("play", 0);
        }
        break;
      case "play":
        if (!wanted) {
          js("pause", 0);
          return;
        }
        cloudPlaying = true;
        holdWake();
        break;
      case "pause":
        cloudPlaying = false;
        wanted = false;
        releaseCloudFocus();
        break;
      case "progress":
        cloudPosition = e.optLong("position");
        break;
      case "finish":
        advanceQueue();
        return;
      case "error":
        fail("SoundCloud не смог открыть эту запись");
        return;
    }
    invalidateState();
  }

  void js(String name, double value) {
    if (web != null)
      web.evaluateJavascript(
          "window.command&&command(" + JSONObject.quote(name) + "," + value + ")", null);
  }

  void holdWake() {
    if (SystemClock.elapsedRealtime() - lastWake > 45000 || !wake.isHeld()) {
      wake.acquire(60000);
      lastWake = SystemClock.elapsedRealtime();
    }
  }

  void releaseCloudFocus() {
    if (wake.isHeld()) wake.release();
    // WebView and ExoPlayer each relinquish their own focus on pause; do not compete with them.
  }

  void persist() {
    if (released || !initialized) return;
    try {
      store.tracks("queue", queue);
      long pos = cloud || resolving ? cloudPosition : nativePlayer.getCurrentPosition();
      store.put(
          "session",
          new JSONObject()
              .put("index", queue.isEmpty() ? -1 : index)
              .put("position", pos)
              .toString());
    } catch (Exception ignored) {
    }
  }

  final Runnable pulse =
      new Runnable() {
        public void run() {
          if (released) return;
          if (cloud && wanted) holdWake();
          if (SystemClock.elapsedRealtime() - lastSave > 5000) {
            lastSave = SystemClock.elapsedRealtime();
            persist();
          }
          main.postDelayed(this, 1000);
        }
      };
}
