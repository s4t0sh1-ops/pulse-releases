package fun.pulse.music;

import static org.junit.Assert.*;

import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;

/** Native Android layout rendering in Robolectric. WebGL and online audio need device QA. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35, qualifiers = "w384dp-h800dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class MobileLayoutTest {
  ActivityController<MainActivity> controller;
  MainActivity a;

  @Before
  public void setup() {
    RuntimeEnvironment.getApplication().getSharedPreferences("pulse-v1", 0).edit().clear().commit();
    // Layout-only tests: the default fake service binder has a null ComponentName.
    // Media transport is covered separately rather than treating this as a device service.
    org.robolectric.Shadows.shadowOf(RuntimeEnvironment.getApplication())
        .declareComponentUnbindable(
            new android.content.ComponentName(
                RuntimeEnvironment.getApplication(), PlaybackService.class));
    controller = Robolectric.buildActivity(MainActivity.class).create();
    a = controller.get();
  }

  @After
  public void stop() {
    controller.destroy();
  }

  void render(String name, int width, int height) throws Exception {
    a.root.measure(
        View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
        View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
    a.root.layout(0, 0, width, height);
    Bitmap image = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
    a.root.draw(new Canvas(image));
    File dir = new File("build/qa");
    dir.mkdirs();
    try (FileOutputStream out = new FileOutputStream(new File(dir, name + ".png"))) {
      image.compress(Bitmap.CompressFormat.PNG, 100, out);
    }
    image.recycle();
    assertEquals(width, a.root.getMeasuredWidth());
    assertEquals(height, a.root.getMeasuredHeight());
  }

  @Test
  public void smallPhoneHasScrollableAuthAndReadableTitle() throws Exception {
    render("mobile-login-384", 384, 800);
    assertEquals("auth", a.page);
    assertEquals(View.GONE, a.nav.getVisibility());
    assertEquals(View.GONE, a.mini.getVisibility());
    a.auth(true);
    render("mobile-register-320", 320, 640);
    assertTrue(a.content.getChildAt(0) instanceof ScrollView);
    TextView headline = findText(a.content, "Музыка\nначинается с тебя.");
    assertNotNull(headline);
    assertNotNull(headline.getLayout());
    assertTrue(headline.getHeight() >= headline.getLayout().getHeight());
  }

  @Test
  public void homeProfileAndPlayerFitPhone() throws Exception {
    org.json.JSONObject p = a.store.register("Слушатель", "qa@example.invalid", "test-pass-3");
    a.store.activate(p);
    a.store.put("tour:" + p.getString("id"), "true");
    Track t = new Track();
    t.id = "qa";
    t.title = "Твоя любимая песня";
    t.artist = "Исполнитель";
    t.source = "local";
    t.duration = 180000;
    a.homeRows = new ArrayList<>(Arrays.asList(t));
    a.home();
    render("mobile-home-384", 384, 800);
    assertTrue(a.mini.getBottom() <= a.nav.getTop());
    assertTrue(a.nav.getBottom() <= 800);
    a.profile();
    render("mobile-profile-384", 384, 800);
    assertNotNull(findText(a.content, "Выйти из профиля"));
    assertNotNull(findText(a.content, "Подключить Яндекс по коду"));
    assertNotNull(findText(a.content, "Импортировать из Яндекс Музыки"));
    assertNull(findText(a.content, "Таймер сна"));
    assertNull(findText(a.content, "Настроить волну"));
    assertNull(findText(a.content, "Сохранить диагностику звука"));
    assertNotNull(a.miniArt);
    a.current = t;
    a.nowPlaying();
    render("mobile-player-384", 384, 800);
    assertEquals(View.GONE, a.mini.getVisibility());
    assertEquals(View.GONE, a.nav.getVisibility());
    assertNotNull(a.nowSeek);
  }

  @Test
  public void differentPhoneWidthsAndLargeTextRemainUsable() throws Exception {
    org.json.JSONObject p = a.store.register("Слушатель", "sizes@example.invalid", "test-pass-4");
    a.store.activate(p);
    a.store.put("tour:" + p.getString("id"), "true");
    Track t = new Track();
    t.id = "qa";
    t.title = "Название песни";
    t.artist = "Исполнитель";
    a.homeRows = new ArrayList<>(Arrays.asList(t));
    for (int width : new int[] {320, 360, 384, 412, 480, 600}) {
      RuntimeEnvironment.setQualifiers("w" + width + "dp-h800dp-mdpi");
      a.home();
      render("mobile-home-" + width, width, 800);
      assertTrue(a.nav.getBottom() <= 800);
      assertTrue(a.content.getBottom() <= a.mini.getTop());
      for (int i = 0; i < a.nav.getChildCount(); i++) {
        LinearLayout item = (LinearLayout) a.nav.getChildAt(i);
        View glyph = item.getChildAt(0), label = item.getChildAt(1);
        assertEquals(
            (glyph.getLeft() + glyph.getRight()) / 2, (label.getLeft() + label.getRight()) / 2, 1);
      }
    }
    RuntimeEnvironment.setQualifiers("w360dp-h780dp-mdpi");
    RuntimeEnvironment.setFontScale(1.5f);
    a.auth(true);
    render("mobile-register-large-font", 360, 780);
    TextView headline = findText(a.content, "Музыка\nначинается с тебя.");
    assertNotNull(headline);
    assertTrue(headline.getHeight() >= headline.getLayout().getHeight());
    RuntimeEnvironment.setFontScale(1);
  }

  @Test
  public void allBackgroundsIgnoreOldTouchSettingsButKeepAnimation() throws Exception {
    for (String effect : new String[] {"vortex", "chrome", "veil", "silk", "iridescence"}) {
      a.store.put("effect", effect);
      org.json.JSONObject saved =
          new org.json.JSONObject()
              .put("mouseReact", true)
              .put("mouseInteraction", true)
              .put("interactive", true)
              .put("clickRipple", true)
              .put("clickSwirl", true)
              .put("mouseStrength", 9)
              .put("speed", 0.7);
      a.store.put("effect:" + effect, saved.toString());
      org.json.JSONObject config = a.backgroundEditor.config(true);
      org.json.JSONObject props = config.getJSONObject("props");
      assertFalse(config.getBoolean("paused"));
      for (String key :
          new String[] {
            "mouseReact", "mouseInteraction", "interactive", "clickRipple", "clickSwirl"
          }) assertFalse(effect + ":" + key, props.getBoolean(key));
      assertEquals(0, props.getDouble("mouseStrength"), 0);
      assertEquals(0.7, props.getDouble("speed"), 0);
    }
  }

  @Test
  public void walkthroughUsesRealTargetsAndCannotBeSkippedByBack() throws Exception {
    org.json.JSONObject p = a.store.register("Обучение", "tour@example.invalid", "test-pass-3");
    a.store.activate(p);
    Track demo = new Track();
    demo.id = "demo";
    demo.title = "Песня";
    demo.artist = "Артист";
    a.homeRows = new ArrayList<>(Arrays.asList(demo));
    render("mobile-before-tour", 384, 800);
    a.tour(0);
    for (int step = 0; step < CoachMarks.TITLES.length; step++) {
      if (step > 0) a.coach.step(step);
      render("mobile-tour-layout", 384, 800);
      org.robolectric.shadows.ShadowLooper.idleMainLooper();
      a.coach
          .place(); // Layout-only Activity: explicitly execute the post-layout spotlight placement.
      assertFalse(a.coach.revealed);
      android.view.MotionEvent press =
          android.view.MotionEvent.obtain(
              0,
              0,
              android.view.MotionEvent.ACTION_UP,
              a.coach.focus.centerX(),
              a.coach.focus.centerY(),
              0);
      a.coach.onTouchEvent(press);
      press.recycle();
      assertTrue(a.coach.revealed);
      render("mobile-tour-" + step, 384, 800);
      assertNotNull(a.coach.target);
      assertTrue(a.coach.focus.width() > 0);
      a.onBackPressed();
      assertTrue(a.touring);
      assertFalse(a.store.get("tour:" + p.getString("id"), "false").equals("true"));
    }
    a.coach.step(CoachMarks.TITLES.length);
    assertFalse(a.touring);
    assertEquals("true", a.store.get("tour:" + p.getString("id"), "false"));
  }

  static TextView findText(View v, String value) {
    if (v instanceof TextView && ((TextView) v).getText().toString().equals(value))
      return (TextView) v;
    if (v instanceof ViewGroup)
      for (int i = 0; i < ((ViewGroup) v).getChildCount(); i++) {
        TextView found = findText(((ViewGroup) v).getChildAt(i), value);
        if (found != null) return found;
      }
    return null;
  }
}
