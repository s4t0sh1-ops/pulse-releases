package fun.pulse.music;

import android.app.*;
import android.content.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.*;

final class YandexUi {
  final MainActivity a;
  final YandexMusic music;
  final AtomicInteger generation = new AtomicInteger();
  AlertDialog authDialog;
  final YandexConnector connector;
  final YandexConnector.Listener listener = this::changed;
  TextView connectionStatus;
  boolean attached = false, closed = false, wasConnected = false, initiated = false;

  YandexUi(MainActivity activity) {
    a = activity;
    music = new YandexMusic(a);
    connector = ((PulseApp) a.getApplication()).yandex();
    wasConnected = music.session.connected();
  }

  void cancel() {
    generation.incrementAndGet();
    connector.cancel();
    if (authDialog != null) {
      authDialog.dismiss();
      authDialog = null;
    }
  }

  void disconnect() {
    cancel();
    music.session.clear();
    a.stopAudio();
    a.toast("Яндекс отключён");
    a.profile();
  }

  void section(LinearLayout body) {
    a.space(body, 18);
    body.addView(a.text("Яндекс Музыка", 20, a.TEXT, true));
    a.space(body, 10);
    if (music.session.connected()) {
      body.addView(
          a.text(
              "Подключён: "
                  + music
                      .session
                      .account()
                      .optString(
                          "displayName",
                          music.session.account().optString("login", "твой аккаунт")),
              13,
              a.MUTED,
              false));
      a.space(body, 12);
      body.addView(a.button("Импортировать из Яндекс Музыки", this::importLikes));
      a.space(body, 10);
      body.addView(a.button("Отключить Яндекс", this::disconnect));
    } else {
      body.addView(a.button("Подключить Яндекс по коду", this::connect));
      a.space(body, 10);
      body.addView(
          a.button(
              "Импортировать из Яндекс Музыки",
              () -> {
                a.toast("Сначала подключи свой аккаунт по коду");
                connect();
              }));
    }
    a.space(body, 12);
    body.addView(
        a.text(
            "Личный музыкальный аккаунт. Импорт добавляет лайки в любимое Pulse; доступ к полным"
                + " записям определяется твоим аккаунтом и подпиской.",
            12,
            a.MUTED,
            false));
  }

  void resume() {
    if (closed) return;
    if (!attached) {
      connector.add(listener);
      attached = true;
    }
    if (a.store.loggedIn()) connector.resume();
  }

  void close() {
    closed = true;
    generation.incrementAndGet();
    connector.remove(listener);
    attached = false;
    if (authDialog != null) {
      authDialog.dismiss();
      authDialog = null;
    }
  }

  void changed(YandexConnector.State state) {
    if (closed || !a.store.loggedIn()) return;
    boolean wasBusy = authDialog != null;
    if (state.busy && !state.code.isEmpty()) {
      if (authDialog == null) showCode(state);
      if (connectionStatus != null) connectionStatus.setText(state.message);
    } else if (!state.busy) {
      if (authDialog != null) {
        authDialog.dismiss();
        authDialog = null;
        connectionStatus = null;
      }
      if (state.connected && (wasBusy || !wasConnected)) {
        a.toast("Яндекс Музыка подключена");
        a.profile();
      } else if ((wasBusy || initiated) && !state.message.isEmpty()) a.toast(state.message);
      if (!state.message.isEmpty()) initiated = false;
    }
    wasConnected = state.connected;
  }

  void showCode(YandexConnector.State state) {
    LinearLayout body = a.column();
    body.setPadding(a.dp(20), a.dp(12), a.dp(20), a.dp(12));
    body.addView(a.text("Введи код на странице Яндекса", 15, a.TEXT, false));
    a.space(body, 16);
    TextView code = a.text(state.code, 30, a.TEXT, true);
    code.setTextIsSelectable(true);
    body.addView(code);
    a.space(body, 16);
    body.addView(
        a.button(
            "Скопировать код и открыть Яндекс",
            () -> {
              ((android.content.ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE))
                  .setPrimaryClip(ClipData.newPlainText("Код входа Яндекс", state.code));
              a.open(state.target);
            }));
    a.space(body, 12);
    connectionStatus = a.text(state.message, 13, a.MUTED, false);
    body.addView(connectionStatus);
    a.space(body, 12);
    body.addView(a.button("Я подтвердил код — проверить", connector::resume));
    authDialog =
        new AlertDialog.Builder(a)
            .setTitle("Подключить Яндекс")
            .setView(body)
            .setNegativeButton("Отмена", (d, w) -> cancel())
            .setOnCancelListener(d -> cancel())
            .show();
  }

  void connect() {
    resume();
    initiated = true;
    a.toast("Получаем код Яндекса…");
    connector.start();
  }

  void importLikes() {
    int request = generation.incrementAndGet();
    TextView status = a.text("Загружаем любимые треки…", 15, a.TEXT, false);
    status.setPadding(a.dp(20), a.dp(16), a.dp(20), a.dp(16));
    AlertDialog dialog =
        new AlertDialog.Builder(a)
            .setTitle("Импорт Яндекс Музыки")
            .setView(status)
            .setNegativeButton("Отмена", (d, w) -> cancel())
            .setOnCancelListener(d -> cancel())
            .create();
    dialog.show();
    a.workers.execute(
        () -> {
          try {
            List<Track> rows =
                music.likes(
                    () -> request != generation.get(),
                    (loaded, total) ->
                        a.ui.post(
                            () -> {
                              if (request == generation.get())
                                status.setText("Получено " + loaded + " из " + total);
                            }));
            a.ui.post(
                () -> {
                  if (request != generation.get() || !a.store.loggedIn()) return;
                  int count = 0;
                  Set<String> seen = new HashSet<>();
                  for (Track t : a.favorites) seen.add(t.id);
                  for (Track t : rows)
                    if (seen.add(t.id)) {
                      a.favorites.add(0, t);
                      count++;
                    }
                  a.store.tracks("favorites", a.favorites);
                  dialog.dismiss();
                  a.toast("Добавлено любимых треков: " + count);
                  a.showCollection("Любимые треки", a.favorites);
                });
          } catch (Exception e) {
            a.ui.post(
                () -> {
                  if (request == generation.get()) {
                    dialog.dismiss();
                    a.toast("Импорт не завершён. Проверь подключение Яндекса и попробуй снова.");
                  }
                });
          }
        });
  }
}
