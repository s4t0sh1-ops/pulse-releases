package fun.pulse.music;

import java.util.*;
import org.json.*;

/** Local playlists have stable IDs and snapshots of track metadata, never audio copies. */
final class Playlists {
  final Store store;

  Playlists(Store store) {
    this.store = store;
  }

  JSONObject all() {
    return store.object("playlists-v1");
  }

  void save(JSONObject all) {
    store.put("playlists-v1", all.toString());
  }

  JSONObject get(String id) {
    return all().optJSONObject(id);
  }

  List<String> ids() {
    List<String> ids = new ArrayList<>();
    JSONObject all = all();
    for (Iterator<String> it = all.keys(); it.hasNext(); ) {
      String id = it.next();
      if (all.optJSONObject(id) != null) ids.add(id);
    }
    ids.sort(
        Comparator.comparing(
            id -> all.optJSONObject(id).optString("name"), String.CASE_INSENSITIVE_ORDER));
    return ids;
  }

  String name(String id) {
    JSONObject p = get(id);
    return p == null ? "Плейлист" : p.optString("name");
  }

  List<Track> tracks(String id) {
    JSONObject p = get(id);
    return Track.list(p == null ? null : p.optJSONArray("tracks"));
  }

  String create(String name) throws Exception {
    String id = UUID.randomUUID().toString();
    JSONObject all = all();
    all.put(id, new JSONObject().put("name", validName(name)).put("tracks", new JSONArray()));
    save(all);
    return id;
  }

  String validName(String name) {
    name = name.trim();
    if (name.isEmpty() || name.length() > 80)
      throw new IllegalArgumentException("Название: от 1 до 80 символов");
    return name;
  }

  void rename(String id, String name) throws Exception {
    JSONObject all = all(), p = all.optJSONObject(id);
    if (p == null) return;
    p.put("name", validName(name));
    save(all);
  }

  void delete(String id) {
    JSONObject all = all();
    all.remove(id);
    save(all);
  }

  boolean add(String id, Track track) throws Exception {
    JSONObject all = all(), p = all.optJSONObject(id);
    if (p == null) throw new IllegalArgumentException("Плейлист уже удалён");
    List<Track> rows = Track.list(p.optJSONArray("tracks"));
    if (rows.stream().anyMatch(t -> t.id.equals(track.id))) return false;
    rows.add(0, Track.from(track.json()));
    p.put("tracks", Track.array(rows));
    save(all);
    return true;
  }

  void remove(String id, Track track) throws Exception {
    JSONObject all = all(), p = all.optJSONObject(id);
    if (p == null) return;
    List<Track> rows = Track.list(p.optJSONArray("tracks"));
    rows.removeIf(t -> t.id.equals(track.id));
    p.put("tracks", Track.array(rows));
    save(all);
  }
}
