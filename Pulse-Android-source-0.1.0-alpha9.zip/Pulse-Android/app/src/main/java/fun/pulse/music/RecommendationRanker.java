package fun.pulse.music;

import java.util.*;

final class RecommendationRanker {
  static boolean sameArtist(String a, String b) {
    String x = Matching.normalize(a), y = Matching.normalize(b);
    if (x.isEmpty() || y.isEmpty()) return false;
    if (x.equals(y)) return true;
    for (String part : b.split("[,;&]|(?i) feat\\. | & "))
      if (Matching.normalize(part).equals(x)) return true;
    return false;
  }

  static List<Track> anchors(List<Track> favorites, List<Track> history) {
    Map<String, Integer> weights = new HashMap<>();
    List<Track> all = new ArrayList<>(favorites);
    all.addAll(history.subList(0, Math.min(80, history.size())));
    for (Track t : favorites) weights.merge(Matching.normalize(t.artist), 5, Integer::sum);
    for (int i=0; i<Math.min(80, history.size()); i++)
      weights.merge(Matching.normalize(history.get(i).artist), i<20 ? 3 : 1, Integer::sum);
    all.removeIf(t -> t.artist.isEmpty());
    Collections.shuffle(all);
    all.sort(Comparator.comparingInt((Track t) -> weights.getOrDefault(Matching.normalize(t.artist),0)).reversed());
    return all;
  }

  static List<Track> rank(List<Track> candidates, List<Track> favorites, List<Track> history) {
    Map<String, Integer> artists = new HashMap<>(), genres = new HashMap<>();
    Set<String> heard = new HashSet<>();
    for (Track t : history) {
      artists.merge(Matching.normalize(t.artist), 1, Integer::sum);
      if (!t.genre.isEmpty()) genres.merge(Matching.normalize(t.genre), 1, Integer::sum);
      heard.add(t.id);
    }
    for (Track t : favorites) {
      artists.merge(Matching.normalize(t.artist), 5, Integer::sum);
      if (!t.genre.isEmpty()) genres.merge(Matching.normalize(t.genre), 4, Integer::sum);
    }
    List<Track> rows = new ArrayList<>(candidates);
    Collections.shuffle(rows);
    rows.sort(
        Comparator.comparingInt(
                (Track t) ->
                    artists.getOrDefault(Matching.normalize(t.artist), 0) * 3
                        + genres.getOrDefault(Matching.normalize(t.genre), 0)
                        - (heard.contains(t.id) ? 7 : 0))
            .reversed());
    return rows;
  }
}
