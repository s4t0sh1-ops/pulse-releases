package fun.pulse.music;

import static org.junit.Assert.*;
import java.util.*;
import org.junit.Test;

public class WaveRelevanceTest {
  Track song(String id, String artist) {
    Track t = new Track(); t.id=id; t.artist=artist; t.title=id; return t;
  }
  @Test public void personalWaveUsesListeningAnchorsInsteadOfGlobalTrending() throws Exception {
    List<String> queried = new ArrayList<>();
    Catalog catalog = new Catalog() {
      @Override public List<Track> related(Track seed) {
        queried.add(seed.artist); return List.of(song(seed.id+"-related",seed.artist));
      }
      @Override public List<Track> trending() { fail("Must not replace personalised wave with charts"); return List.of(); }
    };
    Track old=song("1","Old"), liked=song("2","Favourite");
    List<Track> result=catalog.forYou(List.of(liked),List.of(old,liked,liked));
    assertEquals("Favourite", queried.get(0));
    assertTrue(result.stream().allMatch(t -> queried.contains(t.artist)));
  }
  @Test public void unavailableRecommendationsDoNotSilentlyBecomeCharts() throws Exception {
    Catalog catalog = new Catalog() {
      @Override public List<Track> related(Track seed) { return List.of(); }
      @Override public List<Track> trending() { fail("No unrelated fallback"); return List.of(); }
    };
    try { catalog.forYou(List.of(song("1","A")),List.of()); fail(); }
    catch(java.io.IOException expected) {}
  }
  @Test public void artistMatchingRejectsNamesThatOnlyContainAnotherArtist() {
    assertTrue(RecommendationRanker.sameArtist("CODE80", "CODE80, ALLME"));
    assertFalse(RecommendationRanker.sameArtist("CODE80", "CODE800"));
    assertFalse(RecommendationRanker.sameArtist("", "Anyone"));
  }
}
