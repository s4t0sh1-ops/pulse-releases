package fun.pulse.music;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import org.json.*;

/** Public catalogue adapters. No personal token or gated preview is distributed. */
public final class Catalog {
  public static String enc(String s) {
    try {
      return URLEncoder.encode(s, "UTF-8");
    } catch (UnsupportedEncodingException impossible) {
      throw new AssertionError(impossible);
    }
  }

  public static String request(String url, JSONObject body) throws Exception {
    URL target = new URL(url);
    if (!target.getProtocol().equals("https")) throw new IOException("Нужен защищённый источник");
    HttpURLConnection c = (HttpURLConnection) target.openConnection();
    c.setConnectTimeout(6000);
    c.setReadTimeout(10000);
    c.setRequestProperty("User-Agent", "Mozilla/5.0 PulseAndroid/0.1");
    try {
      if (body != null) {
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        try (OutputStream out = c.getOutputStream()) {
          out.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
      }
      if (c.getResponseCode() / 100 != 2)
        throw new IOException("Источник ответил " + c.getResponseCode());
      try (InputStream in = c.getInputStream();
          ByteArrayOutputStream out = new ByteArrayOutputStream()) {
        byte[] chunk = new byte[16384];
        int n;
        while ((n = in.read(chunk)) != -1) {
          out.write(chunk, 0, n);
          if (out.size() > 12 * 1024 * 1024) throw new IOException("Слишком большой ответ");
        }
        return out.toString(StandardCharsets.UTF_8.name());
      }
    } finally {
      c.disconnect();
    }
  }

  static JSONObject object(String url) throws Exception {
    return new JSONObject(request(url, null));
  }

  static JSONObject records(JSONObject entities, String name) {
    JSONObject raw = entities.optJSONObject(name), out = new JSONObject();
    if (raw != null)
      for (Iterator<String> i = raw.keys(); i.hasNext(); ) {
        String key = i.next();
        JSONObject j = raw.optJSONObject(key);
        if (j != null)
          try {
            out.put(key, j.optJSONObject("data") != null ? j.optJSONObject("data") : j);
          } catch (Exception ignored) {
          }
      }
    return out;
  }

  static JSONObject scPage(String path) throws Exception {
    if (path.startsWith("https://")) {
      URI u = new URI(path);
      if (!Arrays.asList("soundcloud.com", "m.soundcloud.com", "www.soundcloud.com")
          .contains(u.getHost())) throw new IOException("Нужна ссылка SoundCloud");
      path = u.getRawPath();
    }
    if (!path.startsWith("/") || path.startsWith("//")) throw new IOException("Неверная ссылка");
    String html = request("https://m.soundcloud.com" + path, null);
    Matcher m =
        Pattern.compile("<script id=\"__NEXT_DATA__\"[^>]*>(.*?)</script>", Pattern.DOTALL)
            .matcher(html);
    if (!m.find()) throw new IOException("SoundCloud сейчас недоступен");
    return new JSONObject(m.group(1)).getJSONObject("props").getJSONObject("pageProps");
  }

  static List<Track> scRows(JSONObject page, JSONArray selected) {
    JSONObject initial = page.optJSONObject("initialStoreState"),
        entities = initial == null ? new JSONObject() : initial.optJSONObject("entities");
    if (entities == null) return new ArrayList<>();
    JSONObject users = records(entities, "users"), tracks = records(entities, "tracks");
    List<Track> out = new ArrayList<>();
    List<String> keys = new ArrayList<>();
    if (selected != null)
      for (int i = 0; i < selected.length(); i++) keys.add(selected.optString(i));
    else for (Iterator<String> i = tracks.keys(); i.hasNext(); ) keys.add(i.next());
    for (String key : keys) {
      JSONObject j = tracks.optJSONObject(key);
      if (j == null
          || !j.optBoolean("streamable")
          || !Arrays.asList("ALLOW", "MONETIZE").contains(j.optString("policy"))
          || !j.optBoolean("public", true)
          || j.optLong("full_duration") > j.optLong("duration") + 5000) continue;
      JSONObject media = j.optJSONObject("media");
      JSONArray trans = media == null ? null : media.optJSONArray("transcodings");
      boolean full = trans == null || trans.length() == 0;
      for (int n = 0; trans != null && n < trans.length(); n++)
        if (!trans.optJSONObject(n).optBoolean("snipped")) full = true;
      if (!full) continue;
      JSONObject user = j.optJSONObject("user");
      if (user == null) user = users.optJSONObject(j.optString("user"));
      if (user == null) user = new JSONObject();
      Track t = new Track();
      t.id = "sc:" + j.optString("id");
      t.title = j.optString("title");
      t.artist = user.optString("username", "SoundCloud");
      t.source = "soundcloud";
      t.url = j.optString("permalink_url");
      t.cover = j.optString("artwork_url", user.optString("avatar_url"));
      if (t.cover.equals("null")) t.cover = user.optString("avatar_url");
      t.duration = j.optLong("full_duration", j.optLong("duration"));
      t.artistId = user.optString("id");
      t.artistUrl = user.optString("permalink_url");
      t.genre = j.optString("genre");
      if (!t.url.isEmpty()) out.add(t);
    }
    return out;
  }

  static List<Track> audiusRows(JSONArray a) {
    List<Track> rows = new ArrayList<>();
    if (a == null) return rows;
    for (int i = 0; i < a.length(); i++) {
      JSONObject j = a.optJSONObject(i);
      if (j == null || !j.optBoolean("is_streamable") || j.optBoolean("is_delete")) continue;
      JSONObject access = j.optJSONObject("access"),
          conditions = j.optJSONObject("stream_conditions");
      if (access != null && !access.optBoolean("stream", true)
          || conditions != null && conditions.length() > 0) continue;
      JSONObject user = j.optJSONObject("user"), art = j.optJSONObject("artwork");
      if (user == null) continue;
      Track t = new Track();
      t.id = "audius:" + j.optString("id");
      t.source = "audius";
      t.title = j.optString("title");
      t.artist = user.optString("name", user.optString("handle"));
      t.artistId = user.optString("id");
      t.duration = j.optLong("duration") * 1000;
      t.genre = j.optString("genre");
      t.cover = art == null ? "" : art.optString("480x480", art.optString("150x150"));
      t.url = "https://api.audius.co/v1/tracks/" + j.optString("id") + "/stream?app_name=Pulse";
      rows.add(t);
    }
    return rows;
  }

  public List<Track> trending() throws Exception {
    return audiusRows(
        object("https://api.audius.co/v1/tracks/trending?limit=50&app_name=Pulse")
            .optJSONArray("data"));
  }

  public static final class Result {
    public final List<Track> tracks = new ArrayList<>();
    public final List<String> failed = new ArrayList<>();
  }

  public Result search(String query, List<Track> local) {
    ExecutorService pool = Executors.newFixedThreadPool(3);
    Result result = new Result();
    List<Callable<List<Track>>> calls =
        Arrays.asList(
            () -> scRows(scPage("/search?q=" + enc(query)), null),
            () ->
                audiusRows(
                    object(
                            "https://api.audius.co/v1/tracks/search?query="
                                + enc(query)
                                + "&limit=40&app_name=Pulse")
                        .optJSONArray("data")),
            () -> yandex(query));
    try {
      List<Future<List<Track>>> jobs = pool.invokeAll(calls, 17, TimeUnit.SECONDS);
      String[] names = {"SoundCloud", "Audius", "Яндекс"};
      for (int i = 0; i < jobs.size(); i++)
        try {
          result.tracks.addAll(jobs.get(i).get());
        } catch (Exception e) {
          result.failed.add(names[i]);
        }
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    } finally {
      pool.shutdownNow();
    }
    for (Track t : local) if (Matching.score(query, t) > 20) result.tracks.add(t);
    LinkedHashMap<String, Track> unique = new LinkedHashMap<>();
    for (Track t : result.tracks) unique.put(t.id, t);
    result.tracks.clear();
    result.tracks.addAll(unique.values());
    result.tracks.sort(
        Comparator.comparingDouble((Track t) -> Matching.score(query, t)).reversed());
    return result;
  }

  List<Track> yandex(String query) throws Exception {
    JSONObject root =
        object(
                "https://api.music.yandex.net/search?text="
                    + enc(query)
                    + "&type=track&page=0&nocorrect=false")
            .getJSONObject("result");
    JSONObject tracks = root.optJSONObject("tracks");
    JSONArray a = tracks == null ? null : tracks.optJSONArray("results");
    List<Track> out = new ArrayList<>();
    for (int i = 0; a != null && i < a.length(); i++) {
      JSONObject j = a.getJSONObject(i);
      Track t = new Track();
      t.id = "yandex:" + j.optString("id");
      t.source = "yandex";
      t.title = j.optString("title");
      if (!j.optString("version").isEmpty()) t.title += " (" + j.optString("version") + ")";
      t.duration = j.optLong("durationMs");
      JSONArray artists = j.optJSONArray("artists");
      List<String> names = new ArrayList<>();
      for (int n = 0; artists != null && n < artists.length(); n++)
        names.add(artists.getJSONObject(n).optString("name"));
      t.artist = String.join(", ", names);
      if (artists != null && artists.length() > 0)
        t.artistId = artists.getJSONObject(0).optString("id");
      String cover = j.optString("coverUri");
      if (!cover.isEmpty()) t.cover = "https://" + cover.replace("%%", "400x400");
      out.add(t);
    }
    return out;
  }

  public List<Track> artist(Track t) throws Exception {
    if (t.source.equals("soundcloud") && !t.artistUrl.isEmpty())
      return scRows(scPage(t.artistUrl), null);
    if (t.source.equals("audius")) {
      List<Track> all = new ArrayList<>();
      Set<String> seen = new HashSet<>();
      int offset = 0;
      while (true) {
        JSONArray data =
            object(
                    "https://api.audius.co/v1/users/"
                        + t.artistId
                        + "/tracks?limit=100&offset="
                        + offset
                        + "&app_name=Pulse")
                .optJSONArray("data");
        List<Track> batch = audiusRows(data);
        int added = 0;
        for (Track row : batch)
          if (seen.add(row.id)) {
            all.add(row);
            added++;
          }
        if (data == null || data.length() < 100 || added == 0) return all;
        offset += data.length();
      }
    }
    List<Track> all = search(t.artist, new ArrayList<>()).tracks;
    all.removeIf(row -> !Matching.normalize(row.artist).contains(Matching.normalize(t.artist)));
    return all;
  }

  public List<Track> related(Track seed) throws Exception {
    List<Track> rows = new ArrayList<>();
    if (seed != null && seed.source.equals("soundcloud")) {
      JSONObject page = scPage(seed.url),
          entities = page.getJSONObject("initialStoreState").getJSONObject("entities");
      JSONObject collections = records(entities, "relatedTracksCollections"),
          collection = collections.optJSONObject(page.optString("trackUrn"));
      if (collection != null) rows.addAll(scRows(page, collection.optJSONArray("collection")));
      if (rows.size() < 40)
        rows.addAll(scRows(scPage("/search?q=" + enc(seed.artist + " " + seed.genre)), null));
    }
    if (rows.size() < 45) {
      String genre = seed == null ? "" : seed.genre;
      try {
        rows.addAll(
            audiusRows(
                object(
                        "https://api.audius.co/v1/tracks/trending?limit=100&app_name=Pulse"
                            + (genre.isEmpty() ? "" : "&genre=" + enc(genre)))
                    .optJSONArray("data")));
      } catch (Exception e) {
        if (rows.isEmpty()) rows.addAll(trending());
      }
    }
    LinkedHashMap<String, Track> unique = new LinkedHashMap<>();
    for (Track t : rows) if (seed == null || !t.id.equals(seed.id)) unique.put(t.id, t);
    rows = new ArrayList<>(unique.values());
    Collections.shuffle(rows);
    return rows;
  }

  public Track resolve(Track t, List<Track> library) throws Exception {
    if (t.source.equals("local")) return t;
    if (t.source.equals("audius")) {
      String id = t.id.substring(7);
      JSONObject j =
          object("https://api.audius.co/v1/tracks/" + id + "?app_name=Pulse").getJSONObject("data");
      if (audiusRows(new JSONArray().put(j)).isEmpty())
        throw new IOException("Источник ограничил доступ");
      return t;
    }
    if (t.source.equals("soundcloud")) {
      List<Track> rows = scRows(scPage(t.url), null);
      for (Track row : rows) if (row.id.equals(t.id)) return row;
      throw new IOException("SoundCloud не разрешил полную запись");
    }
    for (Track match : search(t.artist + " " + t.title, library).tracks)
      if (!match.source.equals("yandex") && Matching.sameRecording(t, match))
        return resolve(match, library);
    throw new IOException("Совпадающая полная открытая запись не найдена");
  }
}
