package fun.pulse.music;

import android.app.AlertDialog;
import android.graphics.Color;
import android.text.InputType;
import android.widget.*;
import java.io.*;
import java.util.*;
import org.json.*;

/**
 * The desktop background schemas are shipped unchanged; every original parameter remains editable.
 */
final class BackgroundEditor {
  final MainActivity a;
  final JSONObject schemas;

  BackgroundEditor(MainActivity activity) {
    a = activity;
    try (InputStream in = a.getAssets().open("background-schemas.json");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
      byte[] b = new byte[4096];
      int n;
      while ((n = in.read(b)) > 0) bytes.write(b, 0, n);
      schemas = new JSONObject(bytes.toString("UTF-8"));
    } catch (Exception e) {
      throw new IllegalStateException(e);
    }
  }

  JSONObject props(String effect) {
    JSONObject values = a.store.object("effect:" + effect);
    JSONArray rows = schemas.optJSONArray(effect);
    if (rows != null)
      for (int i = 0; i < rows.length(); i++) {
        JSONArray row = rows.optJSONArray(i);
        if (row != null && !values.has(row.optString(1)))
          try {
            values.put(row.optString(1), row.opt(2));
          } catch (Exception ignored) {
          }
      }
    return values;
  }

  void set(String effect, String key, Object value) {
    JSONObject values = props(effect);
    try {
      values.put(key, value);
      a.store.put("effect:" + effect, values.toString());
      a.applyBackground();
    } catch (Exception ignored) {
    }
  }

  void show() {
    a.startPage("appearance");
    LinearLayout body = a.column();
    a.header(body, "Оформление", a::profile);
    body.addView(a.text("Фон приложения", 20, a.TEXT, true));
    a.space(body, 14);
    String effect = a.store.get("effect", "vortex");
    String[] names = {"Liquid Metal Vortex", "Liquid Chrome", "Dark Veil", "Silk", "Iridescence"},
        effects = {"vortex", "chrome", "veil", "silk", "iridescence"};
    for (int i = 0; i < effects.length; i++) {
      String chosen = effects[i];
      body.addView(
          a.button(
              (effect.equals(chosen) ? "✓  " : "") + names[i],
              () -> {
                a.store.put("effect", chosen);
                a.applyBackground();
                show();
              }));
      a.space(body, 10);
    }
    a.space(body, 12);
    body.addView(a.text("Настройки фона", 20, a.TEXT, true));
    if (effect.equals("vortex")) {
      control(body, effect, "Скорость", "speed", .6, 0, 3, .01);
      control(body, effect, "Оттенок", "hue", 0, 0, 360, 1);
      control(body, effect, "Сложность", "complexity", 5, 1, 8, 1);
    } else {
      JSONArray rows = schemas.optJSONArray(effect);
      JSONObject p = props(effect);
      for (int i = 0; rows != null && i < rows.length(); i++) {
        JSONArray r = rows.optJSONArray(i);
        if (r == null) continue;
        String label = r.optString(0), key = r.optString(1);
        Object value = p.opt(key);
        if (value instanceof Boolean) {
          Switch toggle = new Switch(a);
          toggle.setText(label.replace("курсор", "касание"));
          toggle.setTextColor(a.TEXT);
          toggle.setTextSize(14);
          toggle.setTypeface(a.font);
          toggle.setPadding(0, a.dp(12), 0, a.dp(12));
          toggle.setChecked((Boolean) value);
          toggle.setOnCheckedChangeListener((v, on) -> set(effect, key, on));
          body.addView(toggle);
        } else if (value instanceof String) {
          a.field(body, label, a.button(value.toString(), () -> color(effect, key, label)));
        } else
          control(
              body,
              effect,
              label,
              key,
              p.optDouble(key),
              r.optDouble(3),
              r.optDouble(4),
              r.optDouble(5));
      }
    }
    a.space(body, 22);
    body.addView(a.text("За панелями", 20, a.TEXT, true));
    a.slider(body, "Яркость фона", "intensity", 10, 100, 55, v -> a.applyBackground());
    a.slider(
        body,
        "Плотность панелей",
        "panelAlpha",
        64,
        220,
        165,
        v -> {
          a.panelAlpha = v;
          a.applyBackground();
        });
    a.slider(body, "Затемнение краёв", "edge", 0, 100, 60, v -> a.applyBackground());
    a.toggleSetting(body, "Анимация", "motion", true);
    a.space(body, 12);
    body.addView(
        a.button(
            "Применить",
            () -> {
              a.applyBackground();
              show();
            }));
    a.space(body, 10);
    body.addView(
        a.button(
            "Сбросить этот фон",
            () -> {
              a.store.put("effect:" + effect, "{}");
              a.applyBackground();
              show();
            }));
    a.space(body, 14);
    body.addView(
        a.text(
            "Режим телефона: до 24 кадров/с, плотность рендера до 1×. В фоне анимация"
                + " приостанавливается.",
            12,
            a.MUTED,
            false));
    a.surface(a.scroll(body));
  }

  void control(
      LinearLayout body,
      String effect,
      String label,
      String key,
      double fallback,
      double min,
      double max,
      double step) {
    double current = props(effect).optDouble(key, fallback);
    a.space(body, 16);
    TextView title = a.text(label + " · " + format(current), 13, a.MUTED, false);
    body.addView(title);
    SeekBar s = new SeekBar(a);
    int steps = Math.max(1, (int) Math.round((max - min) / step));
    s.setMax(steps);
    s.setProgress((int) Math.round((current - min) / step));
    s.setProgressTintList(android.content.res.ColorStateList.valueOf(a.ACCENT));
    s.setThumbTintList(android.content.res.ColorStateList.valueOf(a.ACCENT));
    s.setOnSeekBarChangeListener(
        new SeekBar.OnSeekBarChangeListener() {
          public void onStartTrackingTouch(SeekBar b) {}

          public void onStopTrackingTouch(SeekBar b) {
            double value = min + b.getProgress() * step;
            set(effect, key, value);
          }

          public void onProgressChanged(SeekBar b, int p, boolean from) {
            title.setText(label + " · " + format(min + p * step));
          }
        });
    body.addView(s, new LinearLayout.LayoutParams(-1, a.dp(48)));
  }

  static String format(double v) {
    return String.format(Locale.ROOT, "%.3f", v).replaceAll("0+$", "").replaceAll("\\.$", "");
  }

  void color(String effect, String key, String label) {
    EditText hex = a.input("#7c3aed", props(effect).optString(key), InputType.TYPE_CLASS_TEXT);
    AlertDialog dialog =
        new AlertDialog.Builder(a)
            .setTitle(label)
            .setView(hex)
            .setPositiveButton("Сохранить", null)
            .setNegativeButton("Отмена", null)
            .create();
    dialog.setOnShowListener(
        d ->
            dialog
                .getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(
                    v -> {
                      String value = hex.getText().toString().trim();
                      if (!value.matches("#[a-fA-F0-9]{6}")) {
                        hex.setError("Введи цвет в формате #7c3aed");
                        return;
                      }
                      set(effect, key, value);
                      dialog.dismiss();
                      show();
                    }));
    dialog.show();
  }

  JSONObject config(boolean foreground) throws Exception {
    String effect = a.store.get("effect", "vortex");
    JSONObject p = props(effect);
    for (String key : new String[] {"color", "baseColor"})
      if (p.has(key)
          && p.opt(key) instanceof String
          && (effect.equals("chrome") || effect.equals("iridescence"))) {
        int color = Color.parseColor(p.getString(key));
        String name = effect.equals("chrome") ? "baseColor" : "color";
        p.remove(key);
        p.put(
            name,
            new JSONArray()
                .put(Color.red(color) / 255.0)
                .put(Color.green(color) / 255.0)
                .put(Color.blue(color) / 255.0));
      }
    p.put("dpr", Math.min(1, p.optDouble("dpr", 1)));
    p.put("maxDevicePixelRatio", Math.min(1, p.optDouble("maxDevicePixelRatio", 1)));
    return new JSONObject()
        .put("effect", effect)
        .put("props", p)
        .put("fps", 24)
        .put("intensity", Integer.parseInt(a.store.get("intensity", "55")) / 100.0)
        .put("edge", Integer.parseInt(a.store.get("edge", "60")) / 100.0)
        .put("blur", 0)
        .put("paused", !foreground || !a.store.get("motion", "true").equals("true"));
  }
}
