package fun.pulse.music;

import android.app.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.view.*;
import android.view.inputmethod.*;
import android.webkit.*;
import android.widget.*;
import androidx.media3.common.*;
import androidx.media3.session.*;
import androidx.media3.session.MediaController;
import com.google.common.util.concurrent.ListenableFuture;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public final class MainActivity extends Activity {
  final Handler ui = new Handler(Looper.getMainLooper());
  final ExecutorService workers = Executors.newFixedThreadPool(4);
  final Catalog catalog = new Catalog();
  Store store;
  CloudSync cloud;
  YandexUi yandexUi;
  PlaylistUI playlists;
  Icons nowLikeIcon, nowDislikeIcon;
  NowPlayingView nowView;
  ArtworkLoader artwork;
  List<Track> dislikes = new ArrayList<>();
  String displayedNowId = "";
  Typeface font, bold;
  FrameLayout root, content;
  LinearLayout shell, nav, mini;
  VortexView vortex;
  BackgroundEditor backgroundEditor;
  WebView background;
  CustomBackground customBackground;
  MediaController player;
  ListenableFuture<MediaController> controllerFuture;
  List<Track> queue = new ArrayList<>(),
      favorites = new ArrayList<>(),
      library = new ArrayList<>(),
      seeds = new ArrayList<>(),
      history = new ArrayList<>(),
      homeRows = new ArrayList<>();
  Track current;
  int index = -1, viewGeneration = 0, playGeneration = 0;
  volatile int authGeneration = 0;
  long resumePosition = 0, lastSave = 0;
  boolean touring = false;
  CoachMarks coach;
  MobileUpdates updates;
  ImageView miniArt;
  TrackSheet trackSheet;
  WaveHero waveHero;
  String miniArtId = "";
  boolean loading = false, registerMode = false, foreground = true;
  String page = "home", lastQuery = "", status = "";
  TextView miniTitle, miniArtist, miniState, nowTime, nowStatus;
  LinearLayout miniControls;
  Icons miniPlayIcon, nowPlayIcon;
  SeekBar nowSeek;
  boolean seeking = false;
  int TEXT = 0xfff1eef2, MUTED = 0xffbcc0cb, ACCENT = 0xffdfbdcd;
  int panelAlpha = 165;
  LinkedHashMap<String, Bitmap> imageCache = new LinkedHashMap<>(32, .75f, true);
  Set<String> imageLoading = new HashSet<>();
  Map<String, List<ImageView>> imageWaiters = new HashMap<>();

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    store = new Store(this);
    artwork = new ArtworkLoader(this);
    dislikes = store.tracks("dislikes");
    playlists = new PlaylistUI(this);
    yandexUi = new YandexUi(this);
    font =
        new Typeface.Builder(getAssets(), "fonts/Manrope.ttf")
            .setFontVariationSettings("'wght' 500")
            .setWeight(500)
            .build();
    bold =
        new Typeface.Builder(getAssets(), "fonts/Manrope.ttf")
            .setFontVariationSettings("'wght' 700")
            .setWeight(700)
            .build();
    favorites = store.tracks("favorites");
    library = store.tracks("library");
    history = store.tracks("history");
    seeds = store.tracks("seeds");
    panelAlpha = Integer.parseInt(store.get("panelAlpha", "165"));
    restore();
    build();
    connect();
    if (!store.loggedIn()) auth(false);
    else if (!store.get("tour:" + store.object("profile").optString("id"), "false").equals("true"))
      tour(0);
    else home();
    ui.post(tick);
    cloud = new CloudSync(this);
    updates = new MobileUpdates(this);
    updates.check();
  }

  int dp(float n) {
    return Math.round(n * getResources().getDisplayMetrics().density);
  }

  GradientDrawable glass(float radius) {
    GradientDrawable d = new GradientDrawable();
    d.setColor(Color.argb(panelAlpha, 17, 20, 24));
    d.setCornerRadius(dp(radius));
    d.setStroke(dp(1), 0x703e444b);
    return d;
  }

  GradientDrawable buttonBg() {
    GradientDrawable d =
        new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, new int[] {0xe633333b, 0xc5111216});
    d.setCornerRadius(dp(24));
    d.setStroke(dp(1), 0x908f818b);
    return d;
  }

  LinearLayout column() {
    LinearLayout v = new LinearLayout(this);
    v.setOrientation(LinearLayout.VERTICAL);
    return v;
  }

  LinearLayout row() {
    LinearLayout v = new LinearLayout(this);
    v.setGravity(Gravity.CENTER_VERTICAL);
    return v;
  }

  TextView text(String value, int size, int color, boolean heavy) {
    TextView t = new TextView(this);
    t.setText(value);
    t.setTextColor(color);
    t.setTextSize(size);
    t.setTypeface(heavy ? bold : font);
    t.setLineSpacing(dp(3), 1);
    t.setIncludeFontPadding(false);
    return t;
  }

  TextView label(String value, int size) {
    return text(value, size, TEXT, false);
  }

  void space(LinearLayout v, int h) {
    View x = new View(this);
    v.addView(x, new LinearLayout.LayoutParams(1, dp(h)));
  }

  LinearLayout.LayoutParams weighted() {
    return new LinearLayout.LayoutParams(0, -2, 1);
  }

  void tap(View v, Runnable run) {
    v.setOnClickListener(
        w -> {
          v.animate()
              .scaleX(.96f)
              .scaleY(.96f)
              .setDuration(80)
              .withEndAction(
                  () -> {
                    v.animate().scaleX(1).scaleY(1).setDuration(160).start();
                    run.run();
                  })
              .start();
        });
  }

  TextView button(String title, Runnable run) {
    TextView b = text(title, 14, TEXT, true);
    b.setGravity(Gravity.CENTER);
    b.setPadding(dp(16), dp(13), dp(16), dp(13));
    b.setMinHeight(dp(48));
    b.setBackground(buttonBg());
    tap(b, run);
    return b;
  }

  View icon(String kind, String description, Runnable run) {
    Icons i = new Icons(this, kind);
    i.setContentDescription(description);
    i.setMinimumWidth(dp(48));
    i.setMinimumHeight(dp(48));
    if (run != null) tap(i, run);
    return i;
  }

  void addIcon(LinearLayout row, String kind, String description, Runnable run) {
    row.addView(icon(kind, description, run), new LinearLayout.LayoutParams(dp(48), dp(48)));
  }

  EditText input(String hint, String value, int type) {
    EditText e = new EditText(this);
    e.setTextColor(TEXT);
    e.setHintTextColor(MUTED);
    e.setTypeface(font);
    e.setTextSize(15);
    e.setSingleLine(true);
    e.setInputType(type);
    e.setHint(hint);
    e.setText(value);
    e.setPadding(dp(16), dp(12), dp(16), dp(12));
    e.setBackground(glass(18));
    e.setMinHeight(dp(52));
    return e;
  }

  void field(LinearLayout layout, String title, View field) {
    space(layout, 16);
    layout.addView(text(title, 13, MUTED, false));
    space(layout, 8);
    layout.addView(field, new LinearLayout.LayoutParams(-1, -2));
  }

  ScrollView scroll(LinearLayout body) {
    ScrollView s = new ScrollView(this);
    s.setFillViewport(true);
    s.setClipToPadding(true);
    s.setOverScrollMode(View.OVER_SCROLL_NEVER);
    s.setVerticalScrollBarEnabled(false);
    s.setVerticalFadingEdgeEnabled(false);
    s.setPadding(dp(16), dp(8), dp(16), dp(24));
    s.addView(body, new ScrollView.LayoutParams(-1, -2));
    return s;
  }

  void surface(View view) {
    if (!page.equals("auth") && !page.equals("tour")) {
      if (!store.loggedIn()) {
        auth(false);
        return;
      }
      if (!touring
          && !store
              .get("tour:" + store.object("profile").optString("id"), "false")
              .equals("true")) {
        tour(0);
        return;
      }
    }
    content.removeAllViews();
    content.setClipChildren(true);
    content.addView(view, new FrameLayout.LayoutParams(-1, -1));
    if (view instanceof ListView || view instanceof ScrollView) {
      View fade = new View(this);
      fade.setBackground(
          new GradientDrawable(
              GradientDrawable.Orientation.TOP_BOTTOM, new int[] {0x00101418, 0xd0101418}));
      fade.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
      FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(-1, dp(16), Gravity.BOTTOM);
      content.addView(fade, fp);
    }
    MobileMotion.enter(view, touring);
  }

  void build() {
    getWindow().setStatusBarColor(Color.TRANSPARENT);
    getWindow().setNavigationBarColor(Color.TRANSPARENT);
    root = new FrameLayout(this);
    root.setBackgroundColor(0xff08090b);
    setContentView(root);
    vortex = new VortexView(this);
    root.addView(vortex, new FrameLayout.LayoutParams(-1, -1));
    backgroundEditor = new BackgroundEditor(this);
    background = new WebView(this);
    background.setBackgroundColor(Color.TRANSPARENT);
    background.getSettings().setJavaScriptEnabled(true);
    background.getSettings().setAllowFileAccess(true);
    background.getSettings().setAllowContentAccess(false);
    background.setOnTouchListener((view, event) -> true);
    background.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
    background.setWebViewClient(
        new WebViewClient() {
          @Override
          public void onPageFinished(WebView w, String url) {
            applyBackground();
          }
        });
    background.loadUrl("file:///android_asset/backgrounds/index.html");
    root.addView(background, new FrameLayout.LayoutParams(-1, -1));
    customBackground = new CustomBackground(this);
    customBackground.setVisibility(View.GONE);
    root.addView(customBackground, new FrameLayout.LayoutParams(-1, -1));
    shell = column();
    root.addView(shell, new FrameLayout.LayoutParams(-1, -1));
    shell.setOnApplyWindowInsetsListener(
        (v, insets) -> {
          android.graphics.Insets bars;
          if (Build.VERSION.SDK_INT >= 30) {
            bars =
                insets.getInsets(
                    WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout()
                        | WindowInsets.Type.ime());
            shell.setPadding(bars.left, bars.top, bars.right, bars.bottom);
          } else {
            shell.setPadding(
                insets.getSystemWindowInsetLeft(),
                insets.getSystemWindowInsetTop(),
                insets.getSystemWindowInsetRight(),
                insets.getSystemWindowInsetBottom());
          }
          return insets;
        });
    LinearLayout brand = row();
    brand.setPadding(dp(20), dp(8), dp(12), dp(4));
    ImageView logo = new ImageView(this);
    logo.setImageResource(R.drawable.pulse_logo);
    brand.addView(logo, new LinearLayout.LayoutParams(dp(24), dp(24)));
    TextView name = text("  P U L S E", 12, TEXT, true);
    brand.addView(name, new LinearLayout.LayoutParams(0, dp(40), 1));
    name.setGravity(Gravity.CENTER_VERTICAL);
    addIcon(
        brand, "support", "Поддержка", () -> open("https://t.me/PulseMusicHelpBot?start=support"));
    shell.addView(brand);
    content = new FrameLayout(this);
    shell.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
    mini = new SwipePlayer(this, this::advance);
    mini.setContentDescription("Мини-плеер. Свайп влево — следующий трек, вправо — предыдущий");
    mini.setPadding(dp(10), dp(6), dp(10), dp(6));
    mini.setBackground(glass(20));
    LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(76));
    mp.setMargins(dp(10), dp(4), dp(10), dp(4));
    shell.addView(mini, mp);
    buildMini();
    nav = row();
    nav.setPadding(dp(6), 0, dp(6), 0);
    nav.setBackground(glass(22));
    String[] names = {"Главная", "Поиск", "Любимое", "Профиль"},
        icons = {"home", "search", "heart", "profile"};
    for (int n = 0; n < 4; n++) {
      final int pos = n;
      LinearLayout item = column();
      item.setGravity(Gravity.CENTER);
      Icons i = new Icons(this, icons[n]);
      item.addView(i, new LinearLayout.LayoutParams(dp(40), dp(36)));
      TextView title = text(names[n], 11, MUTED, false);
      title.setGravity(Gravity.CENTER);
      title.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
      title.setSingleLine(true);
      item.addView(
          title,
          new LinearLayout.LayoutParams(
              -1, dp(24 * Math.max(1, getResources().getConfiguration().fontScale))));
      item.setContentDescription(names[n]);
      item.setOnClickListener(
          v -> {
            MobileMotion.press(item);
            navigate(pos);
          });
      nav.addView(
          item,
          new LinearLayout.LayoutParams(
              0, dp(40 + 24 * Math.max(1, getResources().getConfiguration().fontScale)), 1));
    }
    shell.addView(nav);
  }

  void navigate(int pos) {
    if (!store.loggedIn()) {
      auth(false);
      return;
    }
    if (!touring
        && !store.get("tour:" + store.object("profile").optString("id"), "false").equals("true")) {
      tour(0);
      return;
    }
    switch (pos) {
      case 0:
        home();
        break;
      case 1:
        searchPage();
        break;
      case 2:
        showCollection("Любимые треки", favorites);
        break;
      default:
        profile();
    }
  }

  void header(LinearLayout body, String title, Runnable back) {
    LinearLayout h = row();
    if (back != null) addIcon(h, "back", "Назад", back);
    h.addView(text(title, 23, TEXT, true), new LinearLayout.LayoutParams(0, -2, 1));
    body.addView(h);
    space(body, 18);
  }

  void startPage(String name) {
    page = name;
    waveHero = null;
    MobileMotion.selectNavigation(this, name);
    viewGeneration++;
    nowPlayIcon = null;
    nowLikeIcon = null;
    nowDislikeIcon = null;
    nowView = null;
    nowSeek = null;
    nowTime = null;
    nowStatus = null;
    mini.setVisibility(store.loggedIn() && !name.equals("now") ? View.VISIBLE : View.GONE);
    nav.setVisibility(store.loggedIn() && !name.equals("now") ? View.VISIBLE : View.GONE);
  }

  void home() {
    history = store.tracks("history");
    startPage("home");
    LinearLayout body = column();
    space(body, 8);
    LinearLayout hero = column();
    hero.setPadding(dp(22), dp(24), dp(22), dp(22));
    hero.setBackground(glass(26));
    TextView hello = text("ТВОЙ МУЗЫКАЛЬНЫЙ ПОТОК", 10, MUTED, true);
    hello.setLetterSpacing(.1f);
    hero.addView(hello);
    space(hero, 20);
    LinearLayout heroRow = row();
    TextView title = text("Моя\nволна", 40, TEXT, true);
    title.setLineSpacing(0, 1.02f);
    heroRow.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
    View play = icon("play", "Играть мою волну", () -> wave(null));
    play.setBackground(buttonBg());
    heroRow.addView(play, new LinearLayout.LayoutParams(dp(64), dp(64)));
    hero.addView(heroRow);
    space(hero, 22);
    LinearLayout recent = row();
    for (Track t : seeds.subList(0, Math.min(3, seeds.size()))) {
      FrameLayout card = new FrameLayout(this);
      ImageView img = art(t, 54);
      card.addView(img, new FrameLayout.LayoutParams(dp(54), dp(54)));
      card.setContentDescription("Волна: " + t.artist + " — " + t.title);
      tap(card, () -> wave(t));
      LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(54), dp(54));
      lp.setMargins(0, 0, dp(10), 0);
      recent.addView(card, lp);
    }
    TextView tune = text("Настроить", 12, MUTED, false);
    tune.setPadding(dp(8), dp(12), dp(8), dp(12));
    tap(tune, this::waveSettings);
    recent.addView(tune);
    hero.addView(recent);
    body.addView(hero);
    space(body, 12);
    LinearLayout tiles = row();
    TextView hist = button("История", () -> showCollection("История", history)),
        likes = button("Любимые треки", () -> showCollection("Любимые треки", favorites));
    tiles.addView(hist, weighted());
    View gap = new View(this);
    tiles.addView(gap, new LinearLayout.LayoutParams(dp(10), 1));
    tiles.addView(likes, weighted());
    body.addView(tiles);
    space(body, 10);
    body.addView(button("Мои плейлисты", playlists::show));
    space(body, 24);
    LinearLayout heading = row();
    heading.addView(text("Для вас", 23, TEXT, true), weighted());
    addIcon(heading, "plus", "Добавить свои треки", this::pickMusic);
    body.addView(heading);
    space(body, 8);
    if (homeRows.isEmpty()) {
      TextView state = text("Загружаем музыку…", 14, MUTED, false);
      body.addView(state);
      final int generation = viewGeneration;
      workers.execute(
          () -> {
            try {
              List<Track> rows = catalog.forYou(favorites, store.tracks("history"));
              Feedback.filter(rows, store.tracks("dislikes"));
              ui.post(
                  () -> {
                    homeRows = rows;
                    if (page.equals("home") && generation == viewGeneration) home();
                  });
            } catch (Exception e) {
              ui.post(
                  () -> {
                    if (generation == viewGeneration) {
                      state.setText("Не удалось загрузить музыку. Проверь подключение.");
                      body.addView(button("Повторить", this::home));
                    }
                  });
            }
          });
    } else
      for (Track t : homeRows.subList(0, Math.min(18, homeRows.size())))
        body.addView(trackRow(t, homeRows));
    surface(scroll(body));
  }

  ImageView art(Track t, int size) {
    ImageView image = new ImageView(this);
    image.setBackground(glass(12));
    image.setScaleType(ImageView.ScaleType.CENTER_CROP);
    image.setClipToOutline(true);
    if (t == null) image.setImageResource(R.drawable.pulse_logo);
    else artwork.bind(image, t);
    image.setMinimumWidth(dp(size));
    image.setMinimumHeight(dp(size));
    return image;
  }

  View trackRow(Track t, List<Track> context) {
    LinearLayout card = row();
    card.setPadding(dp(10), dp(9), dp(4), dp(9));
    card.setBackground(glass(18));
    card.setMinimumHeight(dp(76));
    ImageView image = art(t, 48);
    card.addView(image, new LinearLayout.LayoutParams(dp(48), dp(48)));
    LinearLayout labels = column();
    labels.setPadding(dp(12), 0, 0, 0);
    TextView title = text(t.title, 14, TEXT, true);
    title.setMaxLines(2);
    title.setEllipsize(TextUtils.TruncateAt.END);
    labels.addView(title);
    space(labels, 5);
    TextView artist = text(t.artist, 12, MUTED, false);
    artist.setSingleLine(true);
    artist.setEllipsize(TextUtils.TruncateAt.END);
    labels.addView(artist);
    card.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
    addIcon(card, "more", "Меню: " + t.title, () -> trackMenu(t));
    tap(card, () -> play(t, context));
    card.setOnLongClickListener(
        v -> {
          trackMenu(t);
          return true;
        });
    LinearLayout wrap = column();
    wrap.addView(card);
    space(wrap, 8);
    return wrap;
  }

  void showCollection(String title, List<Track> rows) {
    startPage("collection");
    LinearLayout header = column();
    header.setPadding(dp(16), dp(8), dp(16), dp(10));
    header(header, title, this::home);
    header.addView(text(rows.size() + " треков", 13, MUTED, false));
    if (title.equals("Любимые треки")) {
      space(header, 10);
      header.addView(button("Мои плейлисты", playlists::show));
    }
    space(header, 12);
    header.addView(
        button(
            "Играть всё",
            () -> {
              if (!rows.isEmpty()) play(rows.get(0), rows);
            }));
    showList(header, rows);
  }

  void showList(LinearLayout heading, List<Track> rows) {
    ListView list = new ListView(this);
    list.setDivider(null);
    list.setPadding(dp(12), 0, dp(12), 0);
    list.setClipToPadding(true);
    list.setOverScrollMode(View.OVER_SCROLL_NEVER);
    list.setVerticalScrollBarEnabled(false);
    list.setVerticalFadingEdgeEnabled(false);
    list.addHeaderView(heading, null, false);
    list.setAdapter(
        new BaseAdapter() {
          public int getCount() {
            return rows.size();
          }

          public Object getItem(int p) {
            return rows.get(p);
          }

          public long getItemId(int p) {
            return p;
          }

          public View getView(int p, View old, android.view.ViewGroup parent) {
            return trackRow(rows.get(p), rows);
          }
        });
    if (rows.isEmpty()) {
      TextView empty = text("Здесь пока нет треков", 15, MUTED, false);
      empty.setPadding(dp(18), dp(28), dp(18), dp(28));
      list.addFooterView(empty, null, false);
    }
    surface(list);
  }

  void searchPage() {
    startPage("search");
    LinearLayout body = column();
    header(body, "Найти музыку", this::home);
    EditText query =
        input("Трек или исполнитель", lastQuery, android.text.InputType.TYPE_CLASS_TEXT);
    query.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
    body.addView(query);
    space(body, 12);
    LinearLayout results = column();
    body.addView(button("Найти", () -> search(query.getText().toString(), body, results)));
    query.setOnEditorActionListener(
        (v, a, event) -> {
          if (a == EditorInfo.IME_ACTION_SEARCH) {
            search(query.getText().toString(), body, results);
            return true;
          }
          return false;
        });
    space(body, 20);
    body.addView(results);
    surface(scroll(body));
  }

  void search(String q, LinearLayout body, LinearLayout results) {
    q = q.trim();
    if (q.isEmpty()) return;
    lastQuery = q;
    ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
        .hideSoftInputFromWindow(body.getWindowToken(), 0);
    final int generation = ++viewGeneration;
    results.removeAllViews();
    results.addView(text("Ищем во всех источниках…", 14, MUTED, false));
    String query = q;
    workers.execute(
        () -> {
          Catalog.Result data = catalog.search(query, library);
          ui.post(
              () -> {
                if (generation != viewGeneration) return;
                results.removeAllViews();
                if (!data.failed.isEmpty()) {
                  TextView notice =
                      text(
                          "Временно недоступно: " + String.join(", ", data.failed),
                          12,
                          MUTED,
                          false);
                  results.addView(notice);
                  space(results, 12);
                }
                if (data.tracks.isEmpty()) {
                  artistCards(results, data.artists);
                  results.addView(
                      text("Ничего не найдено. Попробуй название и исполнителя.", 16, TEXT, false));
                } else {
                  LinearLayout head = column();
                  header(head, "Результаты", this::searchPage);
                  head.addView(
                      text(query + " · " + data.tracks.size() + " треков", 13, MUTED, false));
                  List<Track> artists = new ArrayList<>(data.artists);
                  artists.addAll(data.tracks);
                  artistCards(head, Catalog.artistCards(query, artists));
                  if (!data.failed.isEmpty()) {
                    space(head, 8);
                    head.addView(
                        text(
                            "Часть источников недоступна: " + String.join(", ", data.failed),
                            12,
                            MUTED,
                            false));
                  }
                  space(head, 16);
                  showList(head, data.tracks);
                }
              });
        });
  }

  void trackMenu(Track t) {
    if (trackSheet != null) trackSheet.dismiss();
    trackSheet = new TrackSheet(this, t);
    trackSheet.show();
  }

  void trackAction(Track t, int action) {
    switch (action) {
      case 0:
        toggleFavorite(t);
        break;
      case 1:
        wave(t);
        break;
      case 2:
        int next = Math.max(0, index + 1);
        queue.add(Math.min(next, queue.size()), t);
        store.tracks("queue", queue);
        if (player != null) player.sendCustomCommand(PlaybackService.SYNC_QUEUE, Bundle.EMPTY);
        saveSession();
        toast("Добавлено в очередь");
        break;
      case 3:
        artist(t);
        break;
      case 4:
        versions(t);
        break;
      case 5:
        playlists.choose(t);
        break;
      case 6:
        playlists.remove(t);
        break;
    }
  }

  void toggleFavorite(Track t) {
    boolean removed = favorites.removeIf(x -> x.id.equals(t.id));
    if (!removed) {
      favorites.add(0, t);
      dislikes.removeIf(x -> Feedback.matches(t, x));
      store.tracks("dislikes", dislikes);
      if (nowDislikeIcon != null) nowDislikeIcon.dislike(false, true);
    }
    store.tracks("favorites", favorites);
    homeRows.clear();
    if (nowLikeIcon != null) nowLikeIcon.favorite(!removed, true);
    if (page.equals("collection")) showCollection("Любимые треки", favorites);
    else refreshMini();
  }

  void toggleDislike(Track t) {
    boolean removed = dislikes.removeIf(x -> Feedback.matches(t, x));
    if (!removed) {
      dislikes.add(0, Track.from(t.json()));
      favorites.removeIf(x -> Feedback.matches(t, x));
      store.tracks("favorites", favorites);
      if (nowLikeIcon != null) nowLikeIcon.favorite(false, true);
    }
    store.tracks("dislikes", dislikes);
    homeRows.clear();
    if (nowDislikeIcon != null) nowDislikeIcon.dislike(!removed, true);
    if (!removed
        && store.get("queueRecommended", "false").equals("true")
        && index >= 0
        && index < queue.size()) {
      List<Track> remaining = new ArrayList<>(queue.subList(0, index + 1));
      for (Track row : queue.subList(index + 1, queue.size()))
        if (!Feedback.disliked(row, dislikes)) remaining.add(row);
      queue = remaining;
      store.tracks("queue", queue);
      if (player != null) player.sendCustomCommand(PlaybackService.SYNC_QUEUE, Bundle.EMPTY);
    }
    refreshMini();
  }

  void artist(Track t) {
    startPage("artist");
    LinearLayout body = column();
    header(body, "Исполнитель", this::home);
    LinearLayout hero = column();
    hero.setBackground(glass(24));
    hero.setPadding(dp(22), dp(24), dp(22), dp(24));
    hero.addView(art(t, 100), new LinearLayout.LayoutParams(dp(100), dp(100)));
    space(hero, 16);
    hero.addView(text(t.artist, 32, TEXT, true));
    space(hero, 8);
    hero.addView(text("Каталог исполнителя", 13, MUTED, false));
    body.addView(hero);
    space(body, 20);
    TextView state = text("Загружаем треки…", 14, MUTED, false);
    body.addView(state);
    surface(scroll(body));
    final int generation = viewGeneration;
    workers.execute(
        () -> {
          try {
            List<Track> rows = catalog.artist(t);
            ui.post(
                () -> {
                  if (generation != viewGeneration) return;
                  body.removeView(state);
                  body.addView(
                      button(
                          "Играть всё",
                          () -> {
                            if (!rows.isEmpty()) play(rows.get(0), rows);
                          }));
                  space(body, 12);
                  LinearLayout albums = column();
                  body.addView(albums);
                  loadAlbums(t, albums, generation);
                  showList(body, rows);
                });
          } catch (Exception e) {
            ui.post(
                () -> {
                  if (generation == viewGeneration)
                    state.setText("Не удалось загрузить каталог. Попробуй позже.");
                });
          }
        });
  }

  void artistCards(LinearLayout body, List<Track> artists) {
    if (artists.isEmpty()) return;
    space(body, 16);
    body.addView(text("Исполнители", 20, TEXT, true));
    HorizontalScrollView scroll = new HorizontalScrollView(this);
    scroll.setHorizontalScrollBarEnabled(false);
    LinearLayout cards = row();
    for (Track artist : artists) {
      LinearLayout card = column();
      card.setPadding(dp(12), dp(12), dp(12), dp(12));
      card.setBackground(glass(18));
      card.addView(art(artist, 88), new LinearLayout.LayoutParams(dp(88), dp(88)));
      space(card, 8);
      card.addView(text(artist.artist, 14, TEXT, true));
      card.setContentDescription("Исполнитель: " + artist.artist);
      tap(card, () -> artist(artist));
      LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(140), -2);
      lp.setMargins(0, dp(8), dp(10), dp(8));
      cards.addView(card, lp);
    }
    scroll.addView(cards);
    body.addView(scroll);
    space(body, 16);
  }

  void loadAlbums(Track artist, LinearLayout host, int generation) {
    workers.execute(
        () -> {
          try {
            List<Album> albums = catalog.albums(artist);
            ui.post(
                () -> {
                  if (generation != viewGeneration) return;
                  host.addView(text("Альбомы · " + albums.size(), 20, TEXT, true));
                  if (albums.isEmpty())
                    host.addView(text("Источник не вернул альбомы", 13, MUTED, false));
                  HorizontalScrollView scroll = new HorizontalScrollView(this);
                  LinearLayout cards = row();
                  for (Album album : albums) {
                    LinearLayout card = column();
                    card.setPadding(dp(10), dp(10), dp(10), dp(10));
                    Track art = new Track();
                    art.cover = album.cover;
                    card.addView(art(art, 108), new LinearLayout.LayoutParams(dp(108), dp(108)));
                    space(card, 8);
                    card.addView(text(album.title, 14, TEXT, true));
                    if (!album.year.isEmpty()) card.addView(text(album.year, 12, MUTED, false));
                    tap(card, () -> openAlbum(album));
                    cards.addView(card, new LinearLayout.LayoutParams(dp(142), -2));
                  }
                  scroll.addView(cards);
                  host.addView(scroll);
                  space(host, 16);
                });
          } catch (Exception e) {
            ui.post(
                () -> {
                  if (generation == viewGeneration)
                    host.addView(
                        button(
                            "Повторить загрузку альбомов",
                            () -> {
                              host.removeAllViews();
                              loadAlbums(artist, host, generation);
                            }));
                });
          }
        });
  }

  void openAlbum(Album album) {
    toast("Открываем альбом…");
    int generation = viewGeneration;
    workers.execute(
        () -> {
          try {
            List<Track> rows = catalog.albumTracks(album);
            ui.post(
                () -> {
                  if (generation == viewGeneration) showCollection(album.title, rows);
                });
          } catch (Exception e) {
            ui.post(() -> toast("Не удалось открыть альбом. Попробуй позже."));
          }
        });
  }

  void versions(Track t) {
    startPage("versions");
    LinearLayout body = column();
    header(body, "Версии трека", this::home);
    body.addView(text("Оригинал, ремиксы и обработки выбираются отдельно", 13, MUTED, false));
    surface(scroll(body));
    int generation = viewGeneration;
    workers.execute(
        () -> {
          Catalog.Result r = catalog.search(t.artist + " " + t.title, library);
          ui.post(
              () -> {
                if (generation != viewGeneration) return;
                showList(body, r.tracks);
              });
        });
  }

  void connect() {
    SessionToken token = new SessionToken(this, new ComponentName(this, PlaybackService.class));
    controllerFuture = new MediaController.Builder(this, token).buildAsync();
    controllerFuture.addListener(
        () -> {
          try {
            player = controllerFuture.get();
            player.addListener(
                new Player.Listener() {
                  @Override
                  public void onEvents(Player p, Player.Events e) {
                    syncPlayer();
                  }
                });
            syncPlayer();
          } catch (Exception e) {
            toast("Не удалось запустить музыкальный сервис");
          }
        },
        ui::post);
  }

  void syncPlayer() {
    if (player == null) return;
    if (player.getMediaItemCount() > 0) {
      String id = player.getCurrentMediaItem() == null ? "" : player.getCurrentMediaItem().mediaId;
      List<Track> serviceQueue = store.tracks("queue");
      for (int i = 0; i < serviceQueue.size(); i++)
        if (serviceQueue.get(i).id.equals(id)) {
          queue = serviceQueue;
          index = i;
          current = serviceQueue.get(i);
          break;
        }
      loading = player.getPlaybackState() == Player.STATE_BUFFERING;
      status =
          player.getPlayerError() != null
              ? player.getPlayerError().getMessage()
              : loading ? "Открываем полную запись…" : "";
    } else loading = false;
    if (page.equals("now")
        && current != null
        && nowView != null
        && (!current.id.equals(displayedNowId)
            || !(current.id + "|" + current.cover).equals(nowView.coverKey))) nowView.bind(current);
    refreshMini();
  }

  void play(Track t, List<Track> context) {
    store.put("queueRecommended", "false");
    queue = new ArrayList<>(context);
    index = 0;
    for (int i = 0; i < queue.size(); i++)
      if (queue.get(i).id.equals(t.id)) {
        index = i;
        break;
      }
    load(t, true, 0);
  }

  void load(Track t, boolean autoplay, long position) {
    if (!store.loggedIn()) return;
    homeRows = new ArrayList<>();
    current = t;
    resumePosition = position;
    status = "Открываем полную запись…";
    loading = true;
    if (player == null) {
      loading = false;
      status = "Музыкальный сервис запускается. Нажми играть.";
      refreshMini();
      return;
    }
    store.tracks("queue", queue);
    try {
      store.put(
          "session", new JSONObject().put("index", index).put("position", position).toString());
    } catch (Exception ignored) {
    }
    Bundle args = new Bundle();
    args.putInt("index", index);
    args.putLong("position", position);
    args.putBoolean("autoplay", autoplay);
    ListenableFuture<SessionResult> pending =
        player.sendCustomCommand(PlaybackService.PLAY_QUEUE, args);
    pending.addListener(
        () -> {
          try {
            if (pending.get().resultCode != SessionResult.RESULT_SUCCESS) {
              loading = false;
              status = "Не удалось передать очередь плееру";
              refreshMini();
            }
          } catch (Exception e) {
            loading = false;
            status = "Плеер недоступен";
            refreshMini();
          }
        },
        ui::post);
    refreshMini();
  }

  void stopAudio() {
    if (player != null) player.stop();
    loading = false;
  }

  boolean playing() {
    return player != null && player.isPlaying();
  }

  long position() {
    return player != null && player.getMediaItemCount() > 0
        ? player.getCurrentPosition()
        : resumePosition;
  }

  long duration() {
    return player != null && player.getDuration() > 0
        ? player.getDuration()
        : current == null ? 0 : current.duration;
  }

  void toggle() {
    if (current == null) {
      if (!homeRows.isEmpty()) play(homeRows.get(0), homeRows);
      return;
    }
    if (player != null && player.getMediaItemCount() > 0) {
      if (player.isPlaying() || player.getPlayWhenReady()) player.pause();
      else player.play();
    } else load(current, true, resumePosition);
  }

  void advance(int delta) {
    if (queue.isEmpty()) return;
    int selected = index + delta;
    if (selected < 0) selected = 0;
    if (selected >= queue.size()) {
      if (store.get("repeat", "false").equals("true")) selected = 0;
      else return;
    }
    if (player != null && player.getMediaItemCount() > selected) player.seekTo(selected, 0);
    else {
      index = selected;
      load(queue.get(index), true, 0);
    }
  }

  void seek(long value) {
    if (player != null) player.seekTo(value);
  }

  void buildMini() {
    mini.removeAllViews();
    LinearLayout line = row();
    miniArt = art(current, 44);
    tap(
        miniArt,
        () -> {
          if (current != null) artist(current);
        });
    miniArt.setContentDescription("Открыть исполнителя");
    LinearLayout.LayoutParams artworkParams = new LinearLayout.LayoutParams(dp(44), dp(44));
    artworkParams.setMargins(0, 0, dp(10), 0);
    line.addView(miniArt, artworkParams);
    LinearLayout labels = column();
    miniTitle = text("Пока ничего не играет", 12, TEXT, true);
    miniTitle.setSingleLine(true);
    miniTitle.setEllipsize(TextUtils.TruncateAt.END);
    miniArtist = text("Выбери трек", 11, MUTED, false);
    miniArtist.setSingleLine(true);
    labels.addView(miniTitle);
    space(labels, 3);
    labels.addView(miniArtist);
    tap(labels, this::nowPlaying);
    miniTitle.setContentDescription("Открыть карточку песни");
    tap(miniTitle, this::nowPlaying);
    tap(labels, this::nowPlaying);
    mini.setOnClickListener(v -> nowPlaying());
    line.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
    miniControls = row();
    miniPlayIcon = new Icons(this, "play");
    tap(miniPlayIcon, this::toggle);
    miniControls.addView(miniPlayIcon, new LinearLayout.LayoutParams(dp(48), dp(48)));
    addIcon(miniControls, "next", "Следующий трек", () -> advance(1));
    line.addView(miniControls);
    mini.addView(line);
    miniState = text("", 10, MUTED, false);
    miniState.setSingleLine(true);
    miniState.setEllipsize(TextUtils.TruncateAt.END);
    mini.addView(miniState);
    refreshMini();
  }

  void refreshMini() {
    if (miniTitle == null) return;
    String artId = current == null ? "" : current.id + current.cover;
    if (miniArt != null && !artId.equals(miniArtId)) {
      miniArtId = artId;
      LinearLayout parent = (LinearLayout) miniArt.getParent();
      int at = parent.indexOfChild(miniArt);
      android.view.ViewGroup.LayoutParams lp = miniArt.getLayoutParams();
      parent.removeView(miniArt);
      miniArt = art(current, 44);
      tap(
          miniArt,
          () -> {
            if (current != null) artist(current);
          });
      miniArt.setContentDescription("Открыть исполнителя");
      parent.addView(miniArt, at, lp);
    }
    miniTitle.setText(current == null ? "Пока ничего не играет" : current.title);
    miniArtist.setText(current == null ? "Выбери трек" : current.artist);
    miniArtist.setOnClickListener(current == null ? null : v -> nowPlaying());
    miniState.setText(
        status.isEmpty()
            ? current == null ? "" : time(position()) + " / " + time(duration())
            : status);
    if (miniPlayIcon != null) {
      miniPlayIcon.kind(loading ? "more" : playing() ? "pause" : "play");
      miniPlayIcon.setContentDescription(playing() ? "Пауза" : "Играть");
    }
    if (nowPlayIcon != null) nowPlayIcon.kind(playing() ? "pause" : "play");
    if (nowStatus != null) {
      nowStatus.setText(status);
      nowStatus.setVisibility(status.isEmpty() ? View.GONE : View.VISIBLE);
    }
    if (waveHero != null) waveHero.transport(playing());
  }

  void nowPlaying() {
    if (current == null) return;
    startPage("now");
    nowView = new NowPlayingView(this);
    surface(nowView);
    refreshMini();
  }

  static String time(long ms) {
    long s = Math.max(0, ms / 1000);
    return (s / 60) + ":" + String.format(Locale.ROOT, "%02d", s % 60);
  }

  void restore() {
    queue = store.tracks("queue");
    index = store.object("session").optInt("index", -1);
    resumePosition = store.object("session").optLong("position");
    if (index >= 0 && index < queue.size()) current = queue.get(index);
  }

  void saveSession() {
    if (player != null && player.getMediaItemCount() > 0) {
      syncPlayer();
      try {
        store.put(
            "session", new JSONObject().put("index", index).put("position", position()).toString());
      } catch (Exception ignored) {
      }
      return;
    }
    store.tracks("queue", queue);
    try {
      store.put(
          "session",
          new JSONObject().put("index", index).put("position", resumePosition).toString());
    } catch (Exception ignored) {
    }
  }

  final Runnable tick =
      new Runnable() {
        public void run() {
          if (isFinishing()) return;
          if (nowSeek != null && !seeking && duration() > 0)
            nowSeek.setProgress((int) Math.min(10000, position() * 10000 / duration()));
          if (nowTime != null) nowTime.setText(time(position()) + " / " + time(duration()));
          if (System.currentTimeMillis() - lastSave > 5000) {
            saveSession();
            lastSave = System.currentTimeMillis();
          }
          if (foreground) refreshMini();
          ui.postDelayed(this, 500);
        }
      };

  void wave(Track seed) {
    startPage("wave");
    LinearLayout body = column();
    header(body, seed == null ? "Твоя волна" : "Волна по треку", this::home);
    WaveHero hero = new WaveHero(this, seed, () -> toggle(), this::waveSettings);
    waveHero = hero;
    body.addView(hero);
    space(body, 20);
    TextView state = text("Создаём новую очередь…", 14, MUTED, false);
    space(body, 16);
    body.addView(state);
    surface(scroll(body));
    int generation = viewGeneration;
    Set<String> previous = new HashSet<>();
    for (Track t : queue) previous.add(t.id);
    workers.execute(
        () -> {
          try {
            List<Track> rows = catalog.related(seed);
            String mode = store.get("waveMode", "balanced");
            if (store.get("waveClean", "false").equals("true"))
              rows.removeIf(t -> !Matching.tags(t.title).isEmpty());
            if (store.get("waveRecent", "true").equals("true")) {
              Set<String> recent = new HashSet<>();
              for (Track t : history.subList(0, Math.min(history.size(), 50))) recent.add(t.id);
              rows.removeIf(t -> recent.contains(t.id));
            }
            if (mode.equals("familiar")) {
              Set<String> familiar = new HashSet<>();
              for (Track t : history) familiar.add(Matching.normalize(t.artist));
              rows.sort(
                  Comparator.comparing(t -> !familiar.contains(Matching.normalize(t.artist))));
            } else if (mode.equals("discover")) {
              Set<String> familiar = new HashSet<>();
              for (Track t : history) familiar.add(Matching.normalize(t.artist));
              rows.sort(Comparator.comparing(t -> familiar.contains(Matching.normalize(t.artist))));
            }
            rows.sort(Comparator.comparing(t -> previous.contains(t.id)));
            Feedback.filter(rows, store.tracks("dislikes"));
            ui.post(
                () -> {
                  if (generation != viewGeneration) return;
                  if (rows.isEmpty()) {
                    state.setText("Источник не вернул новые треки. Измени настройки волны.");
                    return;
                  }
                  if (seed != null) {
                    seeds.removeIf(t -> t.id.equals(seed.id));
                    seeds.add(0, seed);
                    if (seeds.size() > 3) seeds = new ArrayList<>(seeds.subList(0, 3));
                    store.tracks("seeds", seeds);
                  }
                  body.removeView(state);
                  space(body, 8);
                  hero.ready(rows.size());
                  body.addView(text("Дальше в волне", 20, TEXT, true));
                  space(body, 16);
                  showList(body, rows);
                  play(rows.get(0), rows);
                  store.put("queueRecommended", "true");
                });
          } catch (Exception e) {
            ui.post(
                () -> {
                  if (generation == viewGeneration)
                    state.setText("Не удалось собрать волну. Проверь сеть и попробуй снова.");
                });
          }
        });
  }

  void waveSettings() {
    startPage("settings");
    LinearLayout body = column();
    header(body, "Настройка волны", this::home);
    String[] titles = {"Баланс", "Больше открытий", "Знакомые исполнители"},
        values = {"balanced", "discover", "familiar"};
    String active = store.get("waveMode", "balanced");
    for (int i = 0; i < 3; i++) {
      String value = values[i];
      body.addView(
          button(
              (active.equals(value) ? "✓  " : "") + titles[i],
              () -> {
                store.put("waveMode", value);
                waveSettings();
              }));
      space(body, 10);
    }
    toggleSetting(body, "Без ремиксов и обработок", "waveClean", false);
    toggleSetting(body, "Без последних 50 прослушанных", "waveRecent", true);
    surface(scroll(body));
  }

  void toggleSetting(LinearLayout body, String label, String key, boolean fallback) {
    Switch s = new Switch(this);
    s.setText(label);
    s.setTextColor(TEXT);
    s.setTypeface(font);
    s.setTextSize(14);
    s.setPadding(dp(4), dp(14), dp(4), dp(14));
    s.setChecked(store.get(key, Boolean.toString(fallback)).equals("true"));
    s.setOnCheckedChangeListener((b, on) -> store.put(key, Boolean.toString(on)));
    body.addView(s);
  }

  void auth(boolean register) {
    authGeneration++;
    startPage("auth");
    registerMode = register;
    mini.setVisibility(View.GONE);
    nav.setVisibility(View.GONE);
    LinearLayout body = column();
    space(body, 14);
    body.addView(text("Музыка\nначинается с тебя.", 32, TEXT, true));
    space(body, 12);
    body.addView(text("Войди или создай профиль на этом телефоне", 14, MUTED, false));
    space(body, 24);
    LinearLayout tabs = row();
    tabs.addView(button(register ? "Вход" : "✓ Вход", () -> auth(false)), weighted());
    View gap = new View(this);
    tabs.addView(gap, new LinearLayout.LayoutParams(dp(10), 1));
    tabs.addView(button(register ? "✓ Регистрация" : "Регистрация", () -> auth(true)), weighted());
    body.addView(tabs);
    EditText
        name =
            input("Твоё имя", "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS),
        email =
            input(
                "Электронная почта",
                "",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS),
        password =
            input(
                "Пароль · от 6 символов",
                "",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
    if (register) field(body, "Имя", name);
    field(body, "Почта", email);
    field(body, "Пароль", password);
    space(body, 24);
    TextView error = text("", 13, 0xffe8a7ba, false);
    body.addView(error);
    body.addView(
        button(
            register ? "Создать профиль" : "Войти",
            () -> {
              String n = name.getText().toString(),
                  e = email.getText().toString(),
                  p = password.getText().toString();
              error.setText("Проверяем…");
              int generation = ++authGeneration;
              workers.execute(
                  () -> {
                    try {
                      JSONObject profile = register ? store.register(n, e, p) : store.login(e, p);
                      ui.post(
                          () -> {
                            if (generation != authGeneration) return;
                            password.setText("");
                            afterLogin(profile);
                          });
                    } catch (Exception ex) {
                      ui.post(
                          () -> {
                            if (generation == authGeneration) error.setText(ex.getMessage());
                          });
                    }
                  });
            }));
    space(body, 14);
    body.addView(button("Войти через Telegram", this::telegram));
    space(body, 18);
    body.addView(
        text(
            "Локальные профили и музыка хранятся на телефоне. Для Telegram ты подтверждаешь запрос"
                + " в нашем боте.",
            12,
            MUTED,
            false));
    surface(scroll(body));
  }

  void afterLogin(JSONObject p) {
    store.activate(p);
    favorites = store.tracks("favorites");
    ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
        .hideSoftInputFromWindow(content.getWindowToken(), 0);
    if (store.get("tour:" + p.optString("id"), "false").equals("true")) home();
    else tour(0);
  }

  void telegram() {
    int generation = ++authGeneration;
    toast("Готовим Telegram-вход…");
    workers.execute(
        () -> {
          try {
            JSONObject challenge =
                new JSONObject(
                    Catalog.request(
                        "https://pulse-help.ddemonovic65.workers.dev/challenge", new JSONObject()));
            String id = challenge.getString("id"),
                secret = challenge.getString("secret"),
                url = challenge.getString("url");
            if (!id.matches("[a-f0-9]{48}")
                || !url.equals("https://t.me/PulseMusicHelpBot?start=" + id))
              throw new IOException("Неожиданный ответ сервера");
            ui.post(
                () -> {
                  if (generation != authGeneration) return;
                  toast("Подтверди вход в боте и вернись в Pulse");
                  open(url);
                });
            long until = System.currentTimeMillis() + 300000;
            while (generation == authGeneration && System.currentTimeMillis() < until) {
              Thread.sleep(2000);
              JSONObject result =
                  new JSONObject(
                      Catalog.request(
                          "https://pulse-help.ddemonovic65.workers.dev/poll",
                          new JSONObject().put("id", id).put("secret", secret)));
              if (result.optBoolean("cancelled"))
                throw new IOException("Запрос отменён. Начни заново");
              JSONObject identity = result.optJSONObject("identity");
              if (identity != null) {
                JSONObject p =
                    new JSONObject()
                        .put("id", "telegram:" + identity.getString("provider_id"))
                        .put("provider", "telegram")
                        .put("name", identity.optString("name", "Слушатель"))
                        .put("provider_id", identity.getString("provider_id"));
                ui.post(
                    () -> {
                      if (generation == authGeneration) {
                        JSONObject previous =
                            store.object("telegram:" + identity.optString("provider_id"));
                        if (previous.length() > 0) store.activate(previous);
                        else store.activate(p);
                        try {
                          if (cloud != null && result.has("session"))
                            cloud.credentials(
                                identity.optString("provider_id"), result.getJSONObject("session"));
                        } catch (Exception e) {
                          toast("Вход выполнен, но синхронизация не сохранена. Войди повторно.");
                        }
                        afterLogin(store.object("profile"));
                      }
                    });
                return;
              }
            }
            if (generation == authGeneration)
              ui.post(() -> toast("Время входа истекло. Попробуй снова."));
          } catch (Exception e) {
            ui.post(
                () -> {
                  if (generation == authGeneration) toast("Telegram: " + e.getMessage());
                });
          }
        });
  }

  void tour(int step) {
    if (coach != null) coach.close();
    touring = true;
    coach = new CoachMarks(this);
    coach.step(step);
  }

  void profile() {
    history = store.tracks("history");
    startPage("profile");
    JSONObject p = store.object("profile");
    LinearLayout body = column();
    if (CloudSync.key(p).length() > 0) {
      body.addView(
          text(
              cloud == null || cloud.status.isEmpty()
                  ? "Лайки синхронизируются между телефоном и ПК"
                  : cloud.status,
              12,
              MUTED,
              false));
      body.addView(button("Обновить вход для синхронизации", this::telegram));
    }
    header(body, "Профиль", this::home);
    LinearLayout hero = row();
    ImageView avatar = art(null, 68);
    hero.addView(avatar, new LinearLayout.LayoutParams(dp(68), dp(68)));
    LinearLayout info = column();
    info.setPadding(dp(16), 0, 0, 0);
    info.addView(text(p.optString("name", "Слушатель"), 25, TEXT, true));
    space(info, 6);
    info.addView(
        text(
            p.optString("provider").equals("telegram")
                ? "Telegram · вход подтверждён"
                : "Локальный профиль",
            12,
            MUTED,
            false));
    hero.addView(info, weighted());
    body.addView(hero);
    space(body, 20);
    LinearLayout stats = row();
    stat(stats, "Прослушано", history.size());
    stat(stats, "Любимых", favorites.size());
    stat(stats, "Своих треков", library.size());
    body.addView(stats);
    EditText name = input("Имя", p.optString("name"), InputType.TYPE_CLASS_TEXT),
        bio =
            input(
                "О себе",
                p.optString("bio"),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
    bio.setSingleLine(false);
    bio.setMaxLines(4);
    field(body, "Имя", name);
    field(body, "Био", bio);
    space(body, 16);
    body.addView(
        button(
            "Сохранить",
            () -> {
              try {
                p.put("name", name.getText().toString().trim())
                    .put("bio", bio.getText().toString().trim());
                store.saveProfile(p);
                if (p.optString("provider").equals("telegram"))
                  store.put("telegram:" + p.optString("provider_id"), p.toString());
                toast("Профиль сохранён");
              } catch (Exception ignored) {
              }
            }));
    space(body, 24);
    body.addView(text("Источники музыки", 20, TEXT, true));
    space(body, 10);
    body.addView(
        text(
            "SoundCloud · открытый каталог\n"
                + "Audius · полные открытые записи\n"
                + "Свои файлы · с телефона",
            13,
            MUTED,
            false));
    yandexUi.section(body);
    space(body, 24);
    body.addView(text("Твоя музыка", 20, TEXT, true));
    space(body, 12);
    body.addView(button("Свои треки", this::pickMusic));
    space(body, 10);
    body.addView(button("Импорт SoundCloud", this::importSoundCloud));
    space(body, 10);
    body.addView(button("Оформление", this::appearance));
    space(body, 10);
    space(body, 24);
    space(body, 24);
    if (!history.isEmpty()) {
      body.addView(text("Недавно слушал", 20, TEXT, true));
      space(body, 12);
      for (Track t : history.subList(0, Math.min(5, history.size())))
        body.addView(trackRow(t, history));
    }
    space(body, 18);
    body.addView(
        button(
            "Выйти из профиля",
            () -> {
              authGeneration++;
              playGeneration++;
              stopAudio();
              yandexUi.cancel();
              yandexUi.music.session.clear();
              store.logout();
              current = null;
              queue.clear();
              index = -1;
              resumePosition = 0;
              saveSession();
              auth(false);
            }));
    space(body, 14);
    body.addView(text("Pulse Android · 0.1.0 alpha\nЛокальная тестовая сборка", 12, MUTED, false));
    surface(scroll(body));
  }

  void stat(LinearLayout row, String title, int count) {
    LinearLayout box = column();
    box.setBackground(glass(16));
    box.setPadding(dp(12), dp(16), dp(8), dp(16));
    box.addView(text(Integer.toString(count), 23, TEXT, true));
    space(box, 8);
    box.addView(text(title, 10, MUTED, false));
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
    lp.setMargins(dp(3), 0, dp(3), 0);
    row.addView(box, lp);
  }

  void appearance() {
    backgroundEditor.show();
  }

  interface IntAction {
    void accept(int value);
  }

  void slider(
      LinearLayout body,
      String label,
      String key,
      int min,
      int max,
      int fallback,
      IntAction change) {
    TextView title =
        text(label + " · " + store.get(key, Integer.toString(fallback)), 13, MUTED, false);
    space(body, 16);
    body.addView(title);
    SeekBar s = new SeekBar(this);
    s.setMax(max - min);
    s.setProgress(Integer.parseInt(store.get(key, Integer.toString(fallback))) - min);
    s.setProgressTintList(ColorStateList.valueOf(ACCENT));
    s.setThumbTintList(ColorStateList.valueOf(ACCENT));
    s.setOnSeekBarChangeListener(
        new SeekBar.OnSeekBarChangeListener() {
          public void onStartTrackingTouch(SeekBar b) {}

          public void onStopTrackingTouch(SeekBar b) {
            int v = b.getProgress() + min;
            store.put(key, Integer.toString(v));
            change.accept(v);
          }

          public void onProgressChanged(SeekBar b, int progress, boolean from) {
            title.setText(label + " · " + (progress + min));
          }
        });
    body.addView(s, new LinearLayout.LayoutParams(-1, dp(48)));
  }

  void applyBackground() {
    if (backgroundEditor == null || background == null) return;
    try {
      JSONObject cfg = backgroundEditor.config(foreground);
      boolean custom = cfg.getString("effect").equals("custom");
      customBackground.setVisibility(custom ? View.VISIBLE : View.GONE);
      if (custom) customBackground.refresh();
      boolean nativeEffect = cfg.getString("effect").equals("vortex");
      vortex.setVisibility(nativeEffect ? View.VISIBLE : View.GONE);
      background.setVisibility(nativeEffect || custom ? View.GONE : View.VISIBLE);
      JSONObject props = cfg.getJSONObject("props");
      vortex.configure(
          nativeEffect && foreground,
          !cfg.getBoolean("paused"),
          (float) props.optDouble("speed", .6),
          (float) props.optDouble("hue", 0),
          (float) props.optDouble("complexity", 5),
          (float) cfg.getDouble("intensity"));
      if (nativeEffect || custom) cfg.put("effect", "").put("paused", true);
      background.evaluateJavascript("window.setBackground&&setBackground(" + cfg + ")", null);
    } catch (Exception ignored) {
    }
  }

  void pickBackground() {
    Intent pick =
        new Intent(Intent.ACTION_OPEN_DOCUMENT)
            .setType("image/*")
            .addCategory(Intent.CATEGORY_OPENABLE)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    startActivityForResult(pick, 74);
  }

  void pickMusic() {
    Intent pick =
        new Intent(Intent.ACTION_OPEN_DOCUMENT)
            .setType("audio/*")
            .addCategory(Intent.CATEGORY_OPENABLE);
    pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
    pick.addFlags(
        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
    startActivityForResult(pick, 71);
  }

  @Override
  protected void onActivityResult(int request, int result, Intent data) {
    super.onActivityResult(request, result, data);
    if (request == 74 && result == RESULT_OK && data != null && data.getData() != null) {
      customBackground.importImage(data.getData());
      return;
    }
    if (request == 73 && result == RESULT_OK && data != null && data.getData() != null) {
      try (java.io.OutputStream out = getContentResolver().openOutputStream(data.getData())) {
        out.write(AudioTrace.read(this).getBytes("UTF-8"));
        toast("Диагностика сохранена");
      } catch (Exception e) {
        toast("Не удалось сохранить файл");
      }
      return;
    }
    if (request != 71 || result != RESULT_OK || data == null) return;
    List<Uri> uris = new ArrayList<>();
    if (data.getClipData() != null)
      for (int i = 0; i < data.getClipData().getItemCount(); i++)
        uris.add(data.getClipData().getItemAt(i).getUri());
    else if (data.getData() != null) uris.add(data.getData());
    for (Uri uri : uris)
      try {
        getContentResolver()
            .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
      } catch (Exception ignored) {
      }
    toast("Добавляем файлы…");
    workers.execute(
        () -> {
          List<Track> found = new ArrayList<>();
          for (Uri uri : uris) {
            Track t = new Track();
            t.id = "local:" + uri;
            t.source = "local";
            t.url = uri.toString();
            t.title = uri.getLastPathSegment();
            t.artist = "С телефона";
            try (MediaMetadataRetriever m = new MediaMetadataRetriever()) {
              m.setDataSource(this, uri);
              String title = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),
                  artist = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                  duration = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
              if (title != null) t.title = title;
              if (artist != null) t.artist = artist;
              if (duration != null) t.duration = Long.parseLong(duration);
            } catch (Exception ignored) {
            }
            found.add(t);
          }
          ui.post(
              () -> {
                for (Track t : found)
                  if (library.stream().noneMatch(x -> x.id.equals(t.id))) library.add(t);
                store.tracks("library", library);
                showCollection("Свои треки", library);
              });
        });
  }

  void importSoundCloud() {
    EditText link =
        input(
            "Имя профиля или ссылка SoundCloud",
            store.get("scImportProfile", ""),
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
    new AlertDialog.Builder(this)
        .setTitle("Импорт SoundCloud")
        .setMessage(
            "Введи имя профиля или ссылку на него. Pulse сам найдёт открытые лайки и добавит их в"
                + " любимое без повторов.")
        .setView(link)
        .setPositiveButton(
            "Импортировать",
            (d, w) -> {
              String url = link.getText().toString().trim();
              toast("Загружаем открытый список…");
              workers.execute(
                  () -> {
                    try {
                      List<Track> rows = Catalog.importLikes(url);
                      store.put("scImportProfile", url);
                      ui.post(
                          () -> {
                            int count = 0;
                            for (Track t : rows)
                              if (favorites.stream().noneMatch(x -> x.id.equals(t.id))) {
                                favorites.add(t);
                                count++;
                              }
                            store.tracks("favorites", favorites);
                            toast(
                                "Добавлено: "
                                    + count
                                    + ". Импортирована открытая страница; длинный список может быть"
                                    + " неполным.");
                            profile();
                          });
                    } catch (Exception e) {
                      ui.post(
                          () ->
                              toast(
                                  "Не удалось импортировать. Нужна публичная ссылка SoundCloud."));
                    }
                  });
            })
        .setNegativeButton("Отмена", null)
        .show();
  }

  void lyrics() {
    if (current == null) return;
    Track song = current;
    startPage("lyrics");
    LinearLayout body = column();
    header(body, "Текст песни", this::nowPlaying);
    body.addView(text(song.title, 23, TEXT, true));
    space(body, 8);
    body.addView(text(song.artist, 14, MUTED, false));
    space(body, 28);
    TextView state = text("Ищем текст…", 15, MUTED, false);
    body.addView(state);
    ScrollView scroll = scroll(body);
    surface(scroll);
    int generation = viewGeneration;
    workers.execute(
        () -> {
          try {
            JSONObject r =
                new JSONObject(
                    Catalog.request(
                        "https://lrclib.net/api/get?artist_name="
                            + Catalog.enc(song.artist)
                            + "&track_name="
                            + Catalog.enc(song.title)
                            + "&duration="
                            + song.duration / 1000,
                        null));
            String synced = r.optString("syncedLyrics", ""), plain = r.optString("plainLyrics", "");
            ui.post(
                () -> {
                  if (generation != viewGeneration) return;
                  body.removeView(state);
                  if (synced.isEmpty() || synced.equals("null")) {
                    body.addView(
                        text(
                            plain.isEmpty() || plain.equals("null")
                                ? "Текст пока недоступен"
                                : plain,
                            21,
                            TEXT,
                            true));
                    return;
                  }
                  List<Long> times = new ArrayList<>();
                  List<TextView> lines = new ArrayList<>();
                  java.util.regex.Pattern pattern =
                      java.util.regex.Pattern.compile("\\[(\\d+):(\\d+(?:\\.\\d+)?)\\](.*)");
                  for (String line : synced.split("\n")) {
                    java.util.regex.Matcher m = pattern.matcher(line);
                    if (m.find()) {
                      times.add(
                          Long.parseLong(m.group(1)) * 60000
                              + (long) (Double.parseDouble(m.group(2)) * 1000));
                      TextView t = text(m.group(3).trim(), 23, MUTED, true);
                      t.setPadding(0, dp(12), 0, dp(12));
                      lines.add(t);
                      body.addView(t);
                      final long at = times.get(times.size() - 1);
                      tap(t, () -> seek(at));
                    }
                  }
                  ui.post(
                      new Runnable() {
                        int active = -1;

                        public void run() {
                          if (generation != viewGeneration) return;
                          int selected = -1;
                          for (int i = 0; i < times.size(); i++)
                            if (position() >= times.get(i)) selected = i;
                          if (selected != active) {
                            active = selected;
                            for (int i = 0; i < lines.size(); i++) {
                              TextView line = lines.get(i);
                              line.setTextColor(i == active ? TEXT : MUTED);
                              line.animate().alpha(i == active ? 1 : .55f).setDuration(250).start();
                            }
                            if (active >= 0)
                              scroll.smoothScrollTo(
                                  0, Math.max(0, lines.get(active).getTop() - dp(190)));
                          }
                          ui.postDelayed(this, 400);
                        }
                      });
                });
          } catch (Exception e) {
            ui.post(
                () -> {
                  if (generation == viewGeneration)
                    state.setText("Текст не найден для этой версии записи");
                });
          }
        });
  }

  void open(String url) {
    try {
      startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    } catch (Exception e) {
      toast("Не найдено приложение для этой ссылки");
    }
  }

  void toast(String message) {
    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
  }

  @Override
  public void onBackPressed() {
    if (trackSheet != null && trackSheet.isShowing()) {
      trackSheet.dismiss();
      return;
    }
    if (touring || (updates != null && updates.required)) return;
    if (page.equals("auth") || page.equals("tour")) {
      moveTaskToBack(true);
      return;
    }
    if (page.equals("home")) {
      moveTaskToBack(true);
      return;
    }
    home();
  }

  @Override
  protected void onResume() {
    super.onResume();
    foreground = true;
    if (yandexUi != null) yandexUi.resume();
    if (background != null) {
      background.onResume();
      applyBackground();
    }
  }

  @Override
  protected void onPause() {
    foreground = false;
    saveSession();
    if (background != null) {
      applyBackground();
      background.onPause();
    }
    super.onPause();
  }

  @Override
  protected void onDestroy() {
    saveSession();
    ui.removeCallbacksAndMessages(null);
    yandexUi.close();
    if (coach != null) coach.close();
    if (trackSheet != null) trackSheet.dismiss();
    if (updates != null) updates.close();
    if (cloud != null) cloud.close();
    authGeneration++;
    playGeneration++;
    if (controllerFuture != null) MediaController.releaseFuture(controllerFuture);
    if (vortex != null) vortex.shutdown();
    if (background != null) background.destroy();
    workers.shutdownNow();
    super.onDestroy();
  }
}
