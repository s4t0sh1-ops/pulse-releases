package fun.pulse.music;

import static org.junit.Assert.*;

import java.util.*;
import org.json.*;
import org.junit.Test;

public class CloudStateTest {
  Track track(String id) throws Exception {
    return Track.from(
        new JSONObject()
            .put("id", id)
            .put("source", "soundcloud")
            .put("title", "Song")
            .put("artist", "Artist"));
  }

  JSONObject reply(JSONArray ack, boolean liked, long cursor, Track t) throws Exception {
    return new JSONObject()
        .put("ack", ack)
        .put("cursor", cursor)
        .put(
            "events",
            new JSONArray()
                .put(
                    new JSONObject()
                        .put("track", t.json())
                        .put("liked", liked)
                        .put("revision", cursor)));
  }

  @Test
  public void offlineEditsAndRestart() throws Exception {
    Track t = track("sc:1");
    CloudState s = new CloudState(new JSONObject());
    s.reconcile(List.of(t));
    JSONObject sent = s.request();
    String first = sent.getJSONArray("ops").getJSONObject(0).getString("op");
    s = new CloudState(new JSONObject(s.state.toString()));
    assertEquals(first, s.request().getJSONArray("ops").getJSONObject(0).getString("op"));
    List<Track> rows = s.apply(reply(new JSONArray().put(first), true, 1, t), List.of());
    assertTrue(rows.isEmpty());
    assertFalse(s.request().getJSONArray("ops").getJSONObject(0).getBoolean("liked"));
    assertNotEquals(first, s.request().getJSONArray("ops").getJSONObject(0).getString("op"));
  }

  @Test
  public void remoteEditsNotEchoedAndLocalFilesStay() throws Exception {
    CloudState s = new CloudState(new JSONObject());
    Track t = track("sc:2"), local = track("file");
    local.source = "local";
    List<Track> rows = s.apply(reply(new JSONArray(), true, 3, t), List.of(local));
    assertEquals(2, rows.size());
    s.reconcile(rows);
    assertEquals(0, s.request().getJSONArray("ops").length());
    rows = s.apply(reply(new JSONArray(), false, 4, t), rows);
    assertEquals(1, rows.size());
    assertEquals("file", rows.get(0).id);
  }

  @Test
  public void batchesAreBounded() throws Exception {
    CloudState s = new CloudState(new JSONObject());
    List<Track> rows = new ArrayList<>();
    for (int i = 0; i < 120; i++) rows.add(track("sc:" + i));
    s.reconcile(rows);
    assertEquals(100, s.request().getJSONArray("ops").length());
  }
}
