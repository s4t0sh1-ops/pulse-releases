package fun.pulse.music;

import static org.junit.Assert.*;

import org.json.*;
import org.junit.Test;

public class YandexDeviceFlowTest {
  JSONObject challenge() throws Exception {
    return new JSONObject()
        .put("device_code", "test-device")
        .put("user_code", "ABCD")
        .put("interval", 5)
        .put("expires_in", 300)
        .put("verification_url", "https://oauth.yandex.ru/device");
  }

  static class Api implements YandexDeviceFlow.Backend {
    int polls, accounts;
    boolean accountOffline;
    String error = "authorization_pending";

    public JSONObject challenge() {
      return null;
    }

    public JSONObject poll(String device) throws Exception {
      polls++;
      return error.isEmpty()
          ? new JSONObject().put("access_token", "test-token")
          : new JSONObject().put("error", error);
    }

    public JSONObject account(String token) throws Exception {
      accounts++;
      if (accountOffline) throw new java.io.IOException("offline");
      return new JSONObject().put("uid", "42");
    }
  }

  @Test
  public void pollingRespectsIntervalAndSlowDown() throws Exception {
    JSONObject p = YandexDeviceFlow.begin(challenge(), "profile", 1000);
    Api api = new Api();
    YandexDeviceFlow.step(p, 2000, api, s -> {});
    assertEquals(0, api.polls);
    YandexDeviceFlow.step(p, 6000, api, s -> {});
    assertEquals(1, api.polls);
    assertEquals(11000, p.getLong("next"));
    api.error = "slow_down";
    YandexDeviceFlow.step(p, 11000, api, s -> {});
    assertEquals(10, p.getInt("interval"));
    assertEquals(21000, p.getLong("next"));
  }

  @Test
  public void tokenSurvivesAccountNetworkFailureAndProcessRecreation() throws Exception {
    JSONObject p = YandexDeviceFlow.begin(challenge(), "profile", 1000);
    Api api = new Api();
    api.error = "";
    api.accountOffline = true;
    final String[] saved = {""};
    try {
      YandexDeviceFlow.step(p, 6000, api, s -> saved[0] = s.toString());
      fail();
    } catch (java.io.IOException expected) {
    }
    assertTrue(saved[0].contains("test-token"));
    assertEquals(1, api.polls);
    JSONObject restored = new JSONObject(saved[0]);
    api.accountOffline = false;
    JSONObject done = YandexDeviceFlow.step(restored, 11000, api, s -> {});
    assertEquals("42", done.getJSONObject("account").getString("uid"));
    assertEquals(1, api.polls);
    assertEquals(2, api.accounts);
  }

  @Test
  public void expiredOrDeniedCodesCannotBecomeConnected() throws Exception {
    JSONObject p = YandexDeviceFlow.begin(challenge(), "profile", 1000);
    Api api = new Api();
    assertTrue(YandexDeviceFlow.step(p, 400000, api, s -> {}).has("error"));
    assertEquals(0, api.polls);
    api.error = "access_denied";
    assertTrue(YandexDeviceFlow.step(p, 6000, api, s -> {}).has("error"));
    try {
      YandexDeviceFlow.begin(
          challenge().put("verification_url", "https://oauth.yandex.ru@other.example/device"),
          "profile",
          1000);
      fail();
    } catch (java.io.IOException expected) {
    }
  }
}
