package fun.pulse.music;

import static org.junit.Assert.*;

import org.json.*;
import org.junit.Test;

public class CoverArtTest {
  @Test
  public void missingTrackArtworkUsesRealAlbumOrValidSourceFallback() throws Exception {
    JSONObject track =
        new JSONObject()
            .put("coverUri", "")
            .put(
                "albums",
                new JSONArray()
                    .put(
                        new JSONObject().put("coverUri", "avatars.yandex.net/get-music/album/%%")));
    assertEquals("https://avatars.yandex.net/get-music/album/400x400", CoverArt.yandex(track));
    assertEquals(
        "https://i1.sndcdn.com/track-t500x500.jpg",
        CoverArt.soundcloud(
            new JSONObject().put("artwork_url", "https://i1.sndcdn.com/track-large.jpg"),
            new JSONObject()));
    assertEquals(
        "https://i1.sndcdn.com/avatar-t500x500.jpg",
        CoverArt.soundcloud(
            new JSONObject().put("artwork_url", ""),
            new JSONObject().put("avatar_url", "https://i1.sndcdn.com/avatar-large.jpg")));
    assertEquals(
        "https://example.org/cover.jpg",
        CoverArt.audius(
            new JSONObject().put("480x480", "").put("1000x1000", "https://example.org/cover.jpg")));
    assertEquals("", CoverArt.url("null"));
    assertEquals("", CoverArt.url("http://example.org/cover.jpg"));
    assertEquals("", CoverArt.url("https://secret@example.org/cover.jpg"));
  }

  @Test
  public void feedbackRejectsSameRecordingAcrossSourcesButKeepsRemix() {
    Track a = new Track(), b = new Track(), remix = new Track();
    a.id = "ya:1";
    b.id = "sc:2";
    remix.id = "sc:3";
    a.artist = b.artist = remix.artist = "Artist";
    a.title = b.title = "Title";
    remix.title = "Title Remix";
    java.util.List<Track> rows = new java.util.ArrayList<>(java.util.Arrays.asList(b, remix));
    Feedback.filter(rows, java.util.Arrays.asList(a));
    assertEquals(1, rows.size());
    assertSame(remix, rows.get(0));
  }
}
