package fun.pulse.music;

import static org.junit.Assert.*;

import android.content.Context;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public class YandexRecoveryTest {
  Context context;
  YandexSession session;
  YandexConnector connector;

  @Before
  public void setup() {
    context = RuntimeEnvironment.getApplication();
    context.getSharedPreferences("yandex-session", 0).edit().clear().commit();
    context.getSharedPreferences("pulse-v1", 0).edit().clear().commit();
    session =
        new YandexSession(context) {
          @Override
          javax.crypto.SecretKey key() {
            return new javax.crypto.spec.SecretKeySpec(new byte[32], "AES");
          }
        };
  }

  @After
  public void close() {
    if (connector != null) connector.worker.shutdownNow();
  }

  @Test
  public void encryptedPendingSignInResumesAfterActivityIsGone() throws Exception {
    new Store(context).activate(new JSONObject().put("id", "profile"));
    JSONObject state =
        YandexDeviceFlow.begin(
                new JSONObject().put("device_code", "device-secret").put("user_code", "ABCD"),
                "profile",
                System.currentTimeMillis())
            .put("next", 0);
    session.pending(state);
    assertFalse(
        context
            .getSharedPreferences("yandex-session", 0)
            .getString("pending", "")
            .contains("device-secret"));
    assertEquals("device-secret", session.pending().getString("device"));
    assertFalse(session.connected());
    YandexDeviceFlow.Backend api =
        new YandexDeviceFlow.Backend() {
          public JSONObject challenge() {
            throw new AssertionError("Must reuse pending grant");
          }

          public JSONObject poll(String device) throws Exception {
            return new JSONObject().put("access_token", "token-secret");
          }

          public JSONObject account(String token) throws Exception {
            return new JSONObject().put("uid", "42").put("displayName", "Listener");
          }
        };
    connector = new YandexConnector(context, session, api);
    YandexConnector.Listener listener = s -> {};
    connector.add(listener);
    connector.remove(listener);
    assertEquals("device-secret", session.pending().optString("device"));
    connector.resume();
    connector.worker.submit(() -> {}).get(3, java.util.concurrent.TimeUnit.SECONDS);
    assertTrue(connector.state.connected);
    assertTrue(session.connected());
    assertEquals("token-secret", session.token());
    assertEquals(0, session.pending().length());
    assertFalse(
        context
            .getSharedPreferences("yandex-session", 0)
            .getString("encrypted", "")
            .contains("token-secret"));
    context
        .getSharedPreferences("yandex-session", 0)
        .edit()
        .putString("encrypted", "corrupt")
        .commit();
    assertFalse(session.connected());
  }
}
