package fun.pulse.music;

import android.graphics.*;
import android.graphics.drawable.Drawable;

/** A quiet music placeholder, distinct from Pulse's app logo. */
final class CoverPlaceholder extends Drawable {
  final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
  final int color;

  CoverPlaceholder(Track track) {
    int hash = (track.artist + track.title).hashCode();
    float[] hsv = {Math.floorMod(hash, 360), .20f, .22f};
    color = Color.HSVToColor(hsv);
  }

  @Override
  public void draw(Canvas c) {
    Rect b = getBounds();
    float w = b.width(), h = b.height(), size = Math.min(w, h);
    c.save();
    c.translate(b.left, b.top);
    p.setShader(new LinearGradient(0, 0, w, h, color, 0xff111519, Shader.TileMode.CLAMP));
    c.drawRoundRect(0, 0, w, h, size * .07f, size * .07f, p);
    p.setShader(null);
    p.setColor(0xffbcb9cb);
    p.setStyle(Paint.Style.STROKE);
    p.setStrokeWidth(Math.max(1.5f, size * .012f));
    p.setStrokeCap(Paint.Cap.ROUND);
    float x = w * .47f, y = h * .59f, r = size * .065f;
    c.drawOval(x - r * 1.6f, y - r * .5f, x + r * .4f, y + r, p);
    c.drawLine(x + r * .4f, y + r * .2f, x + r * .4f, h * .32f, p);
    c.drawLine(x + r * .4f, h * .32f, w * .64f, h * .28f, p);
    c.drawLine(w * .64f, h * .28f, w * .64f, h * .41f, p);
    c.drawLine(x + r * .4f, h * .45f, w * .64f, h * .41f, p);
    c.restore();
  }

  public void setAlpha(int a) {
    p.setAlpha(a);
    invalidateSelf();
  }

  public void setColorFilter(ColorFilter f) {
    p.setColorFilter(f);
    invalidateSelf();
  }

  public int getOpacity() {
    return PixelFormat.OPAQUE;
  }
}
