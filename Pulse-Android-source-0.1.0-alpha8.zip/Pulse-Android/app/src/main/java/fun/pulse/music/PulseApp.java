package fun.pulse.music;

import android.app.Application;

public final class PulseApp extends Application {
  private YandexConnector yandex;

  synchronized YandexConnector yandex() {
    if (yandex == null) yandex = new YandexConnector(this);
    return yandex;
  }
}
