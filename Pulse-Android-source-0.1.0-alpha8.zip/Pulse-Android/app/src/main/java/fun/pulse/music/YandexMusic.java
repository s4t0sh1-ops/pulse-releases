package fun.pulse.music;

import android.content.Context;
import android.util.Xml;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import org.json.*;
import org.xmlpull.v1.XmlPullParser;

/** Personal-account adapter, matching the existing desktop device flow. No shared user account. */
class YandexMusic {
  // Public installed-application parameters used by yandex-music-api's device flow, not a user's
  // credentials.
  static final String CLIENT_ID = "23cabbbdc6cd418abb4b39c32c41195d",
      CLIENT_PARAMETER = "53bc75238f0c4d08a118e51fe9203300";
  final YandexSession session;

  YandexMusic(Context c) {
    session = new YandexSession(c);
  }

  static JSONObject form(String url, String token, Map<String, String> form) throws Exception {
    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
    c.setInstanceFollowRedirects(false);
    c.setConnectTimeout(7000);
    c.setReadTimeout(12000);
    c.setRequestProperty("User-Agent", "PulseAndroid/0.1");
    if (!token.isEmpty()) c.setRequestProperty("Authorization", "OAuth " + token);
    try {
      if (form != null) {
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        List<String> pairs = new ArrayList<>();
        for (Map.Entry<String, String> e : form.entrySet())
          pairs.add(Catalog.enc(e.getKey()) + "=" + Catalog.enc(e.getValue()));
        try (OutputStream out = c.getOutputStream()) {
          out.write(String.join("&", pairs).getBytes("UTF-8"));
        }
      }
      int status = c.getResponseCode();
      InputStream input = status / 100 == 2 ? c.getInputStream() : c.getErrorStream();
      if (input == null) throw new IOException("Яндекс ответил " + status);
      try (InputStream in = input;
          ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) {
          bytes.write(b, 0, n);
          if (bytes.size() > 16 * 1024 * 1024) throw new IOException("Ответ слишком большой");
        }
        JSONObject result = new JSONObject(bytes.toString("UTF-8"));
        if (status / 100 != 2 && !result.has("error"))
          throw new IOException("Яндекс ответил " + status);
        return result;
      }
    } finally {
      c.disconnect();
    }
  }

  static JSONObject challenge() throws Exception {
    JSONObject j =
        form(
            "https://oauth.yandex.ru/device/code",
            "",
            new LinkedHashMap<String, String>() {
              {
                put("client_id", CLIENT_ID);
                put("device_id", UUID.randomUUID().toString().replace("-", "").substring(0, 10));
                put("device_name", "Pulse Android");
              }
            });
    if (!j.has("device_code") || !j.has("user_code"))
      throw new IOException("Не удалось получить код Яндекса");
    return j;
  }

  static JSONObject poll(String device) throws Exception {
    return form(
        "https://oauth.yandex.ru/token",
        "",
        new LinkedHashMap<String, String>() {
          {
            put("grant_type", "device_code");
            put("code", device);
            put("client_id", CLIENT_ID);
            put("client_secret", CLIENT_PARAMETER);
          }
        });
  }

  JSONObject get(String path, Map<String, String> data) throws Exception {
    String token = session.token();
    if (token.isEmpty()) throw new IOException("Подключи свой Яндекс в профиле");
    JSONObject j = form("https://api.music.yandex.net" + path, token, data);
    if (j.has("error"))
      throw new IOException("Яндекс не разрешил запрос. Проверь подключение аккаунта.");
    return j;
  }

  static JSONObject account(String token) throws Exception {
    JSONObject j = form("https://api.music.yandex.net/account/status", token, null);
    JSONObject r = j.optJSONObject("result");
    if (r == null || r.optJSONObject("account") == null)
      throw new IOException("Не удалось подтвердить музыкальный аккаунт");
    return r.getJSONObject("account");
  }

  static Track row(JSONObject j) {
    Track t = new Track();
    t.id = "yandex:" + j.optString("id");
    t.source = "yandex";
    t.title = j.optString("title", "Без названия");
    String v = j.optString("version");
    if (!v.isEmpty()) t.title += " (" + v + ")";
    t.duration = j.optLong("durationMs");
    JSONArray artists = j.optJSONArray("artists");
    List<String> names = new ArrayList<>();
    for (int n = 0; artists != null && n < artists.length(); n++) {
      JSONObject a = artists.optJSONObject(n);
      if (a != null) {
        names.add(a.optString("name"));
        if (n == 0) t.artistId = a.optString("id");
      }
    }
    t.artist = String.join(", ", names);
    t.cover = CoverArt.yandex(j);
    return t;
  }

  interface Progress {
    void update(int loaded, int total);
  }

  List<Track> likes(java.util.function.BooleanSupplier cancelled, Progress progress)
      throws Exception {
    String uid = session.account().optString("uid");
    if (!uid.matches("[0-9]+")) throw new IOException("Подключи Яндекс заново");
    JSONObject result = get("/users/" + uid + "/likes/tracks", null).getJSONObject("result");
    JSONArray ids = result.getJSONObject("library").getJSONArray("tracks");
    List<Track> out = new ArrayList<>();
    for (int i = 0; i < ids.length(); i += 50) {
      if (cancelled.getAsBoolean()) throw new InterruptedException();
      List<String> batch = new ArrayList<>();
      for (int n = i; n < Math.min(i + 50, ids.length()); n++) {
        JSONObject item = ids.getJSONObject(n);
        batch.add(item.getString("id"));
      }
      Map<String, String> form = new HashMap<>();
      form.put("track-ids", String.join(",", batch));
      form.put("with-positions", "false");
      JSONArray tracks = get("/tracks", form).getJSONArray("result");
      for (int n = 0; n < tracks.length(); n++) out.add(row(tracks.getJSONObject(n)));
      progress.update(Math.min(i + 50, ids.length()), ids.length());
    }
    return out;
  }

  Track stream(Track original) throws Exception {
    String id = original.id.replaceFirst("^yandex:", "");
    if (!id.matches("[0-9]+")) throw new IOException("Неизвестная запись Яндекса");
    Map<String, String> metadataRequest = new HashMap<>();
    metadataRequest.put("track-ids", id);
    JSONArray metadata = get("/tracks", metadataRequest).getJSONArray("result");
    if (metadata.length() == 0 || !metadata.getJSONObject(0).optBoolean("available"))
      throw new IOException("Полная запись недоступна твоему аккаунту Яндекса");
    JSONArray rows = get("/tracks/" + id + "/download-info", null).getJSONArray("result");
    JSONObject best = null;
    for (int i = 0; i < rows.length(); i++) {
      JSONObject r = rows.getJSONObject(i);
      if (r.optString("codec").equals("mp3")
          && !r.optBoolean("preview")
          && (best == null || r.optInt("bitrateInKbps") > best.optInt("bitrateInKbps"))) best = r;
    }
    if (best == null) throw new IOException("Полная запись недоступна твоему аккаунту Яндекса");
    URI uri = new URI(best.getString("downloadInfoUrl"));
    if (!"https".equals(uri.getScheme())
        || uri.getHost() == null
        || !uri.getHost().endsWith(".yandex.net"))
      throw new IOException("Неожиданный адрес Яндекса");
    String xml = Catalog.request(uri.toString(), null);
    String url = direct(xml);
    Track playable = Track.from(original.json());
    if (playable.cover.isEmpty()) playable.cover = CoverArt.yandex(metadata.getJSONObject(0));
    playable.url = url;
    return playable;
  }

  static String direct(String xml) throws Exception {
    String upper = xml.toUpperCase(Locale.ROOT);
    if (upper.contains("<!DOCTYPE") || upper.contains("<!ENTITY"))
      throw new IOException("Недопустимый XML записи");
    XmlPullParser parser = Xml.newPullParser();
    parser.setInput(new StringReader(xml));
    Map<String, String> values = new HashMap<>();
    for (int event = parser.getEventType();
        event != XmlPullParser.END_DOCUMENT;
        event = parser.next()) {
      if (event == XmlPullParser.START_TAG
          && Arrays.asList("host", "path", "ts", "s").contains(parser.getName()))
        values.put(parser.getName(), parser.nextText());
    }
    String host = values.getOrDefault("host", ""),
        path = values.getOrDefault("path", ""),
        ts = values.getOrDefault("ts", ""),
        s = values.getOrDefault("s", "");
    if (!host.matches("[a-zA-Z0-9.-]+")
        || !host.endsWith(".yandex.net")
        || !path.startsWith("/")
        || !ts.matches("[0-9a-fA-F]+")) throw new IOException("Некорректный адрес записи");
    byte[] digest =
        MessageDigest.getInstance("MD5")
            .digest(("XGRlBW9FXlekgbPrRHuSiA" + path.substring(1) + s).getBytes("UTF-8"));
    StringBuilder sign = new StringBuilder();
    for (byte b : digest) sign.append(String.format(Locale.ROOT, "%02x", b & 255));
    return "https://" + host + "/get-mp3/" + sign + "/" + ts + path;
  }
}
