package fun.pulse.music;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import java.security.*;
import java.util.*;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import org.json.*;

public final class Store {
  private final SharedPreferences prefs;

  public Store(Context c) {
    prefs = c.getSharedPreferences("pulse-v1", Context.MODE_PRIVATE);
    if (!prefs.contains("favorites-owner") && loggedIn())
      put("favorites-owner", object("profile").optString("id"));
  }

  public String get(String key, String fallback) {
    return prefs.getString(key, fallback);
  }

  public void put(String key, String value) {
    prefs.edit().putString(key, value).apply();
  }

  public JSONObject object(String key) {
    try {
      return new JSONObject(get(key, "{}"));
    } catch (Exception e) {
      return new JSONObject();
    }
  }

  public List<Track> tracks(String key) {
    try {
      return Track.list(new JSONArray(get(key, "[]")));
    } catch (Exception e) {
      return new ArrayList<>();
    }
  }

  public void tracks(String key, List<Track> rows) {
    put(key, Track.array(rows).toString());
  }

  public boolean loggedIn() {
    return !object("profile").optString("id").isEmpty();
  }

  public void logout() {
    activate(new JSONObject());
  }

  public static String hash(char[] password, byte[] salt) throws Exception {
    PBEKeySpec spec = new PBEKeySpec(password, salt, 200000, 256);
    try {
      return Base64.encodeToString(
          SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(),
          Base64.NO_WRAP);
    } finally {
      spec.clearPassword();
      Arrays.fill(password, '\0');
    }
  }

  public JSONObject register(String name, String email, String password) throws Exception {
    email = email.trim().toLowerCase(Locale.ROOT);
    if (name.trim().isEmpty()
        || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
        || password.length() < 6) throw new Exception("Введи имя, почту и пароль от 6 символов");
    JSONObject profiles = object("profiles");
    if (profiles.has(email)) throw new Exception("Эта почта уже есть на телефоне. Выбери «Вход»");
    byte[] salt = new byte[24];
    new SecureRandom().nextBytes(salt);
    JSONObject p =
        new JSONObject()
            .put("id", UUID.randomUUID().toString())
            .put("name", name.trim())
            .put("email", email)
            .put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .put("hash", hash(password.toCharArray(), salt))
            .put("provider", "local");
    profiles.put(email, p);
    put("profiles", profiles.toString());
    return p;
  }

  public JSONObject login(String email, String password) throws Exception {
    JSONObject p = object("profiles").optJSONObject(email.trim().toLowerCase(Locale.ROOT));
    if (p == null) throw new Exception("Профиль не найден на этом телефоне");
    String actual =
        hash(password.toCharArray(), Base64.decode(p.getString("salt"), Base64.NO_WRAP));
    if (!MessageDigest.isEqual(
        actual.getBytes(java.nio.charset.StandardCharsets.UTF_8),
        p.getString("hash").getBytes(java.nio.charset.StandardCharsets.UTF_8)))
      throw new Exception("Неверный пароль");
    return p;
  }

  public void activate(JSONObject profile) {
    try {
      JSONObject old = object("profile");
      if (old.optString("provider").equals("telegram")) {
        String key = "cloud-state:" + old.optString("provider_id");
        CloudState state = new CloudState(object(key));
        state.reconcile(tracks("favorites"));
        put(key, state.state.toString());
      }
    } catch (Exception ignored) {
    }
    String next = profile.optString("id"),
        previous = get("favorites-owner", object("profile").optString("id"));
    if (!previous.equals(next)) {
      if (!previous.isEmpty()) put("favorites-account:" + previous, get("favorites", "[]"));
      // Adopt legacy favourites only once, for the first active account.
      if (prefs.contains("favorites-owner"))
        put("favorites", next.isEmpty() ? "[]" : get("favorites-account:" + next, "[]"));
    }
    put("favorites-owner", next);
    put("profile", profile.toString());
  }

  public void saveProfile(JSONObject p) {
    activate(p);
    if (p.optString("provider").equals("local")) {
      JSONObject all = object("profiles");
      try {
        all.put(p.getString("email"), p);
        put("profiles", all.toString());
      } catch (Exception ignored) {
      }
    }
  }
}
