package fun.pulse.music;

import android.content.Context;
import android.security.keystore.*;
import android.util.Base64;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONObject;

/** Personal service credentials are encrypted with a non-exportable Android Keystore key. */
class YandexSession {
  final Context context;
  static final String ALIAS = "pulse-yandex-session-v1";

  YandexSession(Context c) {
    context = c.getApplicationContext();
  }

  javax.crypto.SecretKey key() throws Exception {
    KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
    ks.load(null);
    if (!ks.containsAlias(ALIAS)) {
      KeyGenerator generator = KeyGenerator.getInstance("AES", "AndroidKeyStore");
      generator.init(
          new KeyGenParameterSpec.Builder(
                  ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
              .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
              .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
              .build());
      generator.generateKey();
    }
    return (javax.crypto.SecretKey) ks.getKey(ALIAS, null);
  }

  void save(String token, JSONObject account) throws Exception {
    if (token.isEmpty() || account.optString("uid").isEmpty())
      throw new java.io.IOException("Не удалось подтвердить аккаунт Яндекса");
    String encrypted = encrypt(token);
    boolean saved =
        context
            .getSharedPreferences("yandex-session", 0)
            .edit()
            .putString("encrypted", encrypted)
            .putString("account", account.toString())
            .commit();
    if (!saved || !token.equals(token()))
      throw new java.io.IOException("Не удалось сохранить подключение Яндекса");
  }

  String encrypt(String value) throws Exception {
    Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
    cipher.init(Cipher.ENCRYPT_MODE, key());
    return new JSONObject()
        .put("iv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP))
        .put("data", Base64.encodeToString(cipher.doFinal(value.getBytes("UTF-8")), Base64.NO_WRAP))
        .toString();
  }

  String decrypt(String raw) throws Exception {
    if (raw.isEmpty()) return "";
    JSONObject j = new JSONObject(raw);
    Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
    c.init(
        Cipher.DECRYPT_MODE,
        key(),
        new GCMParameterSpec(128, Base64.decode(j.getString("iv"), Base64.NO_WRAP)));
    return new String(c.doFinal(Base64.decode(j.getString("data"), Base64.NO_WRAP)), "UTF-8");
  }

  String token() {
    try {
      String raw = context.getSharedPreferences("yandex-session", 0).getString("encrypted", "");
      return decrypt(raw);
    } catch (Exception e) {
      return "";
    }
  }

  JSONObject account() {
    try {
      return new JSONObject(
          context.getSharedPreferences("yandex-session", 0).getString("account", "{}"));
    } catch (Exception e) {
      return new JSONObject();
    }
  }

  boolean connected() {
    return !account().optString("uid").isEmpty() && !token().isEmpty();
  }

  JSONObject pending() {
    try {
      String raw =
          decrypt(context.getSharedPreferences("yandex-session", 0).getString("pending", ""));
      return raw.isEmpty() ? new JSONObject() : new JSONObject(raw);
    } catch (Exception e) {
      return new JSONObject();
    }
  }

  void pending(JSONObject value) throws Exception {
    if (!context
        .getSharedPreferences("yandex-session", 0)
        .edit()
        .putString("pending", encrypt(value.toString()))
        .commit()) throw new java.io.IOException("Не удалось сохранить ожидание входа");
  }

  void clearPending() {
    context.getSharedPreferences("yandex-session", 0).edit().remove("pending").commit();
  }

  void clear() {
    context.getSharedPreferences("yandex-session", 0).edit().clear().commit();
  }
}
