package fun.pulse.music;

import android.content.Context;
import android.os.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.*;

/** Application-owned sign-in: leaving or recreating an Activity does not cancel it. */
final class YandexConnector {
  interface Listener {
    void changed(State state);
  }

  static final class State {
    final String code, target, message;
    final boolean busy, connected;

    State(String code, String target, String message, boolean busy, boolean connected) {
      this.code = code;
      this.target = target;
      this.message = message;
      this.busy = busy;
      this.connected = connected;
    }
  }

  final YandexSession session;
  final Store profiles;
  final Handler ui = new Handler(Looper.getMainLooper());
  final ScheduledExecutorService worker =
      Executors.newSingleThreadScheduledExecutor(
          r -> {
            Thread t = new Thread(r, "Pulse Yandex sign-in");
            t.setDaemon(true);
            return t;
          });
  final java.util.Set<Listener> listeners = new CopyOnWriteArraySet<>();
  final AtomicInteger generation = new AtomicInteger();
  final YandexDeviceFlow.Backend api;

  static YandexDeviceFlow.Backend backend() {
    return new YandexDeviceFlow.Backend() {
      public JSONObject challenge() throws Exception {
        return YandexMusic.challenge();
      }

      public JSONObject poll(String device) throws Exception {
        return YandexMusic.poll(device);
      }

      public JSONObject account(String token) throws Exception {
        return YandexMusic.account(token);
      }
    };
  }

  volatile State state = new State("", "", "", false, false);
  ScheduledFuture<?> pendingTick;

  YandexConnector(Context context) {
    this(context, new YandexSession(context), backend());
  }

  YandexConnector(Context context, YandexSession session, YandexDeviceFlow.Backend api) {
    this.session = session;
    this.api = api;
    profiles = new Store(context);
  }

  void add(Listener listener) {
    listeners.add(listener);
    ui.post(
        () -> {
          if (listeners.contains(listener)) listener.changed(state);
        });
  }

  void remove(Listener listener) {
    listeners.remove(listener);
  }

  void emit(State value) {
    state = value;
    ui.post(
        () -> {
          for (Listener l : listeners) l.changed(value);
        });
  }

  void start() {
    int request = generation.incrementAndGet();
    emit(new State("", "", "Получаем код Яндекса…", true, false));
    worker.execute(
        () -> {
          stopTimer();
          session.clearPending();
          try {
            JSONObject challenge = api.challenge();
            if (request != generation.get()) return;
            JSONObject p =
                YandexDeviceFlow.begin(
                    challenge,
                    profiles.object("profile").optString("id"),
                    System.currentTimeMillis());
            session.pending(p);
            waiting(p, "Введи код на странице Яндекса, затем вернись в Pulse.");
            schedule(request, p);
          } catch (Exception e) {
            if (request == generation.get())
              emit(
                  new State(
                      "",
                      "",
                      "Не удалось получить код. Проверь сеть и попробуй снова.",
                      false,
                      false));
          }
        });
  }

  void resume() {
    worker.execute(() -> tick(generation.get()));
  }

  void cancel() {
    int request = generation.incrementAndGet();
    worker.execute(
        () -> {
          if (request != generation.get()) return;
          stopTimer();
          session.clearPending();
          emit(new State("", "", "", false, session.connected()));
        });
  }

  void stopTimer() {
    if (pendingTick != null) pendingTick.cancel(false);
    pendingTick = null;
  }

  void waiting(JSONObject p, String message) {
    emit(new State(p.optString("code"), p.optString("target"), message, true, false));
  }

  void schedule(int request, JSONObject p) {
    stopTimer();
    long delay = Math.max(500, p.optLong("next") - System.currentTimeMillis());
    pendingTick = worker.schedule(() -> tick(request), delay, TimeUnit.MILLISECONDS);
  }

  void tick(int request) {
    if (request != generation.get()) return;
    JSONObject p = session.pending();
    if (p.length() == 0) {
      emit(new State("", "", "", false, session.connected()));
      return;
    }
    if (!profiles.loggedIn()
        || !p.optString("profile").equals(profiles.object("profile").optString("id"))) {
      session.clearPending();
      emit(new State("", "", "Вход отменён после выхода из профиля.", false, false));
      return;
    }
    try {
      JSONObject answer =
          YandexDeviceFlow.step(
              p,
              System.currentTimeMillis(),
              api,
              s -> {
                if (request == generation.get()) session.pending(s);
              });
      if (request != generation.get()) return;
      if (answer.has("error")) {
        stopTimer();
        session.clearPending();
        emit(new State("", "", answer.optString("error"), false, false));
        return;
      }
      if (answer.has("token")) {
        session.save(answer.getString("token"), answer.getJSONObject("account"));
        session.clearPending();
        stopTimer();
        emit(new State("", "", "Яндекс Музыка подключена", false, true));
        return;
      }
      waiting(p, "Ожидаем подтверждение Яндекса. После ввода кода вернись в Pulse.");
      schedule(request, p);
    } catch (Exception e) {
      if (request != generation.get()) return;
      try {
        p.put("next", System.currentTimeMillis() + Math.max(5, p.optInt("interval", 5)) * 1000L);
        session.pending(p);
      } catch (Exception ignored) {
      }
      waiting(p, "Не удалось связаться с Яндексом. Повторяем подключение…");
      schedule(request, p);
    }
  }
}
