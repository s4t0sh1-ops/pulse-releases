package fun.pulse.music;

import java.net.URI;
import java.util.*;
import org.json.*;

/** Resumable device grant. Checkpoint a received token before the account request. */
final class YandexDeviceFlow {
  interface Backend {
    JSONObject challenge() throws Exception;

    JSONObject poll(String device) throws Exception;

    JSONObject account(String token) throws Exception;
  }

  interface Checkpoint {
    void save(JSONObject state) throws Exception;
  }

  static JSONObject begin(JSONObject challenge, String profile, long now) throws Exception {
    String target =
        challenge.optString(
            "verification_uri", challenge.optString("verification_url", "https://ya.ru/device"));
    URI uri = new URI(target);
    if (!"https".equals(uri.getScheme())
        || uri.getUserInfo() != null
        || !Arrays.asList("ya.ru", "oauth.yandex.ru", "oauth.yandex.com", "passport.yandex.ru")
            .contains(uri.getHost()))
      throw new java.io.IOException("Неожиданный адрес входа Яндекса");
    String device = challenge.getString("device_code"), code = challenge.getString("user_code");
    if (device.isEmpty() || code.isEmpty())
      throw new java.io.IOException("Яндекс не выдал код входа");
    int interval = Math.max(1, Math.min(30, challenge.optInt("interval", 5)));
    return new JSONObject()
        .put("device", device)
        .put("code", code)
        .put("target", target)
        .put("profile", profile)
        .put("interval", interval)
        .put("next", now + interval * 1000L)
        .put(
            "deadline",
            now + Math.max(1, Math.min(600, challenge.optInt("expires_in", 300))) * 1000L);
  }

  static JSONObject step(JSONObject state, long now, Backend api, Checkpoint checkpoint)
      throws Exception {
    if (now >= state.optLong("deadline"))
      return new JSONObject().put("error", "Время входа истекло. Запроси новый код.");
    if (now < state.optLong("next")) return new JSONObject().put("waiting", true);
    int interval = state.optInt("interval", 5);
    state.put("next", now + interval * 1000L);
    String token = state.optString("token");
    if (token.isEmpty()) {
      JSONObject answer = api.poll(state.getString("device"));
      token = answer.optString("access_token");
      if (token.isEmpty()) {
        String error = answer.optString("error");
        if (error.equals("slow_down")) {
          state.put("interval", Math.min(60, interval + 5));
          state.put("next", now + state.getInt("interval") * 1000L);
        } else if (!error.equals("authorization_pending"))
          return new JSONObject()
              .put(
                  "error",
                  error.equals("access_denied")
                      ? "Вход отменён в Яндексе"
                      : "Яндекс не принял код. Запроси новый код.");
        checkpoint.save(state);
        return new JSONObject().put("waiting", true);
      }
      state.put("token", token).put("deadline", now + 600000);
      checkpoint.save(state);
    }
    JSONObject account = api.account(token);
    if (account.optString("uid").isEmpty())
      throw new java.io.IOException("Не удалось подтвердить музыкальный аккаунт");
    return new JSONObject().put("token", token).put("account", account);
  }
}
