package fun.pulse.music;

import android.content.res.ColorStateList;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;

/**
 * A fitted player. Artwork takes remaining height; transport and actions never sit below a scroll.
 */
final class NowPlayingView extends LinearLayout {
  final MainActivity a;
  final LinearLayout stage, details, controls;
  final SwipePlayer artBox;
  final ImageView cover;
  final TextView title, artist;
  String coverKey = "";
  boolean horizontal;

  NowPlayingView(MainActivity a) {
    super(a);
    this.a = a;
    setOrientation(VERTICAL);
    setPadding(a.dp(16), 0, a.dp(16), a.dp(8));
    LinearLayout header = a.row();
    a.addIcon(header, "back", "Назад", a::home);
    TextView label = a.text("Сейчас играет", 21, a.TEXT, true);
    label.setSingleLine(true);
    header.addView(label, new LinearLayout.LayoutParams(0, a.dp(44), 1));
    label.setGravity(Gravity.CENTER_VERTICAL);
    addView(header, new LinearLayout.LayoutParams(-1, a.dp(44)));
    stage = a.column();
    addView(stage, new LinearLayout.LayoutParams(-1, 0, 1));
    cover = a.art(a.current, 0);
    cover.setMinimumWidth(0);
    cover.setMinimumHeight(0);
    artBox =
        new SwipePlayer(a, a::advance) {
          @Override
          protected void onMeasure(int w, int h) {
            int width = MeasureSpec.getSize(w),
                height = MeasureSpec.getSize(h),
                size = Math.max(0, Math.min(width, height) - a.dp(8));
            android.view.ViewGroup.LayoutParams lp = cover.getLayoutParams();
            lp.width = size;
            lp.height = size;
            super.onMeasure(w, h);
          }
        };
    artBox.setGravity(Gravity.CENTER);
    artBox.setContentDescription("Обложка. Свайп влево — следующий трек, вправо — предыдущий");
    artBox.addView(cover, new LinearLayout.LayoutParams(0, 0));
    stage.addView(artBox, new LinearLayout.LayoutParams(-1, 0, 1));
    details = a.column();
    details.setGravity(Gravity.CENTER_HORIZONTAL);
    stage.addView(details, new LinearLayout.LayoutParams(-1, -2));
    title = a.text(a.current.title, 22, a.TEXT, true);
    title.setGravity(Gravity.CENTER);
    title.setMaxLines(2);
    title.setEllipsize(TextUtils.TruncateAt.END);
    details.addView(title, new LinearLayout.LayoutParams(-1, -2));
    artist = a.text(a.current.artist, 14, a.MUTED, false);
    artist.setGravity(Gravity.CENTER);
    artist.setMaxLines(1);
    artist.setHorizontallyScrolling(false);
    artist.setEllipsize(TextUtils.TruncateAt.END);
    artist.setPadding(0, a.dp(4), 0, a.dp(6));
    a.tap(artist, () -> a.artist(a.current));
    LinearLayout.LayoutParams artistParams = new LinearLayout.LayoutParams(-1, -2);
    details.addView(artist, artistParams);
    a.nowSeek = new SeekBar(a);
    a.nowSeek.setProgressTintList(ColorStateList.valueOf(a.ACCENT));
    a.nowSeek.setThumbTintList(ColorStateList.valueOf(a.ACCENT));
    a.nowSeek.setMax(10000);
    a.nowSeek.setContentDescription("Позиция в песне");
    details.addView(a.nowSeek, new LinearLayout.LayoutParams(-1, a.dp(32)));
    a.nowSeek.setOnSeekBarChangeListener(
        new SeekBar.OnSeekBarChangeListener() {
          public void onStartTrackingTouch(SeekBar s) {
            a.seeking = true;
          }

          public void onStopTrackingTouch(SeekBar s) {
            a.seek(a.duration() * s.getProgress() / 10000);
            a.seeking = false;
          }

          public void onProgressChanged(SeekBar s, int p, boolean from) {}
        });
    a.nowTime =
        a.text(
            MainActivity.time(a.position()) + " / " + MainActivity.time(a.duration()),
            11,
            a.MUTED,
            false);
    a.nowTime.setSingleLine(true);
    a.nowTime.setPadding(0, a.dp(2), 0, a.dp(4));
    details.addView(a.nowTime, new LinearLayout.LayoutParams(-1, -2));
    controls = a.row();
    controls.setGravity(Gravity.CENTER);
    a.nowLikeIcon = new Icons(a, "heart");
    a.nowLikeIcon.setOnClickListener(v -> a.toggleFavorite(a.current));
    controls.addView(a.nowLikeIcon);
    a.addIcon(controls, "prev", "Предыдущий трек", () -> a.advance(-1));
    a.nowPlayIcon = new Icons(a, "play");
    a.nowPlayIcon.setBackground(a.buttonBg());
    a.nowPlayIcon.setOnClickListener(v -> a.toggle());
    controls.addView(a.nowPlayIcon);
    a.addIcon(controls, "next", "Следующий трек", () -> a.advance(1));
    a.addIcon(controls, "queue", "Очередь", () -> a.showCollection("Очередь", a.queue));
    a.nowDislikeIcon = new Icons(a, "dislike");
    a.nowDislikeIcon.setOnClickListener(v -> a.toggleDislike(a.current));
    controls.addView(a.nowDislikeIcon);
    details.addView(controls, new LinearLayout.LayoutParams(-1, a.dp(64)));
    LinearLayout actions = a.row();
    actions.addView(a.button("Текст песни", a::lyrics), a.weighted());
    View gap = new View(a);
    actions.addView(gap, new LinearLayout.LayoutParams(a.dp(10), 1));
    actions.addView(a.button("Моя волна", () -> a.wave(a.current)), a.weighted());
    LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, a.dp(48));
    ap.topMargin = a.dp(10);
    details.addView(actions, ap);
    a.nowStatus = a.text(a.status, 11, a.MUTED, false);
    a.nowStatus.setMaxLines(2);
    a.nowStatus.setEllipsize(TextUtils.TruncateAt.END);
    details.addView(a.nowStatus, new LinearLayout.LayoutParams(-1, -2));
    bind(a.current);
  }

  void bind(Track t) {
    title.setText(t.title);
    title.setTooltipText(t.title);
    artist.setText(t.artist);
    String key = t.id + "|" + t.cover;
    if (!key.equals(coverKey)) {
      coverKey = key;
      a.artwork.bind(cover, t);
    }
    a.displayedNowId = t.id;
    a.nowLikeIcon.favorite(a.favorites.stream().anyMatch(x -> x.id.equals(t.id)), false);
    a.nowDislikeIcon.dislike(Feedback.disliked(t, a.dislikes), false);
    a.nowStatus.setVisibility(a.status.isEmpty() ? GONE : VISIBLE);
  }

  @Override
  protected void onMeasure(int w, int h) {
    int width = MeasureSpec.getSize(w) - getPaddingLeft() - getPaddingRight(),
        height = MeasureSpec.getSize(h);
    boolean landscape = width > height * 1.2f && width >= a.dp(560);
    if (horizontal != landscape) {
      horizontal = landscape;
      stage.setOrientation(horizontal ? HORIZONTAL : VERTICAL);
      artBox.setLayoutParams(
          new LinearLayout.LayoutParams(horizontal ? 0 : -1, horizontal ? -1 : 0, 1));
      details.setLayoutParams(
          new LinearLayout.LayoutParams(
              horizontal ? 0 : -1, horizontal ? -1 : -2, horizontal ? 1 : 0));
      details.setGravity(horizontal ? Gravity.CENTER : Gravity.CENTER_HORIZONTAL);
    }
    int controlWidth = horizontal ? width / 2 : width;
    int cell = Math.min(a.dp(48), Math.max(a.dp(30), (controlWidth - a.dp(60)) / 5));
    for (int i = 0; i < controls.getChildCount(); i++) {
      View v = controls.getChildAt(i);
      LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) v.getLayoutParams();
      lp.width = i == 2 ? a.dp(60) : cell;
      lp.height = i == 2 ? a.dp(60) : a.dp(48);
    }
    super.onMeasure(w, h);
  }
}
