package fun.pulse.music;

import java.util.*;
import org.json.*;

/** Durable per-account outbox. New local edits always win over an older in-flight reply. */
final class CloudState {
  JSONObject state;

  CloudState(JSONObject saved) {
    state = saved;
    try {
      if (!state.has("known")) state.put("known", new JSONObject());
      if (!state.has("pending")) state.put("pending", new JSONObject());
    } catch (JSONException e) {
      throw new IllegalStateException(e);
    }
  }

  static boolean shareable(Track t) {
    return t.source.equals("yandex") || t.source.equals("soundcloud") || t.source.equals("audius");
  }

  void reconcile(List<Track> favorites) throws JSONException {
    JSONObject known = state.getJSONObject("known"),
        next = new JSONObject(),
        pending = state.getJSONObject("pending");
    for (Track t : favorites)
      if (shareable(t)) {
        next.put(t.id, t.json());
        if (!known.has(t.id)) pending.put(t.id, operation(t.json(), true));
      }
    for (Iterator<String> it = known.keys(); it.hasNext(); ) {
      String id = it.next();
      if (!next.has(id)) pending.put(id, operation(known.getJSONObject(id), false));
    }
    state.put("known", next);
  }

  JSONObject operation(JSONObject track, boolean liked) throws JSONException {
    return new JSONObject()
        .put("op", UUID.randomUUID().toString())
        .put("liked", liked)
        .put("track", track);
  }

  JSONObject request() throws JSONException {
    JSONArray ops = new JSONArray();
    JSONObject pending = state.getJSONObject("pending");
    for (Iterator<String> it = pending.keys(); it.hasNext() && ops.length() < 100; ) {
      JSONObject op = pending.getJSONObject(it.next()),
          raw = op.getJSONObject("track"),
          clean = new JSONObject();
      for (String k :
          new String[] {"id", "source", "title", "artist", "artist_id", "genre", "duration"})
        clean.put(k, raw.opt(k));
      for (String k : new String[] {"url", "artist_url", "cover"}) {
        String value = raw.optString(k);
        try {
          java.net.URI u = new java.net.URI(value);
          if (!"https".equals(u.getScheme())
              || u.getRawUserInfo() != null
              || u.getRawQuery() != null
              || u.getRawFragment() != null) value = "";
        } catch (Exception e) {
          value = "";
        }
        clean.put(k, value);
      }
      ops.put(
          new JSONObject()
              .put("op", op.getString("op"))
              .put("liked", op.getBoolean("liked"))
              .put("track", clean));
    }
    return new JSONObject().put("cursor", state.optLong("cursor")).put("ops", ops);
  }

  List<Track> apply(JSONObject response, List<Track> favorites) throws JSONException {
    reconcile(favorites);
    JSONObject pending = state.getJSONObject("pending");
    Set<String> ack = new HashSet<>();
    JSONArray a = response.getJSONArray("ack");
    for (int i = 0; i < a.length(); i++) ack.add(a.getString(i));
    List<String> remove = new ArrayList<>();
    for (Iterator<String> it = pending.keys(); it.hasNext(); ) {
      String k = it.next();
      if (ack.contains(pending.getJSONObject(k).getString("op"))) remove.add(k);
    }
    for (String k : remove) pending.remove(k);
    LinkedHashMap<String, Track> rows = new LinkedHashMap<>();
    for (Track t : favorites) rows.put(t.id, t);
    JSONArray events = response.getJSONArray("events");
    for (int i = 0; i < events.length(); i++) {
      JSONObject event = events.getJSONObject(i);
      Track t = Track.from(event.getJSONObject("track"));
      if (!shareable(t) || pending.has(t.id)) continue;
      if (event.getBoolean("liked")) {
        if (!rows.containsKey(t.id)) {
          LinkedHashMap<String, Track> next = new LinkedHashMap<>();
          next.put(t.id, t);
          next.putAll(rows);
          rows = next;
        } else rows.put(t.id, t);
      } else rows.remove(t.id);
    }
    JSONObject known = new JSONObject();
    for (Track t : rows.values()) if (shareable(t)) known.put(t.id, t.json());
    state.put("known", known).put("cursor", response.getLong("cursor"));
    return new ArrayList<>(rows.values());
  }
}
