package fun.pulse.music;

import android.content.Context;
import android.view.*;
import android.widget.*;
import java.util.function.IntConsumer;

/** Intercepts deliberate horizontal swipes; taps and vertical scrolling pass through. */
class SwipePlayer extends LinearLayout {
  final IntConsumer change;
  final float threshold;
  float downX, downY;
  boolean swiping;
  boolean transitioning;

  SwipePlayer(Context context, IntConsumer change) {
    super(context);
    setOrientation(VERTICAL);
    this.change = change;
    threshold = 48 * getResources().getDisplayMetrics().density;
  }

  @Override
  public boolean onInterceptTouchEvent(MotionEvent e) {
    if (transitioning) return true;
    if (e.getPointerCount() > 1) {
      swiping = false;
      return false;
    }
    if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
      downX = e.getX();
      downY = e.getY();
      swiping = false;
    } else if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
      float dx = e.getX() - downX, dy = e.getY() - downY;
      if (Math.abs(dx) > threshold && Math.abs(dx) > Math.abs(dy) * 1.6f) {
        swiping = true;
        getParent().requestDisallowInterceptTouchEvent(true);
        return true;
      }
    }
    return false;
  }

  @Override
  public boolean onTouchEvent(MotionEvent e) {
    if (transitioning) return true;
    if (!swiping) return super.onTouchEvent(e);
    if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
      float drag = Math.max(-threshold * .6f, Math.min(threshold * .6f, (e.getX() - downX) * .22f));
      for (int i = 0; i < getChildCount(); i++) {
        getChildAt(i).setTranslationX(drag);
        getChildAt(i).setAlpha(.92f);
      }
    }
    if (e.getActionMasked() == MotionEvent.ACTION_UP) {
      float dx = e.getX() - downX, dy = e.getY() - downY;
      if (Math.abs(dx) > threshold && Math.abs(dx) > Math.abs(dy) * 1.6f) {
        transition(dx < 0 ? 1 : -1);
      } else reset();
      swiping = false;
    } else if (e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
      swiping = false;
      reset();
    }
    return true;
  }

  void transition(int direction) {
    if (!MobileMotion.enabled()) {
      reset();
      change.accept(direction);
      return;
    }
    transitioning = true;
    for (int i = 0; i < getChildCount(); i++)
      getChildAt(i)
          .animate()
          .translationX(-direction * threshold * .65f)
          .alpha(0)
          .setDuration(90)
          .start();
    postDelayed(
        () -> {
          if (!isAttachedToWindow()) {
            reset();
            return;
          }
          change.accept(direction);
          for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            child.animate().cancel();
            child.setTranslationX(direction * threshold * .5f);
            child.setAlpha(0);
            child
                .animate()
                .translationX(0)
                .alpha(1)
                .setDuration(170)
                .setInterpolator(new android.view.animation.DecelerateInterpolator())
                .start();
          }
          postDelayed(() -> transitioning = false, 170);
        },
        90);
  }

  void reset() {
    transitioning = false;
    for (int i = 0; i < getChildCount(); i++) {
      View child = getChildAt(i);
      child.animate().cancel();
      child.setTranslationX(0);
      child.setAlpha(1);
    }
  }

  @Override
  protected void onDetachedFromWindow() {
    reset();
    super.onDetachedFromWindow();
  }
}
