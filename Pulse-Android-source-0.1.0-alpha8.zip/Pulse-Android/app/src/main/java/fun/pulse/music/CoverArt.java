package fun.pulse.music;

import java.net.URI;
import org.json.*;

/** Exact-source artwork only; never borrow a cover from a similarly named song. */
final class CoverArt {
  static String url(String raw) {
    if (raw == null) return "";
    raw = raw.trim();
    if (raw.isEmpty() || raw.equals("null") || raw.equals("undefined")) return "";
    if (raw.startsWith("//")) raw = "https:" + raw;
    if (!raw.contains("://") && raw.contains("yandex.net/")) raw = "https://" + raw;
    raw = raw.replace("%%", "400x400");
    try {
      URI u = new URI(raw);
      if (!"https".equals(u.getScheme()) || u.getHost() == null || u.getUserInfo() != null)
        return "";
      if (u.getHost().endsWith(".sndcdn.com")) raw = raw.replace("-large.", "-t500x500.");
      return raw;
    } catch (Exception e) {
      return "";
    }
  }

  static String first(String... values) {
    for (String value : values) {
      String result = url(value);
      if (!result.isEmpty()) return result;
    }
    return "";
  }

  static String yandex(JSONObject j) {
    String own = first(j.optString("coverUri"));
    if (!own.isEmpty()) return own;
    JSONArray albums = j.optJSONArray("albums");
    for (int i = 0; albums != null && i < albums.length(); i++) {
      JSONObject a = albums.optJSONObject(i);
      if (a != null) {
        String cover = first(a.optString("coverUri"));
        if (!cover.isEmpty()) return cover;
      }
    }
    return "";
  }

  static String audius(JSONObject art) {
    return art == null
        ? ""
        : first(art.optString("480x480"), art.optString("1000x1000"), art.optString("150x150"));
  }

  static String soundcloud(JSONObject track, JSONObject user) {
    return first(track.optString("artwork_url"), user == null ? "" : user.optString("avatar_url"));
  }
}
