package fun.pulse.music;

import android.os.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

final class CloudSync implements AutoCloseable {
  static final String BASE = "https://pulse-help.ddemonovic65.workers.dev";
  final MainActivity app;
  final Handler ui = new Handler(Looper.getMainLooper());
  final ExecutorService worker = Executors.newSingleThreadExecutor();
  String account = "", status = "", lastFavorites = "";
  CloudState state;
  boolean busy = false, closed = false;
  long next = 0;

  CloudSync(MainActivity a) {
    app = a;
    ui.post(tick);
  }

  static String key(JSONObject profile) {
    return profile.optString("provider").equals("telegram") ? profile.optString("provider_id") : "";
  }

  void credentials(String account, JSONObject session) throws Exception {
    app.store.put(
        "cloud-credential:" + account, new YandexSession(app).encrypt(session.getString("token")));
    next = 0;
  }

  final Runnable tick =
      new Runnable() {
        public void run() {
          if (closed) return;
          try {
            pump();
          } catch (Exception e) {
            status = "Не удалось сохранить синхронизацию";
          }
          ui.postDelayed(this, 2000);
        }
      };

  void pump() throws Exception {
    String active = key(app.store.object("profile"));
    if (!active.equals(account)) {
      account = active;
      state = active.isEmpty() ? null : new CloudState(app.store.object("cloud-state:" + active));
      next = 0;
      lastFavorites = "";
    }
    if (state == null) return;
    String raw = app.store.get("favorites", "[]");
    if (!raw.equals(lastFavorites)) {
      state.reconcile(app.store.tracks("favorites"));
      save();
      lastFavorites = raw;
    }
    if (busy || !app.foreground || System.currentTimeMillis() < next) return;
    String token;
    try {
      token = new YandexSession(app).decrypt(app.store.get("cloud-credential:" + account, ""));
    } catch (Exception e) {
      token = "";
    }
    if (token.isEmpty()) {
      status = "Войди через Telegram ещё раз для синхронизации";
      return;
    }
    final String owner = account, credential = token;
    final JSONObject request = state.request();
    busy = true;
    status = "Синхронизация…";
    worker.execute(
        () -> {
          JSONObject result = null;
          String error = "";
          try {
            result = exchange(credential, request);
          } catch (Exception e) {
            error = e.getMessage();
          }
          final JSONObject response = result;
          final String failure = error;
          ui.post(
              () -> {
                busy = false;
                if (closed || !owner.equals(key(app.store.object("profile")))) return;
                try {
                  if (response == null) {
                    status =
                        "auth".equals(failure)
                            ? "Войди через Telegram ещё раз для синхронизации"
                            : "Нет связи. Лайки сохранены на телефоне";
                    next = System.currentTimeMillis() + 15000;
                    return;
                  }
                  if (response.getJSONArray("ack").length() == 0
                      && response.getJSONArray("events").length() == 0) {
                    status = "Лайки синхронизированы";
                    next = System.currentTimeMillis() + 10000;
                    return;
                  }
                  List<Track> rows = state.apply(response, app.store.tracks("favorites"));
                  boolean changed =
                      !Track.array(rows).toString().equals(Track.array(app.favorites).toString());
                  app.store.tracks("favorites", rows);
                  app.favorites = rows;
                  lastFavorites = app.store.get("favorites", "[]");
                  save();
                  status = "Лайки синхронизированы";
                  next =
                      System.currentTimeMillis()
                          + (response.optBoolean("more")
                                  || state.state.getJSONObject("pending").length() > 0
                              ? 0
                              : 10000);
                  if (changed) {
                    if (app.nowLikeIcon != null && app.current != null)
                      app.nowLikeIcon.favorite(
                          app.favorites.stream().anyMatch(t -> t.id.equals(app.current.id)), false);
                    if (app.page.equals("collection")) app.showCollection("Любимые треки", rows);
                  }
                } catch (Exception e) {
                  status = "Повторим синхронизацию";
                  next = System.currentTimeMillis() + 15000;
                }
              });
        });
  }

  void save() {
    app.store.put("cloud-state:" + account, state.state.toString());
  }

  static JSONObject exchange(String token, JSONObject body) throws Exception {
    HttpURLConnection c = (HttpURLConnection) new URL(BASE + "/sync").openConnection();
    c.setInstanceFollowRedirects(false);
    c.setConnectTimeout(8000);
    c.setReadTimeout(15000);
    c.setRequestMethod("POST");
    c.setDoOutput(true);
    c.setRequestProperty("Content-Type", "application/json");
    c.setRequestProperty("Authorization", "Bearer " + token);
    try {
      try (OutputStream out = c.getOutputStream()) {
        out.write(body.toString().getBytes(StandardCharsets.UTF_8));
      }
      if (c.getResponseCode() == 401) throw new IOException("auth");
      if (c.getResponseCode() != 200) throw new IOException("offline");
      try (InputStream in = c.getInputStream()) {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] chunk = new byte[8192];
        int count;
        while ((count = in.read(chunk)) != -1) {
          buffer.write(chunk, 0, count);
          if (buffer.size() > 2 * 1024 * 1024) throw new IOException("size");
        }
        byte[] bytes = buffer.toByteArray();
        return new JSONObject(new String(bytes, StandardCharsets.UTF_8));
      }
    } finally {
      c.disconnect();
    }
  }

  public void close() {
    try {
      if (state != null && account.equals(key(app.store.object("profile")))) {
        state.reconcile(app.store.tracks("favorites"));
        save();
      }
    } catch (Exception ignored) {
    }
    closed = true;
    ui.removeCallbacksAndMessages(null);
    worker.shutdownNow();
  }
}
