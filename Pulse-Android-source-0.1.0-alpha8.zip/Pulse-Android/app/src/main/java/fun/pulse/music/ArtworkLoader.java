package fun.pulse.music;

import android.graphics.*;
import android.widget.ImageView;
import java.io.*;
import java.lang.ref.WeakReference;
import java.net.*;
import java.util.*;
import org.json.*;

final class ArtworkLoader {
  final MainActivity a;
  final Set<String> metadataLoading = new HashSet<>();
  final Map<String, Long> failed = new HashMap<>();
  final Map<String, List<WeakReference<ImageView>>> metadataWaiters = new HashMap<>();

  ArtworkLoader(MainActivity a) {
    this.a = a;
  }

  void bind(ImageView image, Track track) {
    image.setImageDrawable(new CoverPlaceholder(track));
    image.setContentDescription("Обложка недоступна: " + track.title);
    String url = CoverArt.url(track.cover);
    if (url.isEmpty()) url = CoverArt.url(a.store.object("cover-cache-v1").optString(track.id));
    if (!url.isEmpty()) {
      track.cover = url;
      load(image, track, url);
    } else resolve(image, track);
  }

  void resolve(ImageView image, Track track) {
    String tag = "track:" + track.id;
    image.setTag(tag);
    if (track.id.isEmpty() || track.source.equals("local")) return;
    if (System.currentTimeMillis() - failed.getOrDefault(tag, 0L) < 30000) return;
    metadataWaiters
        .computeIfAbsent(track.id, k -> new ArrayList<>())
        .add(new WeakReference<>(image));
    if (!metadataLoading.add(track.id)) return;
    Track snapshot = Track.from(track.json());
    a.workers.execute(
        () -> {
          String cover = "";
          try {
            cover = a.catalog.cover(snapshot);
          } catch (Exception ignored) {
          }
          final String result = CoverArt.url(cover);
          a.ui.post(
              () -> {
                metadataLoading.remove(snapshot.id);
                List<WeakReference<ImageView>> views = metadataWaiters.remove(snapshot.id);
                boolean usable =
                    !result.isEmpty()
                        && System.currentTimeMillis() - failed.getOrDefault(result, 0L) >= 30000;
                if (!usable) failed.put(tag, System.currentTimeMillis());
                else {
                  track.cover = result;
                  JSONObject cache = a.store.object("cover-cache-v1");
                  try {
                    cache.put(snapshot.id, result);
                    while (cache.length() > 200) cache.remove(cache.keys().next());
                    a.store.put("cover-cache-v1", cache.toString());
                  } catch (Exception ignored) {
                  }
                }
                if (views != null && usable)
                  for (WeakReference<ImageView> weak : views) {
                    ImageView v = weak.get();
                    if (v != null && tag.equals(v.getTag())) load(v, track, result);
                  }
              });
        });
  }

  void load(ImageView image, Track track, String url) {
    image.setTag(url);
    Bitmap cached = a.imageCache.get(url);
    if (cached != null) {
      image.setImageBitmap(cached);
      image.setContentDescription("Обложка: " + track.title);
      return;
    }
    if (System.currentTimeMillis() - failed.getOrDefault(url, 0L) < 30000) {
      resolve(image, track);
      return;
    }
    a.imageWaiters.computeIfAbsent(url, k -> new ArrayList<>()).add(image);
    if (!a.imageLoading.add(url)) return;
    a.workers.execute(
        () -> {
          Bitmap bitmap = null;
          try {
            bitmap = download(url);
          } catch (Exception ignored) {
          }
          final Bitmap result = bitmap;
          a.ui.post(
              () -> {
                a.imageLoading.remove(url);
                List<ImageView> views = a.imageWaiters.remove(url);
                if (result != null) {
                  a.imageCache.put(url, result);
                  while (a.imageCache.size() > 32)
                    a.imageCache.remove(a.imageCache.keySet().iterator().next());
                } else failed.put(url, System.currentTimeMillis());
                if (views != null)
                  for (ImageView v : views)
                    if (url.equals(v.getTag())) {
                      if (result != null) {
                        v.setImageBitmap(result);
                        v.setContentDescription("Обложка: " + track.title);
                      } else resolve(v, track);
                    }
              });
        });
  }

  static Bitmap download(String url) throws Exception {
    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
    c.setConnectTimeout(4000);
    c.setReadTimeout(6000);
    c.setRequestProperty("User-Agent", "Mozilla/5.0 PulseAndroid/0.1");
    try (InputStream in = c.getInputStream();
        ByteArrayOutputStream out = new ByteArrayOutputStream()) {
      byte[] chunk = new byte[8192];
      int n;
      while ((n = in.read(chunk)) != -1) {
        out.write(chunk, 0, n);
        if (out.size() > 5 * 1024 * 1024) throw new IOException("Image too large");
      }
      byte[] data = out.toByteArray();
      BitmapFactory.Options o = new BitmapFactory.Options();
      o.inJustDecodeBounds = true;
      BitmapFactory.decodeByteArray(data, 0, data.length, o);
      if (o.outWidth < 1 || o.outHeight < 1) throw new IOException("Invalid image");
      o.inSampleSize = Math.max(1, (int) Math.ceil(Math.max(o.outWidth, o.outHeight) / 640.0));
      o.inJustDecodeBounds = false;
      return BitmapFactory.decodeByteArray(data, 0, data.length, o);
    } finally {
      c.disconnect();
    }
  }
}
